"""Synthetic pixel-ground-truth tests, never physical experimental evidence."""
import math,unittest
import cv2
import numpy as np
from src.models.baseline3.vision_caliper import measure_object,project,edge_candidates,PROFILES,robust_ellipse
from src.p06_geometry import DEFAULT_PARAMETERS
from src.models.baseline3.size_caliper import fuse


class VisionCaliperTests(unittest.TestCase):
    def test_rotated_projection_interpolates_a_known_linear_image(self):
        y,x=np.mgrid[:200,:200];gray=(x+y).astype(np.float32)
        p=project(gray,[100,100],[1,1],-20,20,3)
        expected=200+math.sqrt(2)*p['t']
        np.testing.assert_allclose(p['gray'],expected,atol=.04)
        self.assertTrue(p['valid'].all())

    def test_annulus_measures_actual_inner_and_outer_edges(self):
        image=np.full((500,500,3),190,np.uint8)
        cv2.circle(image,(250,250),100,(40,40,40),-1);cv2.circle(image,(250,250),35,(190,190,190),-1)
        r=measure_object(image,5,[20.,20.],target_box=[148,148,352,352])
        self.assertEqual(r['status'],'MEASURED_CANDIDATE',r['reason'])
        self.assertAlmostEqual(r['dimensions']['outer_diameter']['pixels'],200,delta=2)
        self.assertAlmostEqual(r['dimensions']['inner_diameter']['pixels'],70,delta=2)
        self.assertGreater(r['diagnostics']['subpixel_edges'],0)

    def test_disk_without_a_visible_hole_is_not_completed_from_a_nominal(self):
        image=np.full((500,500,3),190,np.uint8);cv2.circle(image,(250,250),100,(40,40,40),-1)
        r=measure_object(image,5,[20.,20.],target_box=[148,148,352,352])
        self.assertEqual(r['status'],'UNMEASURABLE');self.assertFalse(r['dimensions'])

    def test_rotated_annulus_is_fitted_in_its_own_axis_frame(self):
        image=np.full((500,500,3),190,np.uint8)
        cv2.ellipse(image,(250,250),(100,90),37,0,360,(40,40,40),-1)
        cv2.ellipse(image,(250,250),(35,32),37,0,360,(190,190,190),-1)
        r=measure_object(image,5,[20.,20.],target_box=[145,145,355,355])
        self.assertEqual(r['status'],'MEASURED_CANDIDATE',r['reason'])
        self.assertAlmostEqual(r['dimensions']['outer_diameter']['pixels'],200,delta=2)
        self.assertAlmostEqual(r['dimensions']['inner_diameter']['pixels'],70,delta=2)

    def test_partial_observed_arc_can_fit_without_nominal_completion(self):
        angles=np.linspace(0,math.radians(280),71)
        points=np.c_[250+100*np.cos(angles),250+90*np.sin(angles)]
        fit=robust_ellipse(points,angles,DEFAULT_PARAMETERS)
        # OpenCV's algebraic fit on a partial float32 arc is approximate;
        # require subpixel recovery, not an exact analytic-conic solution.
        self.assertAlmostEqual(fit['radius'],100,delta=.1)
        self.assertGreaterEqual(fit['angular_bins'],24)
        self.assertLess(fit['maximum_gap_deg'],90)

    def test_hexagon_distance_is_across_flats_not_corners(self):
        image=np.full((500,500,3),190,np.uint8)
        vertices=np.array([[250+90*math.cos(a),250+90*math.sin(a)] for a in np.arange(6)*math.pi/3]).round().astype(np.int32)
        cv2.fillPoly(image,[vertices],(40,40,40));cv2.circle(image,(250,250),25,(190,190,190),-1)
        r=measure_object(image,4,[20.,20.],target_box=[158,169,342,331])
        self.assertEqual(r['status'],'MEASURED_CANDIDATE',r['reason'])
        self.assertAlmostEqual(r['dimensions']['across_flats']['pixels'],90*math.sqrt(3),delta=3)

    def test_screw_rejects_internal_glare_and_uses_multiple_gauges(self):
        image=np.full((400,700,3),190,np.uint8)
        cv2.rectangle(image,(100,150),(490,250),(40,40,40),-1)
        cv2.rectangle(image,(490,95),(530,305),(40,40,40),-1)
        cv2.rectangle(image,(100,190),(490,205),(190,190,190),-1)
        r=measure_object(image,2,[20.,20.],target_box=[95,90,535,310])
        self.assertIn(r['status'],('MEASURED_CANDIDATE','PARTIAL_CANDIDATE'),r['reason'])
        self.assertAlmostEqual(r['dimensions']['thread_major_diameter']['pixels'],100,delta=3)
        self.assertGreaterEqual(r['diagnostics']['valid_gauges'],10)

    def fixture(self,value=4.,uncertainty=.05,status='MEASURED_CANDIDATE'):
        return dict(status=status,reason='',dimensions={'thread_major_diameter':dict(mm_estimate=value,pixels=value*35.,line_xy=[[1,1],[5,1]])},
            diagnostics=dict(quality_valid_for_rejection=status=='MEASURED_CANDIDATE',measurement_uncertainty_mm=uncertainty),
            scale_px_per_mm=[35.,35.])

    def test_hybrid_does_not_run_an_unneeded_second_method(self):
        def forbidden():raise AssertionError('high quality primary should be sufficient')
        r=fuse('A',self.fixture(),forbidden)
        self.assertEqual(r['diagnostics']['attempted_methods'],['A'])

    def test_hybrid_disagreement_is_not_resolved_by_nominal_closeness(self):
        r=fuse('A',self.fixture(4.,.25),lambda:self.fixture(5.,.05))
        self.assertEqual(r['reason'],'HYBRID_METHOD_DISAGREEMENT')
        self.assertEqual(r['status'],'PARTIAL_CANDIDATE');self.assertFalse(r['diagnostics']['quality_valid_for_rejection'])

    def test_hybrid_recovers_only_from_actual_secondary_evidence(self):
        failed=self.fixture(status='UNMEASURABLE');failed['dimensions']={}
        r=fuse('A',failed,lambda:self.fixture())
        self.assertEqual(r['status'],'MEASURED_CANDIDATE')
        self.assertEqual(r['diagnostics']['selected_method'],'B')


if __name__=='__main__':unittest.main()
