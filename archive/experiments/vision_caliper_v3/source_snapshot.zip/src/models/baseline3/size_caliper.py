"""B/C candidate backend, reusing the frozen v2 decisions and foreground checks."""
from __future__ import annotations
import copy,time
from pathlib import Path
import numpy as np
from .inference import ROOT,_frame
from .geometry_repair import measure_object as geometry_measure
from .vision_caliper import measure_object as caliper_measure
from .size_repaired import RepairedSizeBackend
from src.work_orders import validate_counts


def high_quality(m):
    if m['status']!='MEASURED_CANDIDATE' or not m['diagnostics'].get('quality_valid_for_rejection'):return False
    q=m['diagnostics'];minimum=min(d['mm_estimate'] for d in m['dimensions'].values())
    if q.get('measurement_uncertainty_mm',1e9)>.04*minimum:return False
    if q.get('attempted_gauges') and q['valid_gauges']/q['attempted_gauges']<.75:return False
    if 'outer_angular_bins' in q and (min(q['outer_angular_bins'],q['inner_angular_bins'])<28 or max(q['outer_ellipse_rms_fraction'],q['inner_ellipse_rms_fraction'])>.02):return False
    return True


def agreement(a,b):
    common=a['dimensions'].keys()&b['dimensions'].keys();differences={}
    qa,qb=a['diagnostics'],b['diagnostics'];scale=float(np.mean(a['scale_px_per_mm']))
    allowed=qa.get('measurement_uncertainty_mm',0)+qb.get('measurement_uncertainty_mm',0)+3/scale
    for key in common:
        difference=abs(a['dimensions'][key]['mm_estimate']-b['dimensions'][key]['mm_estimate'])
        if difference>allowed:differences[key]=dict(difference_mm=difference,agreement_limit_mm=allowed)
    return not differences,differences


def fuse(primary_name,primary,secondary_loader):
    """Quality-first lazy fallback. Never inspect acceptance bands or nominal sizes."""
    if high_quality(primary):
        result=copy.deepcopy(primary);result['diagnostics'].update(strategy='Hybrid',attempted_methods=[primary_name],selected_method=primary_name)
        return result
    secondary_name='B' if primary_name=='A' else 'A';secondary=secondary_loader()
    agrees,disagreement=agreement(primary,secondary)
    if not agrees and primary['dimensions'] and secondary['dimensions']:
        result=copy.deepcopy(primary)
        result.update(status='PARTIAL_CANDIDATE' if result['dimensions'] else 'UNMEASURABLE',reason='HYBRID_METHOD_DISAGREEMENT')
        result['diagnostics'].update(quality_valid_for_rejection=False,strategy='Hybrid',attempted_methods=[primary_name,secondary_name],
            disagreement=disagreement,alternative_dimensions=secondary['dimensions'],selected_method=None)
        return result
    complete=[(name,m) for name,m in ((primary_name,primary),(secondary_name,secondary)) if m['status']=='MEASURED_CANDIDATE']
    if complete:
        name,chosen=next(((name,m) for name,m in complete if high_quality(m)),complete[0])
        result=copy.deepcopy(chosen)
        # A supported caliper diameter may complement a complete contour length,
        # only when both observed diameters agree within their image evidence.
        caliper=primary if primary_name=='B' else secondary
        if name=='A' and 'thread_major_diameter' in caliper['dimensions'] and caliper['diagnostics'].get('valid_gauges',0)>=10:
            result['dimensions']['thread_major_diameter']=copy.deepcopy(caliper['dimensions']['thread_major_diameter'])
            result['diagnostics']['dimension_methods']={'underhead_length':'A','thread_major_diameter':'B'}
            result['diagnostics']['measurement_uncertainty_mm']=max(result['diagnostics']['measurement_uncertainty_mm'],caliper['diagnostics'].get('measurement_uncertainty_mm',0))
        result['diagnostics'].update(strategy='Hybrid',attempted_methods=[primary_name,secondary_name],selected_method=name,
            methods_agree=True,alternative_status=secondary['status'] if name==primary_name else primary['status'])
        return result
    result=copy.deepcopy(primary if len(primary['dimensions'])>=len(secondary['dimensions']) else secondary)
    result['diagnostics'].update(strategy='Hybrid',attempted_methods=[primary_name,secondary_name],selected_method=None,
                                 alternative_reason=secondary['reason'])
    return result


def measure(image,cid,scale,parameters,box,peers,settings,*,cached_a=None,cached_b=None):
    def a():
        return copy.deepcopy(cached_a) if cached_a is not None else geometry_measure(image,cid,scale,parameters,target_box=box,excluded_boxes=peers)
    def b():
        return copy.deepcopy(cached_b) if cached_b is not None else caliper_measure(image,cid,scale,parameters,target_box=box,excluded_boxes=peers,
            profile=settings['caliper_profile'],head_definition=settings.get('head_definition','underhead_visible'))
    strategy=settings['strategy']
    if strategy=='A':return a()
    if strategy=='B':
        result=b();result['diagnostics'].update(strategy='B',attempted_methods=['B'],selected_method='B');return result
    if strategy!='C':raise ValueError('Unknown A/B/C size strategy')
    primary=settings['hybrid_primary'][str(cid)]
    return fuse(primary,a() if primary=='A' else b(),b if primary=='A' else a)


def frame_measurements(frame,raw,selection,calibration,settings):
    h,w=frame.shape[:2];measurements={};durations={}
    for obj in raw['objects']:
        cid=obj['class_id']
        if cid==0:continue
        x1,y1,x2,y2=[obj[k] for k in ('xmin','ymin','xmax','ymax')];pad=max(24,round(max(x2-x1,y2-y1)*.35))
        l,t=max(0,int(x1)-pad),max(0,int(y1)-pad);r,b=min(w,int(np.ceil(x2))+pad),min(h,int(np.ceil(y2))+pad)
        peers=[]
        for other in raw['objects']:
            if other['detection_id']==obj['detection_id']:continue
            a,c,d,e=[other[k] for k in ('xmin','ymin','xmax','ymax')]
            if min(r,d)>max(l,a) and min(b,e)>max(t,c):peers.append([a-l,c-t,d-l,e-t])
        family='1' if cid in (1,2,3) else str(cid)
        parameters={k:v for k,v in selection['selected'][family]['parameters'].items() if k!='targeted'}
        started=time.perf_counter()
        m=measure(frame[t:b,l:r],cid,calibration['px_per_mm'],parameters,[x1-l,y1-t,x2-l,y2-t],peers,settings)
        durations[obj['detection_id']]=(time.perf_counter()-started)*1000;measurements[obj['detection_id']]=m
    return measurements,durations


class CaliperBackend(RepairedSizeBackend):
    def __init__(self,path,**kwargs):
        super().__init__(path,**kwargs);self.settings=self.config['vision_caliper']
        if self.settings['strategy'] not in ('B','C'):raise ValueError('Use the frozen v2 factory for reference A')
        self.files.extend([Path(__file__),ROOT/'src/models/baseline3/vision_caliper.py']);self.signature=self._signature()
        self.metadata.update(baseline3_mode='size_caliper_v3_'+self.settings['strategy'],
            measurement_strategy=copy.deepcopy(self.settings),
            deployment_stage='DEVELOPMENT_ONLY_NO_CALIPER_TRUTH_OR_INSTRUCTOR_APPROVAL',
            model_version=self.metadata['model_version']+'-caliper-v3-'+self.settings['strategy'])

    def process_observations(self,frame,raw,expected_counts,*,measurement_cache=None):
        result=super().process_observations(frame,raw,expected_counts,measurement_cache=measurement_cache)
        result['inspection'].update(mode='size_caliper_v3_'+self.settings['strategy'],strategy=self.settings['strategy'])
        for obj in result['objects']:
            evidence=obj.get('size_evidence',{})
            if 'measurement' in evidence:
                evidence['measurement_policy_reason']='VISION_CALIPER_'+self.settings['strategy']+' / IMAGE_QUALITY_GATE / NOT_INSTRUCTOR_APPROVED'
        return result

    def infer(self,frame,expected_counts):
        _frame(frame);expected=validate_counts(expected_counts)
        if self._signature()!=self.signature:raise RuntimeError('Caliper candidate changed; reload')
        self.synchronize();start=time.perf_counter();raw=self.detector.infer(frame,expected);self.synchronize();detector_ms=(time.perf_counter()-start)*1000
        if [frame.shape[1],frame.shape[0]]!=self.calibration['frame_size']:
            return self.process_observations(frame,raw,expected)
        dimensions,latencies=frame_measurements(frame,raw,self.selection,self.calibration,self.settings)
        result=self.process_observations(frame,raw,expected,measurement_cache=dimensions)
        result['inspection'].update(geometry_execution='FRESH_VISION_CALIPER_PIPELINE',
            detector_ms=detector_ms,size_module_ms=sum(latencies.values()),per_object_size_ms=latencies,
            actual_fresh_measurement_calls=len(dimensions),strategy=self.settings['strategy'])
        return result

    def rejudge(self,result,expected_counts):
        result=super().rejudge(result,expected_counts)
        result['baseline3_mode']='size_caliper_v3_'+self.settings['strategy'];return result


def create_backend(*,model_id,config):
    if model_id!='baseline3' or config.get('baseline3_mode')!='size_caliper_v3':raise ValueError('Explicit v3 Baseline3 mode required; no count-only fallback')
    path=Path(config['size_candidate_config']);path=path if path.is_absolute() else ROOT/path
    return CaliperBackend(path)
