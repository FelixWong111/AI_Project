"""OpenCV 1-D vision calipers, independent measurement of original pixels.

Principles: rotated finite-width projection, smoothed derivative/polarity,
observed edge pairs, local subpixel extrema, repeated gauges and robust fits.
No catalogue dimensions, image names, work orders or other model predictions
are used to choose an edge or a result. References are in size_caliper_v3/.
"""
from __future__ import annotations
import math
import cv2
import numpy as np
from src.p06_geometry import DEFAULT_PARAMETERS,MeasurementFailure,require,dimension
from .geometry_repair import target_contours

PROFILES={
    'standard':dict(sigma=1.2,half_width=2,minimum_gradient=2.),
    'wide_projection':dict(sigma=1.5,half_width=4,minimum_gradient=2.)}


def project(gray,center,direction,start,end,half_width,valid_mask=None):
    direction=np.asarray(direction,float);direction/=np.linalg.norm(direction)
    tangent=np.array([-direction[1],direction[0]]);positions=np.arange(float(start),float(end)+.5,1.)
    offsets=np.arange(-half_width,half_width+1,dtype=float)
    xy=np.asarray(center)+positions[None,:,None]*direction+offsets[:,None,None]*tangent
    h,w=gray.shape
    good=(xy[:,:,0]>=1)&(xy[:,:,0]<w-2)&(xy[:,:,1]>=1)&(xy[:,:,1]<h-2)
    values=cv2.remap(gray.astype(np.float32,copy=False),xy[:,:,0].astype(np.float32),xy[:,:,1].astype(np.float32),cv2.INTER_LINEAR)
    if valid_mask is not None:
        allowed=cv2.remap(valid_mask,xy[:,:,0].astype(np.float32),xy[:,:,1].astype(np.float32),cv2.INTER_NEAREST)
        good &= allowed>0
    profile=values.mean(axis=0);valid=good.mean(axis=0)>=.95
    corners=[(np.asarray(center)+u*direction+v*tangent).tolist() for u,v in ((start,-half_width),(end,-half_width),(end,half_width),(start,half_width))]
    return dict(t=positions,gray=profile,valid=valid,center=np.asarray(center),direction=direction,rectangle=corners)


def edge_candidates(projection,settings):
    profile=cv2.GaussianBlur(projection['gray'][None,:],(0,0),settings['sigma']).ravel()
    if len(profile)<9:return profile,[]
    derivative=np.gradient(profile);edges=[]
    for polarity in (-1,1):
        signed=polarity*derivative
        peaks=np.flatnonzero((signed[2:-2]>=signed[1:-3])&(signed[2:-2]>signed[3:-1])&(signed[2:-2]>=settings['minimum_gradient']))+2
        for j in peaks:
            if not projection['valid'][j-1:j+2].all():continue
            y0,y1,y2=map(float,signed[j-1:j+2]);denom=y0-2*y1+y2;delta=0.;subpixel=False
            if denom < -1e-4:
                fitted=.5*(y0-y2)/denom
                if abs(fitted)<=.75:delta=fitted;subpixel=True
            edges.append(dict(index=int(j),position=float(projection['t'][j]+delta),amplitude=float(signed[j]),
                              polarity=polarity,subpixel=subpixel))
    return profile,edges


def pair_edges(projection,expected_left,expected_right,settings):
    signal,edges=edge_candidates(projection,settings);t=projection['t'];rough=expected_right-expected_left
    require(rough>4,'CALIPER_SEED_TOO_SMALL');middle=(expected_left+expected_right)/2
    valid=projection['valid'];far=max(8,round(.20*rough));inside=max(5,round(.08*rough));chosen=[]
    for side,polarity,guess in ((-1,-1,expected_left),(1,1,expected_right)):
        bg=float(np.median(signal[:8] if side<0 else signal[-8:]));candidates=[]
        for e in edges:
            j=e['index']
            if e['polarity']!=polarity or (side<0 and t[j]>=middle) or (side>0 and t[j]<=middle):continue
            outer=j+side*np.arange(4,far+4);inner=j-side*np.arange(3,inside+3)
            if min(outer.min(),inner.min())<0 or max(outer.max(),inner.max())>=len(t):continue
            if not valid[np.r_[outer,inner]].all():continue
            exterior=float(np.median(signal[outer]));metal=float(np.median(signal[inner]));contrast=exterior-metal
            if contrast<10 or abs(exterior-bg)>max(18,.25*max(1,bg-metal)):continue
            if np.quantile(abs(signal[outer]-bg),.8)>max(22,.30*max(1,bg-metal)):continue
            step=signal[min(len(t)-1,j+side*3)]-signal[max(0,j-side*3)] if side>0 else signal[max(0,j-3)]-signal[min(len(t)-1,j+3)]
            if step<.45*contrast:continue
            candidates.append(e)
        require(candidates,'CALIPER_EXTERIOR_PAIR_UNSUPPORTED')
        chosen.append(min(candidates,key=lambda e:(abs(e['position']-guess),-e['amplitude'])))
    left,right=chosen
    require(.50*rough<right['position']-left['position']<1.6*rough,'CALIPER_PAIR_GEOMETRY_INCONSISTENT')
    xy=[(projection['center']+projection['direction']*e['position']).tolist() for e in chosen]
    return dict(width=right['position']-left['position'],points=xy,
                amplitude=min(e['amplitude'] for e in chosen),subpixel=sum(e['subpixel'] for e in chosen),
                rectangle=projection['rectangle'])


def owned_context(image,box,parameters,excluded_boxes):
    gray=cv2.cvtColor(image,cv2.COLOR_BGR2GRAY);h,w=gray.shape
    valid=np.ones(gray.shape,np.uint8);x1,y1,x2,y2=map(float,box)
    for a,c,d,e in excluded_boxes:
        l,t=max(0,int(a)-3),max(0,int(c)-3);r,b=min(w,int(np.ceil(d))+3),min(h,int(np.ceil(e))+3)
        if l<r and t<b:valid[t:b,l:r]=0
    valid[max(0,int(y1)):min(h,int(np.ceil(y2))),max(0,int(x1)):min(w,int(np.ceil(x2)))]=1
    try:
        _,_,candidates,diag=target_contours(image,box,parameters,excluded_boxes)
        contour=max(candidates,key=lambda c:c['area'])['contour']
        return gray.astype(np.float32),valid,contour,diag
    except MeasurementFailure:
        edges=cv2.Canny(gray,parameters['canny_low'],parameters['canny_high']);edges[valid==0]=0
        mask=np.zeros_like(edges);l,t=max(0,int(x1)-3),max(0,int(y1)-3);r,b=min(w,int(np.ceil(x2))+3),min(h,int(np.ceil(y2))+3);mask[t:b,l:r]=1
        yy,xx=np.nonzero((edges>0)&(mask>0));require(len(xx)>=40,'CALIPER_NO_INSTANCE_EDGE_SEED')
        contour=np.c_[xx,yy].astype(np.int32).reshape(-1,1,2)
        return gray.astype(np.float32),valid,contour,dict(seed_method='target-owned edge cloud; no closed contour required')


def screw_frame(contour,scale):
    points=cv2.convexHull(contour)[:,0].astype(float);sref=float(np.mean(scale));points*=sref/scale
    # Use filled support for the principal direction; this is an axis seed,
    # not a measured head/shaft boundary.
    x,y,w,h=cv2.boundingRect(contour);mask=np.zeros((h,w),np.uint8)
    cv2.fillConvexPoly(mask,(cv2.convexHull(contour)[:,0]-[x,y]).astype(np.int32),1)
    yy,xx=np.nonzero(mask);cloud=np.c_[xx+x,yy+y].astype(float)*sref/scale
    center=cloud.mean(axis=0);_,v=np.linalg.eigh(np.cov((cloud-center).T));axis=v[:,-1]
    boundary=contour[:,0].astype(float)*sref/scale
    for _ in range(3):
        normal=np.array([-axis[1],axis[0]]);uv=np.c_[(boundary-center)@axis,(boundary-center)@normal]
        start=float(uv[:,0].min());bins=np.rint(uv[:,0]-start).astype(int);n=bins.max()+1
        lo=np.full(n,np.inf);hi=np.full(n,-np.inf);np.minimum.at(lo,bins,uv[:,1]);np.maximum.at(hi,bins,uv[:,1]);ok=np.isfinite(lo)&np.isfinite(hi)
        require(ok.sum()>.45*n,'CALIPER_AXIS_SEED_DISCONTINUOUS');ii=np.arange(n)
        lo=np.interp(ii,ii[ok],lo[ok]);hi=np.interp(ii,ii[ok],hi[ok]);width=cv2.medianBlur((hi-lo).astype(np.float32)[None,:],5).ravel()
        if max(width[:max(3,n//3)])<max(width[-max(3,n//3):]):axis=-axis;continue
        body=np.arange(int(.4*n),int(.85*n));slope=np.polyfit(body,(lo[body]+hi[body])/2,1)[0]
        require(abs(slope)<.8,'CALIPER_AXIS_AMBIGUOUS');axis+=slope*normal;axis/=np.linalg.norm(axis)
    return center,axis,normal,start,lo,hi,width


def axial_edge(gray,valid,center,direction,begin,end,settings):
    projection=project(gray,center,direction,begin,end,settings['half_width'],valid);signal,edges=edge_candidates(projection,settings)
    bg=float(np.median(signal[-8:]));accepted=[]
    for e in edges:
        j=e['index']
        if e['polarity']!=1 or j<5 or len(signal)-j<10:continue
        tail=signal[j+4:]
        if not projection['valid'][j-4:].all():continue
        if np.quantile(abs(tail-bg),.8)>18 or np.median(tail)-np.median(signal[j-5:j-2])<10:continue
        accepted.append(e)
    require(accepted,'CALIPER_AXIAL_TRANSITION_UNSUPPORTED')
    edge=accepted[-1]
    return edge['position'],edge['amplitude'],projection['rectangle']


def screw_measure(gray,valid,contour,scale,settings,head_definition):
    sref=float(np.mean(scale));center,axis,normal,start,lo,hi,width=screw_frame(contour,scale);n=len(width)
    body=np.arange(int(.4*n),int(.85*n));rough=float(np.quantile(width[body],.9));head_width=float(max(width[:n//2]))
    require(rough>6 and head_width>1.2*rough,'CALIPER_HEAD_SHAFT_SEED_UNRESOLVED')
    head=np.flatnonzero(width[:int(.55*n)]>rough+.3*(head_width-rough));require(len(head)>=3,'CALIPER_HEAD_SHAFT_SEED_UNRESOLVED')
    shoulder=float(head[-1]+1);tip=float(n-1);span=tip-shoulder
    def xy(u,v):return (center+axis*(start+u)+normal*v)*scale/sref
    direction=normal*scale/sref;direction/=np.linalg.norm(direction)
    gauges=[]
    for u in np.linspace(shoulder+max(.22*span,.5*rough),shoulder+.80*span,24):
        j=min(n-1,max(0,round(u)));middle=(lo[j]+hi[j])/2
        left,right=lo[j]-middle,hi[j]-middle;reach=max(18,.50*rough)
        try:
            p=project(gray,xy(u,middle),direction,left-reach,right+reach,settings['half_width'],valid)
            pair=pair_edges(p,left,right,settings);pair['u']=float(u);gauges.append(pair)
        except MeasurementFailure:pass
    require(len(gauges)>=10,'CALIPER_TOO_FEW_SHAFT_REGIONS')
    widths=np.array([g['width'] for g in gauges]);median=float(np.median(widths));mad=float(np.median(abs(widths-median)))*1.4826
    keep=abs(widths-median)<=max(3.,4*mad);gauges=[g for g,k in zip(gauges,keep) if k];widths=widths[keep]
    require(len(gauges)>=10 and np.ptp(widths)/np.median(widths)<.30,'CALIPER_SHAFT_REGIONS_INCONSISTENT')
    coverage={min(2,int(3*(g['u']-shoulder)/max(1,span))) for g in gauges};require(len(coverage)>=2,'CALIPER_SHAFT_AXIAL_COVERAGE_LOW')
    chosen=min(gauges,key=lambda g:abs(g['width']-np.quantile(widths,.9)));diameter=chosen['width'];midpoint=np.mean(chosen['points'],axis=0)
    dims=dict(thread_major_diameter=dimension(*map(np.asarray,chosen['points']),scale));failures={};head_positions=[];tip_positions=[];rectangles=[g['rectangle'] for g in gauges]
    axial=axis*scale/sref;axial/=np.linalg.norm(axial);middle=float((lo[round(chosen['u'])]+hi[round(chosen['u'])])/2)
    for rho in (.60,.72,.84):
        pair=[]
        for sign in (-1,1):
            try:
                value,amp,rect=axial_edge(gray,valid,xy(shoulder,middle+sign*rho*diameter),axial,-.7*diameter,.75*diameter,settings)
                pair.append(value);rectangles.append(rect)
            except MeasurementFailure:pass
        if len(pair)==2 and abs(pair[0]-pair[1])<=max(4,.15*diameter):head_positions.append(float(np.mean(pair)))
    for rho in (-.16,0,.16):
        try:
            value,amp,rect=axial_edge(gray,valid,xy(tip,middle+rho*diameter),axial,-.4*diameter,.5*diameter,settings)
            tip_positions.append(value);rectangles.append(rect)
        except MeasurementFailure:pass
    if head_definition not in ('underhead_visible','overall_explicit'):
        failures['underhead_length']='HEAD_LENGTH_DEFINITION_UNCONFIRMED'
    elif head_definition=='overall_explicit':
        # This cannot be enabled implicitly for countersunk parts; catalogue
        # records must explicitly define how overall length maps to the contract.
        failures['underhead_length']='OVERALL_LENGTH_NEEDS_EXPLICIT_CATALOGUE_MAPPING'
    elif len(head_positions)<2 or np.ptp(head_positions)>.2*diameter:
        failures['underhead_length']='CALIPER_HEAD_SEATING_PLANE_UNRESOLVED'
    elif len(tip_positions)<2 or np.ptp(tip_positions)>.15*diameter:
        failures['underhead_length']='CALIPER_TIP_UNRESOLVED'
    else:
        a=xy(shoulder,middle)+axial*np.median(head_positions);b=xy(tip,middle)+axial*np.median(tip_positions)
        require(np.linalg.norm(b-a)>diameter,'CALIPER_LENGTH_GEOMETRY_INCONSISTENT');dims['underhead_length']=dimension(a,b,scale)
    return dims,dict(method='rotated finite-strip vision caliper',valid_gauges=len(gauges),attempted_gauges=24,
        subpixel_edges=sum(g['subpixel'] for g in gauges),minimum_edge_amplitude=float(min(g['amplitude'] for g in gauges)),
        diameter_regions_px=widths.tolist(),measurement_rectangles=rectangles,
        axis_xy=axis.tolist(),diameter_repeatability_px=max(1.,mad),measurement_uncertainty_mm=max(1.,mad)/sref,
        dimension_failures=failures,head_definition=head_definition,
        quality_valid_for_rejection=not failures,contour_required_for_measurement=False),[cv2.convexHull(contour)]


def robust_ellipse(points,angles,parameters):
    points=np.asarray(points,np.float32);require(len(points)>=24,'CALIPER_CIRCULAR_SUPPORT_TOO_SMALL')
    keep=np.ones(len(points),bool)
    for _ in range(4):
        fit=cv2.fitEllipseDirect(points[keep].reshape(-1,1,2));center=np.asarray(fit[0]);axes=np.asarray(fit[1])/2
        require(min(axes)>0 and np.isfinite(axes).all(),'CALIPER_ELLIPSE_DEGENERATE')
        theta=math.radians(fit[2]);rot=np.array([[math.cos(theta),math.sin(theta)],[-math.sin(theta),math.cos(theta)]])
        q=(points-center)@rot.T;error=abs(np.sqrt((q[:,0]/axes[0])**2+(q[:,1]/axes[1])**2)-1)
        med=float(np.median(error[keep]));mad=float(np.median(abs(error[keep]-med)))*1.4826
        keep=error<=min(.08,max(.025,med+3*mad))
        require(keep.sum()>=24,'CALIPER_CIRCULAR_OUTLIER_SUPPORT_TOO_SMALL')
    q=(points-center)@rot.T;phase=np.mod(np.arctan2(q[:,1]/axes[1],q[:,0]/axes[0]),2*np.pi)
    used=np.sort(phase[keep]);gap=float(np.max(np.diff(np.r_[used,used[0]+2*np.pi])))
    bins=len(np.unique((used/(2*np.pi)*36).astype(int)))
    require(bins>=24 and gap<=math.pi/2,'CALIPER_CIRCULAR_ANGULAR_COVERAGE_LOW')
    residual=float(np.sqrt(np.mean(error[keep]**2)))
    require(min(axes)/max(axes)>=parameters['circle_axis_ratio'],'CALIPER_CIRCULAR_FACE_TILTED')
    require(residual<parameters['circle_residual_fraction'],'CALIPER_CIRCULAR_FIT_RESIDUAL_HIGH')
    index=int(np.argmax(axes));direction=rot.T[:,index]
    return dict(center=center,axes=axes,direction=direction,radius=float(max(axes)),residual=residual,
                used=int(keep.sum()),angular_bins=bins,maximum_gap_deg=math.degrees(gap),points=points[keep])


def washer_measure(gray,valid,contour,box,scale,parameters,settings):
    x1,y1,x2,y2=map(float,box);center=np.array([(x1+x2)/2,(y1+y2)/2]);radius=max(x2-x1,y2-y1)/2
    if len(contour)>=5:
        try:
            fitted=cv2.fitEllipse(cv2.convexHull(contour));c=np.asarray(fitted[0]);r=max(fitted[1])/2
            if np.linalg.norm(c-center)<.15*radius and .7*radius<r<1.2*radius:center=c;radius=r
        except cv2.error:pass
    inner_points=[];outer_points=[];used_angles=[];strengths=[];rectangles=[];subpixels=0
    for angle in np.linspace(0,2*np.pi,72,endpoint=False):
        direction=np.array([math.cos(angle),math.sin(angle)])
        p=project(gray,center,direction,0,1.45*radius,settings['half_width'],valid);signal,edges=edge_candidates(p,settings)
        initial=float(np.median(signal[:max(5,round(.10*radius))]));bg=float(np.median(signal[-10:]));pairs=[]
        if abs(initial-bg)>40:continue  # no visible background-like aperture centre
        for a in edges:
            if a['polarity']!=-1 or not .10*radius<a['position']<.75*radius:continue
            for b in edges:
                if b['polarity']!=1 or not .65*radius<b['position']<1.30*radius or b['position']-a['position']<.10*radius:continue
                ia,ib=a['index'],b['index'];margin=max(4,round(.04*radius))
                if ia<=margin or ib+margin+8>=len(signal):continue
                if not p['valid'][max(0,ia-margin):ib+margin+8].all():continue
                metal=signal[ia+margin:ib-margin];outside=signal[ib+margin:]
                if len(metal)<5 or np.median(metal)>min(initial,bg)-10:continue
                if np.quantile(abs(outside-bg),.8)>22:continue
                if np.median(signal[:max(3,ia-margin)])<initial-18:continue
                pairs.append((a,b))
        if not pairs:continue
        # First centre-connected aperture and last background-connected exterior;
        # never choose the pair closest to a catalogue diameter.
        a,b=min(pairs,key=lambda pair:(pair[0]['position'],-pair[1]['position']))
        inner_points.append(center+direction*a['position']);outer_points.append(center+direction*b['position']);used_angles.append(angle)
        strengths.append(min(a['amplitude'],b['amplitude']));subpixels+=a['subpixel']+b['subpixel'];rectangles.append(p['rectangle'])
    require(len(inner_points)>=24,'CALIPER_TOO_FEW_ANNULAR_PAIRS')
    outer=robust_ellipse(outer_points,used_angles,parameters);inner=robust_ellipse(inner_points,used_angles,parameters)
    require(.12*outer['radius']<inner['radius']<.7*outer['radius'],'CALIPER_APERTURE_RATIO_INVALID')
    require(np.linalg.norm(inner['center']-outer['center'])<.12*outer['radius'],'CALIPER_APERTURE_NOT_CONCENTRIC')
    dims={}
    for name,fit in (('outer_diameter',outer),('inner_diameter',inner)):
        c,r,d=fit['center'],fit['radius'],fit['direction'];dims[name]=dimension(c-r*d,c+r*d,scale)
    # Extrapolation for the foreground footprint is explicitly a fitted ellipse,
    # supported by >=240 degrees and a <=90-degree gap, never nominal completion.
    ellipse_points=[]
    for angle in np.linspace(0,2*np.pi,96,endpoint=False):
        # Use observed ellipse parameters through covariance axes from the fit.
        major=outer['direction'];minor=np.array([-major[1],major[0]])
        ellipse_points.append(outer['center']+major*outer['radius']*math.cos(angle)+minor*min(outer['axes'])*math.sin(angle))
    sref=float(np.mean(scale));uncert=max(1.0/sref,outer['residual']*dims['outer_diameter']['mm_estimate'],inner['residual']*dims['inner_diameter']['mm_estimate'])
    return dims,dict(method='multi-angle finite-width radial caliper + robust observed-edge ellipses',
        valid_gauges=len(inner_points),attempted_gauges=72,subpixel_edges=subpixels,minimum_edge_amplitude=float(min(strengths)),
        outer_ellipse_rms_fraction=outer['residual'],inner_ellipse_rms_fraction=inner['residual'],
        outer_angular_bins=outer['angular_bins'],inner_angular_bins=inner['angular_bins'],
        outer_maximum_gap_deg=outer['maximum_gap_deg'],inner_maximum_gap_deg=inner['maximum_gap_deg'],
        measurement_rectangles=rectangles,observed_inner_points=np.asarray(inner_points).tolist(),observed_outer_points=np.asarray(outer_points).tolist(),
        measurement_uncertainty_mm=uncert,quality_valid_for_rejection=True,
        footprint='fitted ellipse from observed edge support; not nominal geometry',contour_required_for_measurement=False),[np.rint(ellipse_points).astype(np.int32).reshape(-1,1,2)]


def nut_measure(gray,valid,contour,box,scale,parameters,settings):
    x1,y1,x2,y2=map(float,box);center=np.array([(x1+x2)/2,(y1+y2)/2]);size=min(x2-x1,y2-y1)
    segments=cv2.createLineSegmentDetector().detect(gray.astype(np.uint8))[0];lines=[]
    require(segments is not None,'CALIPER_NO_HEXAGON_LINE_SUPPORT')
    for x,y,xx,yy in segments[:,0]:
        a=np.array([x,y]);b=np.array([xx,yy]);length=float(np.linalg.norm(b-a));mid=(a+b)/2
        if length<.15*size or not x1<=mid[0]<=x2 or not y1<=mid[1]<=y2:continue
        radius=np.linalg.norm(mid-center)
        if not .27*size<radius<.7*size:continue
        angle=math.atan2(yy-y,xx-x);lines.append((angle,length))
    require(len(lines)>=4,'CALIPER_HEXAGON_STRAIGHT_EDGES_INSUFFICIENT')
    z=sum(length*np.exp(6j*angle) for angle,length in lines);coherence=abs(z)/sum(length for _,length in lines)
    require(coherence>=.55,'CALIPER_HEXAGON_DIRECTIONS_INCONSISTENT');base=float(np.angle(z)/6)
    values=[];gauges=[]
    for k in range(3):
        normal=np.array([math.cos(base+math.pi/2+k*math.pi/3),math.sin(base+math.pi/2+k*math.pi/3)])
        tangent=np.array([-normal[1],normal[0]]);group=[]
        for offset in (-.16,0,.16):
            try:
                p=project(gray,center+tangent*offset*size,normal,-.80*size,.80*size,settings['half_width'],valid)
                pair=pair_edges(p,-.43*size,.43*size,settings);group.append(pair)
            except MeasurementFailure:pass
        require(len(group)>=2,'CALIPER_OPPOSITE_FLATS_UNSUPPORTED')
        widths=np.array([g['width'] for g in group]);require(np.ptp(widths)/np.median(widths)<.08,'CALIPER_FLAT_EDGE_NOT_PARALLEL')
        selected=min(group,key=lambda g:abs(g['width']-np.median(widths)));values.append(selected['width']);gauges.extend(group)
    require(np.ptp(values)/np.median(values)<parameters['nut_spread_fraction'],'CALIPER_HEXAGON_POSE_OR_SHADOW')
    selected=min(gauges,key=lambda g:abs(g['width']-np.median(values)));dims=dict(across_flats=dimension(*map(np.asarray,selected['points']),scale))
    sref=float(np.mean(scale));return dims,dict(method='three opposite-flat normal directions, repeated finite-width calipers',
        valid_gauges=len(gauges),attempted_gauges=9,minimum_edge_amplitude=float(min(g['amplitude'] for g in gauges)),
        subpixel_edges=sum(g['subpixel'] for g in gauges),hex_line_coherence=float(coherence),
        opposite_flats_mm=[v/sref for v in values],measurement_uncertainty_mm=max(1./sref,float(np.std(values))/sref),
        measurement_rectangles=[g['rectangle'] for g in gauges],quality_valid_for_rejection=True),[cv2.convexHull(contour)]


def measure_object(image,class_id,scale,parameters=None,*,target_box=None,excluded_boxes=(),profile='standard',head_definition='underhead_visible'):
    if profile not in PROFILES:raise ValueError('Unknown finite caliper profile')
    if class_id not in (1,2,3,4,5):raise ValueError('Caliper requires catalogue family 1..5')
    scale=np.asarray(scale,float);require(scale.shape==(2,) and np.isfinite(scale).all() and min(scale)>0,'CALIPER_SCALE_INVALID')
    params=dict(DEFAULT_PARAMETERS,**(parameters or {}));settings=PROFILES[profile]
    h,w=image.shape[:2];box=target_box if target_box is not None else [1,1,w-1,h-1]
    result=dict(status='UNMEASURABLE',reason='',class_id=class_id,dimensions={},dimension_status={},contours_xy=[],diagnostics={},
        scale_px_per_mm=scale.tolist(),scope='independent Vision Caliper; provisional original-pixel metrology')
    try:
        gray,valid,contour,diag=owned_context(image,box,params,excluded_boxes)
        if class_id in (1,2,3):dims,details,support=screw_measure(gray,valid,contour,scale,settings,head_definition)
        elif class_id==4:dims,details,support=nut_measure(gray,valid,contour,box,scale,params,settings)
        else:dims,details,support=washer_measure(gray,valid,contour,box,scale,params,settings)
        for dim in dims.values():
            line=np.asarray(dim['line_xy']);require(np.isfinite(line).all() and (line>=0).all() and (line[:,0]<w).all() and (line[:,1]<h).all(),'CALIPER_MEASUREMENT_OUTSIDE_IMAGE')
        failures=details.get('dimension_failures',{})
        result.update(status='PARTIAL_CANDIDATE' if failures else 'MEASURED_CANDIDATE',reason='; '.join(failures.values()),
            dimensions=dims,diagnostics=dict(diag,**details,profile=profile),contours_xy=[c[:,0].tolist() for c in support])
    except (MeasurementFailure,cv2.error) as error:
        result['reason']=str(error);result['diagnostics'].update(quality_valid_for_rejection=False,profile=profile)
    keys=('underhead_length','thread_major_diameter') if class_id in (1,2,3) else ('across_flats',) if class_id==4 else ('outer_diameter','inner_diameter')
    result['dimension_status']={k:dict(status='CANDIDATE' if k in result['dimensions'] else 'UNMEASURABLE',reason='' if k in result['dimensions'] else result['reason']) for k in keys}
    return result
