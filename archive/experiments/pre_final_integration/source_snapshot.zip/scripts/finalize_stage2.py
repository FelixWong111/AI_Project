"""Resumable final Stage 2 packaging; never trains or reads Stage 3 images."""
from __future__ import annotations
import argparse,csv,hashlib,json,os,shutil,subprocess,sys,time,zipfile
from pathlib import Path
from datetime import datetime,timezone
from collections import Counter
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
OUT=ROOT/'results/p07_final_integration';DATA=ROOT/'datasets/mechanical_components_v2'
OLD=ROOT/'data/mechanical_components_v2';ARCHIVE=ROOT/'archive/experiments'

def sha(p):
    with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def save(p,v):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf8')
def rows(p):
    with Path(p).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def csvsave(p,values,fields=None):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields or list(values[0]));w.writeheader();w.writerows(values)
def rel(p):return Path(p).resolve().relative_to(ROOT).as_posix()
def command(args,log=None):
    r=subprocess.run(args,cwd=ROOT,capture_output=True,text=True,encoding='utf8',errors='replace')
    if log:Path(log).write_text(r.stdout+r.stderr,encoding='utf8')
    if r.returncode:raise RuntimeError(f'{args}: exit {r.returncode}; see {log}')
    return r.stdout
def copy_verified(source,dest):
    source,dest=Path(source),Path(dest);dest.parent.mkdir(parents=True,exist_ok=True)
    if dest.exists():assert sha(source)==sha(dest),f'Existing different artifact: {dest}'
    else:shutil.copy2(source,dest)
    assert sha(source)==sha(dest)

def audit():
    if (OUT/'initial_audit.json').exists():return
    OUT.mkdir(parents=True,exist_ok=True);backup=ROOT/'outputs/final_integration/pre_change_sources.zip';backup.parent.mkdir(parents=True,exist_ok=True)
    files=[p for folder in ('src','scripts','config','tests') for p in (ROOT/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts]
    files += [ROOT/n for n in ('app.py','predict.py','p08_run.py','p08_object_observations.py','README.md','.gitignore','.gitattributes')]
    with zipfile.ZipFile(backup,'w',zipfile.ZIP_DEFLATED) as z:
        for p in files:z.write(p,rel(p))
    (OUT/'initial_git_status.txt').write_text(command(['git','status','--short']),encoding='utf8')
    (ROOT/'outputs/final_integration/pre_change.patch').write_text(command(['git','diff','--binary']),encoding='utf8')
    protected={rel(p):sha(p) for folder in ('models','results/dataset_v2_baseline_comparison','results/baseline3_v2_experiment')
        for p in (ROOT/folder).rglob('*') if p.is_file()}
    weights=[dict(path=rel(p),bytes=p.stat().st_size,sha256=sha(p)) for p in (ROOT/'models').rglob('*') if p.suffix in ('.pt','.pth','.joblib','.npz')]
    save(OUT/'initial_audit.json',dict(branch=command(['git','branch','--show-current']).strip(),
        protected=protected,weights=weights,source_backup=rel(backup),source_backup_sha256=sha(backup),
        manual_sha256=sha(ROOT/'Project-Man.pdf'),team_plan_sha256=sha(ROOT/'team_plan_ai.md'),
        requested_docx='NOT_FOUND; available team_plan_ai.md reviewed',
        live_physical_acceptance='NOT_VERIFIED',stage3='No Stage3 image/GT evaluation; exclude from publishable tree'))


def datasets():
    if (OUT/'dataset_migration.json').exists():return
    from PIL import Image
    public=[r for r in rows(OLD/'manifests/dataset_manifest.csv') if r['split'] in ('train','val','stage2_test')]
    # Actual source names are train/validation in some manifests; derive by stage/list.
    ids={n:set((OLD/'splits'/f'{s}.txt').read_text(encoding='utf8').splitlines()) for n,s in [('train','train'),('validation','val'),('stage2_test','stage2_test')]}
    selected=set.union(*ids.values());public=[r for r in rows(OLD/'manifests/dataset_manifest.csv') if r['image_id'] in selected]
    assert {k:len(v) for k,v in ids.items()}=={'train':360,'validation':80,'stage2_test':30}
    migration=[]
    def move(source,target,expected=None):
        source,target=Path(source),Path(target);assert target.resolve().is_relative_to(DATA.resolve())
        if source.exists():
            h=sha(source);assert expected is None or expected==h
            target.parent.mkdir(parents=True,exist_ok=True)
            if target.exists():assert sha(target)==h;source.unlink()
            else:shutil.move(str(source),str(target))
        else:h=sha(target);assert expected is None or expected==h
        assert sha(target)==h
        migration.append(dict(source=rel(source),destination=rel(target),sha256=h,bytes=target.stat().st_size))
    for r in public:
        split=next(k for k,v in ids.items() if r['image_id'] in v);target=DATA/'public'/split/'images'/r['image_id']
        source=ROOT/r['image_path'];move(source,target,r['sha256'])
        with Image.open(target) as image:assert image.size==(int(r['width']),int(r['height']))
        label=Path(r['image_id']).with_suffix('.txt').name
        source_label=OLD/'yolo/labels'/('train' if split=='train' else 'val' if split=='validation' else 'test')/label
        move(source_label,DATA/'public'/split/'labels'/label)
        original=ROOT/r['source_annotation'];copy_verified(original,DATA/'public'/split/'annotations'/Path(original).name)
    roi_rows=read(ROOT/'results/baseline3_v2_experiment/size_development_v1/rois.json');assert len(roi_rows)==220
    for r in roi_rows:
        split='development' if r['experiment_split']=='development' else 'regression_used'
        move(ROOT/r['image_path'],DATA/'size_special'/split/r['image_id'],r['derived_sha256'])
    ruler=rows(OLD/'calibration/ruler_manifest.csv');assert len(ruler)==10
    for r in ruler:move(ROOT/r['image_path'],DATA/'calibration/ruler_images'/r['image_id'])
    pathmap={r['source']:r['destination'] for r in migration}
    def mapped(value):
        if isinstance(value,dict):return {k:mapped(v) for k,v in value.items()}
        if isinstance(value,list):return [mapped(v) for v in value]
        if isinstance(value,str):return pathmap.get(value,value)
        return value
    gt_images=[r for r in rows(OLD/'ground_truth_images.csv') if r['image_id'] in selected]
    gt_objects=[r for r in rows(OLD/'ground_truth_objects.csv') if r['image_id'] in selected]
    for r in gt_images:
        r['image_path']=pathmap[r['image_path']]
        split=next(k for k,v in ids.items() if r['image_id'] in v)
        r['annotation_path']=rel(DATA/'public'/split/'annotations'/Path(r['annotation_path']).name)
    csvsave(DATA/'annotations/ground_truth_images.csv',gt_images);csvsave(DATA/'annotations/ground_truth_objects.csv',gt_objects)
    for split,names in ids.items():
        subset=[r for r in gt_images if r['image_id'] in names]
        csvsave(DATA/'manifests'/(split+'.csv'),subset)
        (DATA/'manifests'/(split+'.txt')).write_text('\n'.join(r['image_id'] for r in subset)+'\n',encoding='utf8')
        base=DATA/'public'/split
        csvsave(base/'ground_truth_images.csv',subset);csvsave(base/'ground_truth_objects.csv',[r for r in gt_objects if r['image_id'] in names])
        orders=[dict(image_id=r['image_id'],expected_counts=dict.fromkeys('12345',1)) for r in subset]
        save(DATA/'configs'/('expected_counts_'+split+'.json'),orders)
    csvsave(DATA/'development/ground_truth_images.csv',[r for r in gt_images if r['image_id'] not in ids['stage2_test']])
    csvsave(DATA/'development/ground_truth_objects.csv',[r for r in gt_objects if r['image_id'] not in ids['stage2_test']])
    for name,split in [('validation','validation'),('stage2_evaluation','stage2_test')]:
        save(DATA/'configs'/(name+'.json'),dict(schema='inspection-evaluation/v2',dataset=rel(DATA/'public'/split),
            evaluation_stage='validation' if split=='validation' else 'stage2',input_dir=rel(DATA/'public'/split/'images'),
            ground_truth_images=rel(DATA/'public'/split/'ground_truth_images.csv'),ground_truth_objects=rel(DATA/'public'/split/'ground_truth_objects.csv'),
            counts_file=rel(DATA/'configs'/('expected_counts_'+split+'.json')),split_list=rel(DATA/'manifests'/(split+'.txt')),dataset_status=rel(DATA/'dataset_status.json')))
    cfg=read(OLD/'configs/training.json');cfg.update(data_dir=rel(DATA/'development'),prepared_dir='outputs/training_v2/prepared')
    save(DATA/'configs/training.json',cfg)
    save(DATA/'configs/data.yaml.json',dict(path='datasets/mechanical_components_v2',train='public/train/images',val='public/validation/images',test='public/stage2_test/images',
        names={i:n for i,n in enumerate(('non_catalogue','long_screw','thick_screw','thin_screw','hex_nut','flat_washer'))}))
    import yaml
    (DATA/'configs/data.yaml').write_text(yaml.safe_dump(read(DATA/'configs/data.yaml.json'),sort_keys=False),encoding='utf8')
    (DATA/'configs/data.yaml.json').unlink()
    csvsave(DATA/'manifests/source_sha256.csv',migration)
    csvsave(DATA/'manifests/source_mapping.csv',[mapped(r) for r in rows(OLD/'manifests/source_mapping.csv') if r['image_id'] in selected])
    csvsave(DATA/'size_special/manifest.csv',[mapped(r) for r in roi_rows])
    csvsave(DATA/'calibration/calibration_manifest.csv',[mapped(r) for r in ruler])
    copy_verified(ROOT/'results/baseline3_v2_experiment/size_development_v1/calibration.json',DATA/'calibration/calibration.json')
    copy_verified(OLD/'configs/class_mapping.json',DATA/'manifests/class_mapping.json')
    copy_verified(OLD/'audit/annotation_resolutions.json',DATA/'annotations/annotation_resolutions.json')
    (DATA/'annotations/annotation_rules.md').write_text('原始人工JSON为标注权威；原图像素xyxy左上原点，忽略实例不参与计数。ID0为类型或尺寸不符目录。GT由人工对象推导，expected_counts独立固定为各1。D18/F21以JSON为准，整批人工核实见原冻结确认记录。歧义/遮挡无法判定必须REVIEW，不补造框；保留原ignore字段。\n',encoding='utf8')
    state=read(OLD/'dataset_status.json');state.update(human_confirmation='datasets/mechanical_components_v2/manifests/human_confirmation.json',
        freeze_record='datasets/mechanical_components_v2/manifests/original_freeze.json',stage3='EXCLUDED',scope='Frozen Stage2 publishable subset only; reused size regression is not independent evaluation')
    copy_verified(OLD/'audit/human_confirmation_20261126.json',DATA/'manifests/human_confirmation.json')
    copy_verified(OLD/'audit/freeze_20261126.json',DATA/'manifests/original_freeze.json')
    save(DATA/'dataset_status.json',state)
    save(DATA/'manifests/dataset_statistics.json',dict(images={k:len(v) for k,v in ids.items()},
        labels={k:dict(Counter(r['ground_truth_label'] for r in gt_images if r['image_id'] in names)) for k,names in ids.items()},
        size_special=dict(development=154,regression_used=66,physical_specimens=8),rulers=10,stage3='90 images EXCLUDED; sealed locally',
        scene_independence='Existing human confirmation, not inferred from hash uniqueness'))
    # Leftovers contain sealed Stage3 images/GT and historical caches. Never publish them.
    sealed=ROOT/'data/sealed/mechanical_components_v2_legacy'
    assert sealed.resolve().is_relative_to((ROOT/'data/sealed').resolve())
    sealed.parent.mkdir(parents=True,exist_ok=True);assert not sealed.exists();shutil.move(str(OLD),str(sealed))
    save(OUT/'dataset_migration.json',dict(files=migration,public_images=470,dimension_images=220,ruler_images=10,
        sealed_local_remainder=rel(sealed),stage3_published=False,p03='NO_WRITES',image_bytes_unchanged=True))
    (DATA/'README.md').write_text('# Mechanical components v2 — Stage 2\n\n唯一正式数据目录。Train360、Validation80、Stage2 Test30，冻结划分不变。size_special/development154用于开发；regression_used66已被使用，不能作为新独立验证；仅8个实物。calibration/ruler_images含10张标尺，标定未获教师确认，不直接适用于Camo。Stage3的90张及真值不在本目录。\n\n图像/标签使用Git LFS，克隆后执行git lfs pull；实际远程上传和配额尚待push核实。GT位于annotations/及各public分区；预测程序只读取images和configs/expected_counts_*.json。manifests/source_sha256.csv记录迁移前后相同字节SHA，source_mapping.csv记录原始来源。原始数据集只读，未复制原始HEIC。\n',encoding='utf8')


def models():
    if (OUT/'model_promotion.json').exists():return
    release=ROOT/'models/release';versions=read(ROOT/'results/dataset_v2_baseline_comparison/model_versions.json')
    for model in ('baseline1','baseline2'):
        source=ROOT/'models'/(model+'_v2_candidate');target=release/model
        for p in source.iterdir():
            if p.is_file():copy_verified(p,target/p.name)
        for key,v in versions[model+'_new']['files'].items():assert sha(ROOT/key)==v['sha256']
    source=ROOT/'models/baseline3_v2_candidate';target=release/'baseline3'
    for name in ('best.pt','training_record.json'):copy_verified(source/name,target/name)
    detector=read(source/'detector.json');detector['weights']='models/release/baseline3/best.pt';detector['release_status']='FROZEN_STAGE2_DETECTOR'
    save(target/'detector.json',detector)
    v1=ROOT/'results/baseline3_v2_experiment/size_development_v1';v2=ROOT/'results/baseline3_v2_experiment/size_repair_v2'
    for name in ('selection.json','calibration.json'):copy_verified(v1/name,target/name)
    size=read(v2/'candidate.json');size.update(detector_config='models/release/baseline3/detector.json',
        selection_path='models/release/baseline3/selection.json',calibration_path='models/release/baseline3/calibration.json')
    size['foreground']['background_path']='datasets/mechanical_components_v2/public/train/images/G01.jpg'
    save(target/'size.json',size)
    entries={
        'baseline1':dict(version=versions['baseline1_new']['model_version'],output_capability='image_level',bridge=None,
            model_config=dict(baseline1_config='models/release/baseline1/config.json',baseline1_bundle='models/release/baseline1/baseline1.joblib',device='cpu'),
            scene_guard=False,fixed_counts=dict.fromkeys('12345',1),origin='results/dataset_v2_baseline_comparison/selection.json'),
        'baseline2':dict(version=versions['baseline2_new']['model_version'],output_capability='image_level',bridge=None,
            model_config=dict(baseline2_bundle='models/release/baseline2',device='cpu'),scene_guard=False,fixed_counts=dict.fromkeys('12345',1),
            origin='results/dataset_v2_baseline_comparison/selection.json'),
        'baseline3':dict(version='size_repair_v2 / '+detector['weights_sha256'],output_capability='object_level',
            bridge='src.models.baseline3.size_repaired:create_backend',model_config=dict(baseline3_mode='size_repaired_development',
                size_candidate_config='models/release/baseline3/size.json'),scene_guard=False,arbitrary_counts=True,
            origin='results/baseline3_v2_experiment/size_repair_v2/candidate_freeze.json',physical_acceptance='NOT_VERIFIED')}
    for model,entry in entries.items():entry['files']={rel(p):sha(p) for p in (release/model).iterdir() if p.is_file()}
    # Bind the actual accepted geometry/decision code and common reference order.
    shared=['config/inspection.json','config/p06_part_specs_candidate.json','src/models/baseline3/geometry_repair.py',
        'src/models/baseline3/size_repaired.py','src/models/baseline3/size_candidate.py','src/models/baseline3/candidate.py']
    registry=dict(schema='frozen-model-registry/v1',created_utc=datetime.now(timezone.utc).isoformat(),models=entries,
        reserved=dict(final=dict(status='NOT_READY',reason='No independent Stage3 improved model delivered')),
        shared_files={p:sha(ROOT/p) for p in shared},training='NOT_RUN',physical_acceptance='NOT_VERIFIED')
    save(ROOT/'config/model_registry.json',registry)
    save(OUT/'model_promotion.json',dict(registry='config/model_registry.json',registry_sha256=sha(ROOT/'config/model_registry.json'),
        entries=entries,weights_and_parameters_unchanged=True))


def main():
    sys.stdout.reconfigure(encoding='utf8',errors='replace')
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--phase',choices=['audit','datasets','models'],required=True);args=p.parse_args()
    OUT.mkdir(parents=True,exist_ok=True)
    state_path=ROOT/'task_state.json';state=read(state_path) if state_path.exists() else dict(task='P07 final Stage2 integration',phases={})
    record=dict(status='RUNNING',command=[sys.executable,*sys.argv],started_utc=datetime.now(timezone.utc).isoformat())
    state['phases'][args.phase]=record;save(state_path,state)
    try:globals()[args.phase]();record.update(status='COMPLETED',finished_utc=datetime.now(timezone.utc).isoformat())
    except Exception as error:record.update(status='ERROR',error=repr(error));raise
    finally:
        state=read(state_path);state['phases'][args.phase]=record;state['ready']=False
        state['next']='Continue P07 final integration; physical calibration/live/demo pending';save(state_path,state)
        (ROOT/'PROGRESS.md').write_text('# P07 final Stage 2 integration\n\n'+ '\n'.join(f"- {k}: {v['status']}" for k,v in state['phases'].items())+'\n\nState: task_state.json. No training/commit/push/merge. Stage3 excluded.\n',encoding='utf8')
    print(args.phase,'COMPLETED',flush=True)
if __name__=='__main__':main()
