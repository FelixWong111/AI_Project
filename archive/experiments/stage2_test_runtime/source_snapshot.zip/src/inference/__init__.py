"""Shared inference entrypoints."""
