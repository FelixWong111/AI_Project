"""Independent, resumable metrology development. Frozen YOLO/Test/P03 are read-only."""
from __future__ import annotations
import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from scripts.experiment_baseline3_v2 import save,load,csvrows,write_csv,digest,rel,update

EXP=ROOT/'results/baseline3_v2_experiment'
OUT=EXP/'size_development_v1'
DATA=ROOT/'data/mechanical_components_v2'
RUNTIME=ROOT/'outputs/size_development_v1'
TASKS=('size_v1_inventory','size_v1_rulers','size_v1_baseline','size_v1_tuning',
       'size_v1_holdout','size_v1_foreground','size_v1_public_validation','size_v1_acceptance')


def inventory():
    if (OUT/'inventory.json').exists():return
    import numpy as np
    from PIL import Image,ImageOps
    state=load(EXP/'task_state.json')
    for t in TASKS:state['tasks'].setdefault(t,dict(status='PENDING'))
    save(EXP/'task_state.json',state)
    request=Path('C:/Users/王以乐/.codex/attachments/16090135-a704-489f-83a3-58bfc610f6b5/已粘贴的文本.txt')
    OUT.mkdir(parents=True,exist_ok=True);(OUT/'request.txt').write_bytes(request.read_bytes())
    save(OUT/'human_confirmation.json',dict(recorded_at_utc=datetime.now(timezone.utc).isoformat(),
        source='Project owner/user explicit attached request',source_sha256=digest(request),
        one_physical_specimen_per_original_specification_folder=True,
        independent_arrangements_between_photographs=True,
        fixed_camera_for_rulers_dimensions_and_public_collection=True,
        scope='New 数据集 collection; does not assert Camo digital crop/FOV equivalence, caliper truth or instructor approval'))
    rows=csvrows(DATA/'manifests/dimension_manifest.csv')
    assert len(rows)==220
    folders=sorted({(ROOT/r['source_path']).parent for r in rows})
    assert len(folders)==8
    ids={p:f'DIM-SPECIMEN-{i+1:02d}' for i,p in enumerate(folders)}
    rng=np.random.default_rng(42);manifest=[];mapping=[]
    for folder in folders:
        items=sorted([r for r in rows if (ROOT/r['source_path']).parent==folder],key=lambda r:r['image_id'])
        actual={p.resolve() for p in folder.iterdir() if p.suffix.lower() in ('.jpg','.jpeg','.png','.heic')}
        assert actual=={(ROOT/r['source_path']).resolve() for r in items}
        chosen=set(rng.permutation(len(items))[:round(len(items)*.7)].tolist())
        for i,row in enumerate(items):
            p=ROOT/row['image_path'];raw=ROOT/row['source_path']
            image=Image.open(p);assert image.size==(int(row['width']),int(row['height']))
            source=Image.open(raw) if raw.suffix.lower()!='.heic' else None
            if source is None:
                sys.path.insert(0,str(ROOT/'.tools'));import pillow_heif;pillow_heif.register_heif_opener();source=Image.open(raw)
            normalized=ImageOps.exif_transpose(source).convert('RGB')
            assert normalized.size==image.size and np.array_equal(np.asarray(normalized),np.asarray(image.convert('RGB'))),raw
            orientation=source.getexif().get(274);source.close();image.close()
            cid=int(row['class_id']);label=folder.name
            family=1 if '螺丝' in label else 4 if '螺母' in label else 5
            manifest.append(dict(row,physical_sample_id=ids[folder],scene_id=row['image_id'].rsplit('.',1)[0],
                original_specification_folder=rel(folder),measurement_family=family,official_class_id=cid,
                experiment_split='development' if i in chosen else 'retained_scene_validation',
                source_sha256=digest(raw),derived_sha256=digest(p),exif_orientation=orientation,
                physical_truth='nominal folder label; not a caliper measurement'))
        mapping.append(dict(folder=rel(folder),physical_sample_id=ids[folder],photos=len(items),official_class_id=int(items[0]['class_id'])))
    write_csv(OUT/'dimension_manifest.csv',manifest)
    save(OUT/'inventory.json',dict(specimens=mapping,photos=len(manifest),physical_specimens=8,
        splits=dict(Counter(r['experiment_split'] for r in manifest)),seed=42,
        validation_scope='Different scenes of the same eight physical specimens, not unseen-specimen generalization',
        historical_use='Prior workspace records show conversion/inventory only for this collection; external unrecorded use remains unknown',
        selection_protocol='Measure existing body_profile first; finite segmentation/quality/range candidates on development only. Freeze before retained scenes. Public Train/Val only afterwards; no Test/Stage3.',
        protected={rel(p):digest(p) for p in [ROOT/'app.py',*ROOT.glob('config/*.json'),*ROOT.glob('models/baseline3_v2_candidate/*'),*ROOT.glob('src/p06*.py'),
            ROOT/'src/models/baseline3/candidate.py',EXP/'freeze.json',EXP/'model_selection.md'] if p.is_file()}))
    update('size_v1_inventory','COMPLETED',evidence='size_development_v1/inventory.json')


def rulers():
    if (OUT/'calibration.json').exists():return
    import cv2,numpy as np
    from src.models.baseline3.metrology import ruler_ticks,fit_metric_calibration,ruler_interval_errors,fit_radial_calibration,radial_interval_errors
    values=[];flat=[];summary=[]
    for row in csvrows(DATA/'calibration/ruler_manifest.csv'):
        im=cv2.imdecode(np.fromfile(ROOT/row['image_path'],np.uint8),cv2.IMREAD_COLOR)
        d=ruler_ticks(im);d.update(image_id=row['image_id'],source_path=row['source_path'],image_path=row['image_path'],
                                  image_sha256=digest(ROOT/row['image_path']),source_sha256=digest(ROOT/row['source_path']))
        major=max(d['phase_length_scores']);minor=float(np.median(d['phase_length_scores']))
        assert major/minor>1.4,'Centimeter/minor tick pattern not confirmed'
        values.append(d)
        for p in d['points']:
            flat.append(dict(image_id=row['image_id'],**p))
            color=(0,0,255) if p['relative_mm']%10==d['major_tick_phase'] else (0,180,0)
            cv2.circle(im,(round(p['x']),round(p['y'])),5,color,-1)
        im=cv2.resize(im,(756,1008));cv2.putText(im,f"{Path(row['image_id']).stem[-8:]} {d['px_per_mm']:.4f} px/mm",(20,35),cv2.FONT_HERSHEY_SIMPLEX,.6,(0,0,255),2)
        path=OUT/'rulers'/('ticks_'+Path(row['image_id']).stem+'.jpg');path.parent.mkdir(parents=True,exist_ok=True);cv2.imencode('.jpg',im)[1].tofile(path)
        summary.append({k:d[k] for k in ('image_id','px_per_mm','tick_count','span_mm','residual_rms_px','residual_p95_px')})
    models=[]
    for mode in ('global','anisotropic','affine','projective'):
        fit=fit_metric_calibration(values,mode=mode)
        fit['leave_one_photo_out']=[ruler_interval_errors(r,fit_metric_calibration(values[:i]+values[i+1:],mode=mode)['matrix_pixel_to_mm']) for i,r in enumerate(values)]
        fit['cv_mean_rms_mm']=float(np.mean([x['rms_error_mm'] for x in fit['leave_one_photo_out']]))
        models.append(fit)
    for order in (1,2):
        parameters=fit_radial_calibration(values,order=order)
        cv=[radial_interval_errors(r,fit_radial_calibration(values[:i]+values[i+1:],order=order)) for i,r in enumerate(values)]
        models.append(dict(mode=f'radial{order}',parameters=parameters,leave_one_photo_out=cv,cv_mean_rms_mm=float(np.mean([x['rms_error_mm'] for x in cv]))))
    best=min(models,key=lambda x:x['cv_mean_rms_mm'])
    # Prefer the simple global model unless a correction improves photo-held-out error by 20%.
    global_model=models[0];selected=best if best['cv_mean_rms_mm']<global_model['cv_mean_rms_mm']*.8 else global_model
    assert selected['mode']=='global','A non-global model needs explicit metric rectification wiring'
    scale=float(1/np.exp(selected['parameters'][0]));worst=max(x['p95_absolute_error_mm'] for x in selected['leave_one_photo_out'])
    calibration=dict(schema='ruler-scale-development/v1',status='IMAGE_RULER_FIT_WITH_PHOTO_CROSS_VALIDATION',
        capture_geometry_id='user-confirmed-fixed-new-collection-20261125',frame_size=[3024,4032],
        px_per_mm=[scale,scale],selected_model=selected['mode'],model_selection_rule='Leave-one-photo-out 10mm interval RMS; retain global unless correction improves >=20%',
        models=models,photo_scales=summary,total_detected_ticks=sum(x['tick_count'] for x in values),
        ruler_validation_worst_photo_p95_mm_per_10mm=worst,relative_conservative_scale_envelope=worst/10,
        independent_caliper_validation=False,instructor_approved=False,
        uncertainty_scope='Ruler interval/image-position consistency only; repeated overlapping intervals are not independent samples. No caliper MAE or height-parallax bound.',
        supported_input='Original fixed-collection 3024x4032 pixels; geometry runs on original-frame ROIs, not letterboxed network input',
        camo_transform='NOT_CONFIRMED: photo EXIF has 1.57mm ultrawide + digital zoom 2.5802; do not infer Camo field of view from resolution',
        height_difference='Ruler surface/part measurement planes may differ; distance and specimen heights are not recorded, so no invented parallax correction')
    save(OUT/'rulers/tick_fits.json',values);write_csv(OUT/'rulers/tick_points.csv',flat);write_csv(OUT/'rulers/photo_scales.csv',summary)
    save(OUT/'calibration.json',calibration)
    print('CALIBRATION',scale,selected['cv_mean_rms_mm'],worst,flush=True)
    update('size_v1_rulers','COMPLETED',evidence='size_development_v1/calibration.json',teacher_acceptance='PENDING')


def prepare_rois():
    path=OUT/'rois.json'
    if path.exists():return load(path)
    import cv2,numpy as np
    from scripts.experiment_baseline3_v2 import configure
    from src.models.baseline3.candidate import detector_factory
    from src.models.baseline1.features import load_image_bgr
    configure();cv2.setNumThreads(1)
    detector=detector_factory(model_id='baseline3',config={'config_path':ROOT/'models/baseline3_v2_candidate/detector.json'})
    records=[];folder=RUNTIME/'crops';folder.mkdir(parents=True,exist_ok=True)
    for row in csvrows(OUT/'dimension_manifest.csv'):
        im=load_image_bgr(str(ROOT/row['image_path']));obs=detector.infer(im,dict.fromkeys('12345',1))
        objects=sorted(obs['objects'],key=lambda o:-o['score']);method='frozen_yolo'
        if objects:
            obj=objects[0];box=[obj[k] for k in ('xmin','ymin','xmax','ymax')]
        else:
            # Experimental measurement ROI only, never a ground-truth annotation.
            from src.p06_geometry import silhouette,DEFAULT_PARAMETERS
            try:
                contour,_=silhouette(cv2.cvtColor(im,cv2.COLOR_BGR2GRAY),DEFAULT_PARAMETERS)
                x,y,w,h=cv2.boundingRect(contour);box=[x,y,x+w,y+h];method='foreground_measurement_roi_no_gt'
            except Exception as exc:
                records.append(dict(row,roi_error=str(exc),detector_objects=objects));continue
        x1,y1,x2,y2=box;pad=max(16,round(max(x2-x1,y2-y1)*.18))
        l,t=max(0,int(x1)-pad),max(0,int(y1)-pad);rr,b=min(im.shape[1],int(np.ceil(x2))+pad),min(im.shape[0],int(np.ceil(y2))+pad)
        crop=im[t:b,l:rr];dest=folder/row['image_id'];cv2.imencode('.png',crop)[1].tofile(dest)
        records.append(dict(row,crop_path=rel(dest),crop_xyxy=[l,t,rr,b],
            target_box=[x1-l,y1-t,x2-l,y2-t],roi_method=method,detector_objects=objects))
        if len(records)%40==0:print('ROI',len(records),'/220',flush=True)
    save(path,records);return records


def measure_one(job):
    row,parameters,targeted=job
    import cv2,numpy as np
    from src.p06_geometry import measure_object,DEFAULT_PARAMETERS
    if row.get('roi_error'):return dict(image_id=row['image_id'],status='UNMEASURABLE',reason=row['roi_error'],dimensions={})
    im=cv2.imdecode(np.fromfile(ROOT/row['crop_path'],np.uint8),cv2.IMREAD_COLOR)
    measured=measure_object(im,int(row['measurement_family']),load(OUT/'calibration.json')['px_per_mm'],
        dict(DEFAULT_PARAMETERS,**parameters),target_box=row['target_box'] if targeted else None)
    # Compact diagnostics retain numeric quality and definitions; large sampled
    # profiles/contours are kept only where a later failure overlay is needed.
    diag={k:v for k,v in measured['diagnostics'].items() if not isinstance(v,list)}
    return dict(image_id=row['image_id'],status=measured['status'],reason=measured['reason'],
                dimensions=measured['dimensions'],dimension_status=measured['dimension_status'],diagnostics=diag)


def baseline():
    if (OUT/'baseline_measurements.json').exists():return
    from concurrent.futures import ThreadPoolExecutor
    import cv2
    cv2.setNumThreads(1);rois=prepare_rois()
    with ThreadPoolExecutor(max_workers=4) as pool:results=list(pool.map(measure_one,[(r,{},False) for r in rois]))
    save(OUT/'baseline_measurements.json',results)
    summary=measurement_summary(rois,results);save(OUT/'baseline_summary.json',summary)
    print('BASELINE',json.dumps(summary,ensure_ascii=False),flush=True)
    update('size_v1_baseline','COMPLETED',evidence='size_development_v1/baseline_summary.json')


def measurement_summary(rows,results):
    import numpy as np
    paired={r['image_id']:r for r in results};report={}
    for sid in sorted({r['physical_sample_id'] for r in rows}):
        subset=[paired[r['image_id']] for r in rows if r['physical_sample_id']==sid]
        specs=next(r for r in rows if r['physical_sample_id']==sid)
        stats={}
        for key in sorted({k for r in subset for k in r['dimensions']}):
            nums=np.array([r['dimensions'][key]['mm_estimate'] for r in subset if key in r['dimensions']])
            stats[key]=dict(n=len(nums),mean=float(nums.mean()),median=float(np.median(nums)),std=float(nums.std()),
                           min=float(nums.min()),max=float(nums.max()),p05=float(np.percentile(nums,5)),p95=float(np.percentile(nums,95)))
        report[sid]=dict(specification=Path(specs['original_specification_folder']).name,images=len(subset),
            complete=sum(r['status']=='MEASURED_CANDIDATE' for r in subset),partial=sum(r['status']=='PARTIAL_CANDIDATE' for r in subset),
            failed=sum(r['status']=='UNMEASURABLE' for r in subset),reasons=dict(Counter(r['reason'] for r in subset if r['reason'])),dimensions=stats)
    return report


def tune():
    """Finite segmentation search on development scenes only; no holdout access."""
    if (OUT/'selection.json').exists():return
    from concurrent.futures import ThreadPoolExecutor
    import cv2,numpy as np
    cv2.setNumThreads(1)
    rows=[r for r in load(OUT/'rois.json') if r['experiment_split']=='development']
    assert len(rows)==154
    grid=[dict(background_offset=o,close_kernel=k,targeted=t)
          for o in (25,35,45) for k in (3,5) for t in (False,True)]
    plan=dict(seed=42,development_images=[r['image_id'] for r in rows],
        manifest_sha256=digest(OUT/'dimension_manifest.csv'),trials=grid,
        algorithm='Unchanged P06 body_profile/hexagon/ellipse geometry; ordinary silhouette parameters and existing target isolation only',
        selection='Per measurement family: maximize complete measurements excluding capped-nut incompatible geometry; tie: lowest mean normalized dimension spread; then earlier trial',
        acceptance='Per catalogue class and dimension: development min/max expanded by ruler worst-photo P95 relative scale envelope; provisional visible-image bands, not approved manufacturing tolerances',
        holdout='66 retained scenes not read during parameter selection; old fixed baseline precomputed but not inspected for tuning',
        highlight_mask='Not enabled; no new reflectance reconstruction or Stage 3 method')
    save(OUT/'search_plan.json',plan)
    trials=[]
    for i,trial in enumerate(grid):
        path=OUT/'tuning'/f'trial_{i:02d}.json'
        params={k:v for k,v in trial.items() if k!='targeted'}
        if path.exists():values=load(path)
        else:
            with ThreadPoolExecutor(max_workers=4) as pool:
                values=list(pool.map(measure_one,[(r,params,trial['targeted']) for r in rows]))
            save(path,values)
        index={v['image_id']:v for v in values};family={}
        for f in (1,4,5):
            subset=[r for r in rows if int(r['measurement_family'])==f and r['physical_sample_id']!='DIM-SPECIMEN-08']
            grouped=measurement_summary(subset,values)
            variability=[d['std']/d['mean'] for g in grouped.values() for d in g['dimensions'].values()]
            family[str(f)]=dict(complete=sum(index[r['image_id']]['status']=='MEASURED_CANDIDATE' for r in subset),
                total=len(subset),normalized_spread=float(np.mean(variability)) if variability else 999.)
        trials.append(dict(trial=i,parameters=trial,family=family))
        print('TUNE',i+1,'/12',family,flush=True)
    selected={};combined=[]
    for f in ('1','4','5'):
        best=min(trials,key=lambda t:(-t['family'][f]['complete'],t['family'][f]['normalized_spread'],t['trial']))
        selected[f]=best
        ids={r['image_id'] for r in rows if str(r['measurement_family'])==f}
        combined.extend(v for v in load(OUT/'tuning'/f"trial_{best['trial']:02d}.json") if v['image_id'] in ids)
    save(OUT/'development_measurements.json',combined)
    summary=measurement_summary(rows,combined);save(OUT/'development_summary.json',summary)
    envelope=load(OUT/'calibration.json')['relative_conservative_scale_envelope']
    bands={}
    for r in rows:
        cid=str(r['official_class_id'])
        if cid=='0' or cid in bands:continue
        spec=summary[r['physical_sample_id']]
        bands[cid]={k:dict(min_mm=d['min']*(1-envelope),max_mm=d['max']*(1+envelope),
                           observed_min=d['min'],observed_max=d['max'],n=d['n'])
                    for k,d in spec['dimensions'].items()}
    selection=dict(schema='size-development-selection/v1',selected=selected,bands=bands,
        calibration_sha256=digest(OUT/'calibration.json'),search_plan_sha256=digest(OUT/'search_plan.json'),
        development_predictions_sha256=digest(OUT/'development_measurements.json'),
        scope='Development candidate only; one physical specimen per specification; no independent specimen generalization',
        validated=False,instructor_approved=False,caliper_mae=None,
        nominal_specs_path='config/p06_part_specs_candidate.json',
        nominal_specification_warning='Supplier nominal dimensions are not caliper truth; empirical bands are not manufacturing tolerances')
    save(OUT/'tuning/trials.json',trials);save(OUT/'selection.json',selection)
    update('size_v1_tuning','COMPLETED',evidence='size_development_v1/selection.json',retained_scenes_used=False)


def holdout():
    if (OUT/'holdout_acceptance.json').exists():return
    from concurrent.futures import ThreadPoolExecutor
    import cv2
    from src.models.baseline3.size_candidate import size_conclusion
    cv2.setNumThreads(1);selection=load(OUT/'selection.json')
    rows=load(OUT/'rois.json');retained=[r for r in rows if r['experiment_split']=='retained_scene_validation']
    assert len(retained)==66
    jobs=[]
    for row in retained:
        p=selection['selected'][str(row['measurement_family'])]['parameters']
        jobs.append((row,{k:v for k,v in p.items() if k!='targeted'},p['targeted']))
    with ThreadPoolExecutor(max_workers=4) as pool:values=list(pool.map(measure_one,jobs))
    save(OUT/'retained_measurements.json',values)
    optimized=load(OUT/'development_measurements.json')+values
    save(OUT/'all_measurements.json',optimized)
    old=load(OUT/'baseline_measurements.json');cases=[]
    by_id={r['image_id']:r for r in rows}
    for version,data in (('baseline',old),('optimized',optimized)):
        for value in data:
            row=by_id[value['image_id']];cid=int(row['official_class_id'])
            # Stress test known anomaly against its catalogue counterpart, not
            # ground-truth-assisted production classification or relabelling.
            counterpart=cid or {'1':1,'4':4,'5':5}[str(row['measurement_family'])]
            outcome,details=size_conclusion(value,counterpart,selection['bands'])
            cases.append(dict(version=version,image_id=row['image_id'],physical_sample_id=row['physical_sample_id'],
                experiment_split=row['experiment_split'],official_class_id=cid,
                challenged_catalogue_class=counterpart,measurement_status=value['status'],
                conclusion=outcome,reason=value['reason'],details=';'.join(details),
                measurement_complete=value['status']=='MEASURED_CANDIDATE',
                contour_extracted=bool(value.get('diagnostics',{}).get('silhouette_method'))))
    write_csv(OUT/'specimen_decisions.csv',cases)
    summary={}
    for version in ('baseline','optimized'):
        summary[version]={}
        for split in ('development','retained_scene_validation'):
            subset=[r for r in cases if r['version']==version and r['experiment_split']==split]
            summary[version][split]={}
            for sid in sorted({r['physical_sample_id'] for r in subset}):
                group=[r for r in subset if r['physical_sample_id']==sid]
                summary[version][split][sid]=dict(n=len(group),measured=sum(r['measurement_complete'] for r in group),
                    contours=sum(r['contour_extracted'] for r in group),conclusions=dict(Counter(r['conclusion'] for r in group)))
    save(OUT/'holdout_acceptance.json',dict(selection_sha256=digest(OUT/'selection.json'),results=summary,
        no_parameter_updates_after_holdout=True,independent_specimens=False,
        caveat='Baseline and optimized use the same frozen empirical bands for paired comparison; original supplier nominal tolerance comparison is separate. Cap-nut failures are not size-confirmed rejection.'))
    for split in ('development','retained_scene_validation'):
        selected=[r for r in rows if r['experiment_split']==split]
        save(OUT/(split+'_distribution.json'),measurement_summary(selected,optimized))
    print('HOLDOUT',json.dumps(summary['optimized']['retained_scene_validation']),flush=True)
    update('size_v1_holdout','COMPLETED',evidence='size_development_v1/holdout_acceptance.json',independent_specimen_generalization=False)


def foreground():
    """Finite foreground trials on Train; never select using public Val."""
    target=OUT/'foreground_selection.json'
    if target.exists():return
    import cv2,numpy as np
    from src.models.baseline1.features import load_image_bgr
    from src.models.baseline3.candidate import detector_factory
    from src.models.baseline3.size_candidate import DevelopmentForeground
    from scripts.experiment_baseline3_v2 import configure
    from src.p06_foreground import DEFAULTS
    configure();cv2.setNumThreads(1)
    rows=[r for r in csvrows(DATA/'development/ground_truth_images.csv') if r['split']=='train']
    bg=next(r for r in rows if r['image_id']=='G01.jpg')
    assert all(int(bg[k])==0 for k in ('long_screw_count','thick_screw_count','thin_screw_count',
                                      'hex_nut_count','flat_washer_count','non_catalogue_count'))
    # Reproducible coverage of groups; these cases are training-only diagnostics.
    selected=[]
    for condition in sorted({r['condition'] for r in rows}):
        group=sorted([r for r in rows if r['condition']==condition],key=lambda r:r['image_id'])
        if group:selected.extend(group[::max(1,len(group)//6)][:6])
    if bg not in selected:selected.append(bg)
    config=dict(background_path=bg['image_path'],reference_id=bg['image_id'],
        capture_geometry_id=load(OUT/'calibration.json')['capture_geometry_id'])
    plan=dict(images=[r['image_id'] for r in selected],split='Train only',
        trials=[dict(threshold=t,minimum_area=a) for t in (20,30,40) for a in (10,30)],
        rule='Maximize fully associated training frames; tie: fewer unmatched foreground candidates; then lower threshold/area',
        preprocessing='Robust quadratic illumination fit outside detector boxes, 4 iterations, sample stride8, MAD trim4, 756x1008, fixed before evaluation',
        scope='Ordinary P06 background association; no Highlight-Mask/Stage3 metal reconstruction. Unmatched foreground is REVIEW, not fabricated ID0')
    save(OUT/'foreground_search_plan.json',plan)
    detector=detector_factory(model_id='baseline3',config={'config_path':ROOT/'models/baseline3_v2_candidate/detector.json'})
    samples=[]
    for row in selected:
        im=load_image_bgr(str(ROOT/row['image_path']));obs=detector.infer(im,dict.fromkeys('12345',1));samples.append((row,im,obs))
    background=load_image_bgr(str(ROOT/bg['image_path']));trials=[]
    for trial in plan['trials']:
        parameters=dict(DEFAULTS,difference_threshold=trial['threshold'],minimum_area=trial['minimum_area'])
        fg=DevelopmentForeground(background,dict(config,parameters=parameters));cases=[]
        for row,im,obs in samples:
            result=fg.process(im,obs)
            cases.append(dict(image_id=row['image_id'],counts_complete=result['counts_complete'],
                reason=result['reason'],unresolved=sum(g['class_id'] is None for g in result['candidates']),
                regions=len(result.get('regions',[])),foreground_fraction=result.get('foreground_fraction'),
                candidates=result['candidates'],background_fit_rms=result.get('background_fit_rms')))
        record=dict(parameters=parameters,complete=sum(r['counts_complete'] for r in cases),
                    unresolved=sum(r['unresolved'] for r in cases),cases=cases)
        trials.append(record);print('FOREGROUND',trial,record['complete'],'/',len(cases),record['unresolved'],flush=True)
    best=min(trials,key=lambda r:(-r['complete'],r['unresolved'],r['parameters']['difference_threshold'],r['parameters']['minimum_area']))
    config['parameters']=best['parameters'];save(OUT/'foreground_trials.json',trials)
    save(target,dict(selected=config,training_diagnostic_frames=len(selected),complete=best['complete'],
        complete_fraction=best['complete']/len(selected),heldout_unknown_object_validation=False,
        interpretation='Association completeness on training frames is not proof of arbitrary unknown-object recall'))
    candidate=dict(schema='size-candidate-config/v1',mode='size_development_candidate',
        detector_config='models/baseline3_v2_candidate/detector.json',selection_path=rel(OUT/'selection.json'),
        calibration_path=rel(OUT/'calibration.json'),foreground=config,
        release_status='DEVELOPMENT_ONLY_NOT_INSTRUCTOR_APPROVED',
        capture_geometry_assertion='Original fixed-collection images only; identical resolution alone does not validate lens, zoom, crop or Camo geometry',
        known_capture_limitations='Digital zoom varies; one Train frame uses wide camera. EXIF absent in 180 Train/Val JPEGs. Development bands tolerate observed variability, not a rigorous parallax bound.')
    save(OUT/'candidate.json',candidate)
    profile=load(EXP/'configs/new_full.json');profile.update(bridge='src.models.baseline3.size_candidate:create_backend')
    profile['model_config'].update(baseline3_mode='size_development_candidate',size_candidate_config=rel(OUT/'candidate.json'))
    save(OUT/'p07_profile.json',profile)
    frozen={}
    for path in (OUT/'candidate.json',OUT/'p07_profile.json',OUT/'selection.json',OUT/'calibration.json',
                 ROOT/'src/models/baseline3/size_candidate.py',ROOT/'src/models/baseline3/metrology.py'):
        frozen[rel(path)]=digest(path)
    save(OUT/'candidate_freeze.json',dict(files=frozen,heldout_public_validation_used_for_selection=False))
    print('CANDIDATE FROZEN',flush=True)


def validate():
    if (OUT/'public_comparison.json').exists():return
    import subprocess,os
    from scripts.experiment_baseline3_v2 import saved_run,configure,run_metrics,object_diagnostics
    from src.evaluator import evaluate
    configure()
    frozen=load(OUT/'candidate_freeze.json')
    assert all(digest(ROOT/p)==h for p,h in frozen['files'].items()),'Frozen candidate changed before comparison'
    original=load(EXP/'validation/runs.json')
    runs=dict(validation_raw=original['new_c0.35_n0.5'],validation_previous_full=original['new_full'])
    index=OUT/'public_runs.json'
    if index.exists():runs.update(load(index))
    root=OUT/'public_validation'
    run=saved_run(root,OUT/'p07_profile.json',EXP/'configs/validation.json')
    runs['validation_candidate']=rel(run);save(index,runs)
    # The P08 stage-config gate intentionally has no Train mode. Reuse its
    # prediction CLI, evaluator and object scorer with an explicit Train-only
    # truth view, without mislabelling Train as Validation or changing P08 code.
    images=[r for r in csvrows(DATA/'development/ground_truth_images.csv') if r['split']=='train']
    ids={r['image_id'] for r in images};assert len(ids)==360
    objects=[r for r in csvrows(DATA/'development/ground_truth_objects.csv') if r['image_id'] in ids]
    view=OUT/'public_train_truth';write_csv(view/'ground_truth_images.csv',images);write_csv(view/'ground_truth_objects.csv',objects)
    profiles=dict(raw=EXP/'configs/new_raw.json',previous_full=EXP/'configs/new_full.json',candidate=OUT/'p07_profile.json')
    for label,profile in profiles.items():
        destination=OUT/'public_train'/label;pred=destination/'predictions';ev=destination/'evaluation'
        if (ev/'object_observations.json').exists():
            runs['train_'+label]=rel(destination);save(index,runs);continue
        destination.mkdir(parents=True,exist_ok=True)
        command=[sys.executable,str(ROOT/'predict.py'),'--input_dir',str(DATA/'yolo/images/train'),
            '--model','baseline3','--output_dir',str(pred),'--counts_file',str(DATA/'configs/expected_counts_train.json'),
            '--config',str(profile),'--record-timing']
        command_record=dict(command=command,dataset=str(view),split='Train diagnostics only; no Test',
                            model_config_sha256=digest(profile),timing_excludes='image decode, weight load, export and GUI')
        if pred.exists():
            assert load(destination/'command.json')==command_record,'Partial run configuration changed'
            assert (pred/'diagnostics.json').exists(),'Partial prediction run; inspect before resuming'
        else:
            save(destination/'command.json',command_record)
            with (destination/'prediction.log').open('x',encoding='utf8') as log:
                code=subprocess.run(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,env=os.environ.copy()).returncode
            assert code==0,f'Train prediction failed: {destination}'
        if not (ev/'summary.json').exists():
            evaluate(view/'ground_truth_images.csv',view/'ground_truth_objects.csv',DATA/'configs/expected_counts_train.json',pred,ev)
        command=[sys.executable,str(ROOT/'p08_object_observations.py'),'--dataset',str(view),
                 '--predictions-dir',str(pred),'--output',str(ev/'object_observations.json')]
        with (destination/'object_observations.log').open('w',encoding='utf8') as log:
            assert subprocess.run(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT).returncode==0
        runs['train_'+label]=rel(destination);save(index,runs)
        print('PUBLIC TRAIN',label,'complete',flush=True)
    summaries={};table=[]
    for label,path in runs.items():
        run=ROOT/path;metrics=run_metrics(run);obs=load(run/'evaluation/object_observations.json')
        diagnostics=load(run/'predictions/diagnostics.json')['images']
        calls=sum(r['result'].get('inspection',{}).get('measurement_calls',0) for r in diagnostics)
        complete=sum(r['result'].get('inspection',{}).get('measurement_complete',0) for r in diagnostics)
        times=[float(r['processing_ms']) for r in csvrows(run/'predictions/timing.csv') if r['processing_ms']]
        import numpy as np
        summary=dict(image_level=metrics,object_level=obs,measurement_calls=calls,complete_measurements=complete,
            measurement_success_rate=complete/calls if calls else None,
            offline_processing_ms=dict(median=float(np.median(times)),p95=float(np.percentile(times,95)),
                                       mean=float(np.mean(times)),n=len(times)),source=path)
        summaries[label]=summary
        table.append(dict(mode=label,images=metrics['input_cases'],accuracy_all_inputs=metrics['all_input_correct_fraction'],
            accuracy_decided=metrics['completed_accuracy'],fail_precision=metrics['fail']['precision'],
            fail_recall_decided=metrics['fail']['recall'],fail_recall_all=metrics['fail']['recall_all_eligible'],
            fail_f1_decided=metrics['fail']['f1'],false_pass=metrics['false_pass']['count'],false_fail=metrics['false_fail']['count'],
            review=metrics['status_counts'].get('REVIEW',0),error=metrics['status_counts'].get('ERROR',0),
            coverage=metrics['eligible_coverage'],pass_outputs=metrics['status_counts'].get('PASS',0),
            five_class_vector_exact=obs['five_class_vector_exact'],measurement_calls=calls,
            measurement_success_rate=summary['measurement_success_rate'],
            median_offline_processing_ms=summary['offline_processing_ms']['median'],
            p95_offline_processing_ms=summary['offline_processing_ms']['p95']))
        write_csv(OUT/'failures'/(label+'_objects.csv'),object_diagnostics(run))
    raw={r['image_id']:r for r in csvrows(ROOT/runs['validation_raw']/'predictions/images.csv')}
    previous={r['image_id']:r for r in csvrows(ROOT/runs['validation_previous_full']/'predictions/images.csv')}
    candidate={r['image_id']:r for r in csvrows(ROOT/runs['validation_candidate']/'predictions/images.csv')}
    truth={r['image_id']:r for r in csvrows(DATA/'evaluation/validation/ground_truth_images.csv')}
    paired=[]
    for image in sorted(raw):
        gt=truth[image]['ground_truth_label'];a=raw[image]['status'];b=previous[image]['status'];c=candidate[image]['status']
        paired.append(dict(image_id=image,true_label=gt,raw_status=a,previous_full_status=b,candidate_status=c,
            regression_vs_raw=a==gt and c!=gt,regression_vs_previous=b==gt and c!=gt,
            recovered_pass=b=='REVIEW' and c=='PASS' and gt=='PASS'))
    write_csv(OUT/'public_comparison.csv',table);write_csv(OUT/'failures/validation_paired.csv',paired)
    save(OUT/'public_comparison.json',dict(scope='Public Train and reused/development Val only; no Stage2 Test or Stage3 images accessed',
        candidate_frozen_before_comparison=True,results=summaries,
        regression_cases=[r for r in paired if r['regression_vs_raw'] or r['regression_vs_previous']],
        official_size_mae='NOT_AVAILABLE: no independent caliper truth',live_latency='NOT_RUN'))
    print('COMPARISON',json.dumps(table),flush=True)
    update('size_v1_public_validation','COMPLETED',evidence='size_development_v1/public_comparison.json',formal_test='NOT_RERUN',stage3_images='NOT_ACCESSED')


def statistics():
    """Post-freeze descriptive statistics; never feed them back into selection."""
    import math,numpy as np
    rows=load(OUT/'rois.json');metadata={r['image_id']:r for r in rows};records=[];positions=[]
    specs={str(s['class_id']):s for s in load(ROOT/'config/p06_part_specs_candidate.json')['items']}
    nominal_cases=[]
    for version,filename in (('baseline','baseline_measurements.json'),('optimized','all_measurements.json')):
        values=load(OUT/filename)
        for v in values:
            row=metadata[v['image_id']];cid=str(row['official_class_id']);checks=[]
            if cid!='0':
                for name,spec in specs[cid]['dimensions'].items():
                    if name in v['dimensions']:
                        mm=v['dimensions'][name]['mm_estimate'];checks.append(abs(mm-spec['reference_mm'])<=spec['provisional_allowance_mm'])
                    else:checks.append(None)
                state='OUTSIDE_SUPPLIER_PROVISIONAL_ALLOWANCE' if False in checks else 'WITHIN_SUPPLIER_PROVISIONAL_ALLOWANCE' if checks and None not in checks else 'UNMEASURABLE'
                nominal_cases.append(dict(version=version,image_id=v['image_id'],physical_sample_id=row['physical_sample_id'],
                    split=row['experiment_split'],conclusion=state,
                    caveat='Supplier nominal and user-proposed allowance; not caliper truth or instructor-confirmed manufacturing tolerance'))
        for sid in sorted({r['physical_sample_id'] for r in rows}):
            for split in ('development','retained_scene_validation','all'):
                subset=[v for v in values if metadata[v['image_id']]['physical_sample_id']==sid and
                        (split=='all' or metadata[v['image_id']]['experiment_split']==split)]
                for name in sorted({k for v in subset for k in v['dimensions']}):
                    for unit,field in (('px','pixels'),('mm_provisional','mm_estimate')):
                        a=np.array([v['dimensions'][name][field] for v in subset if name in v['dimensions']])
                        records.append(dict(version=version,physical_sample_id=sid,split=split,dimension=name,unit=unit,
                            n=len(a),mean=float(a.mean()),median=float(np.median(a)),std=float(a.std()),
                            min=float(a.min()),max=float(a.max()),p05=float(np.percentile(a,5)),p95=float(np.percentile(a,95))))
        if version=='optimized':
            for v in values:
                row=metadata[v['image_id']];l,t,r,b=row.get('crop_xyxy',[0,0,0,0])
                for name,dim in v['dimensions'].items():
                    a,c=np.array(dim['line_xy']);angle=float(math.degrees(math.atan2(*(c-a)[::-1]))%180)
                    positions.append(dict(image_id=v['image_id'],physical_sample_id=row['physical_sample_id'],split=row['experiment_split'],
                        dimension=name,pixels=dim['pixels'],mm_provisional=dim['mm_estimate'],angle_deg=angle,
                        orientation_bin=int(angle//30)*30,x_fraction=(l+r)/2/3024,y_fraction=(t+b)/2/4032,
                        quadrant=('left' if (l+r)/2<1512 else 'right')+'_'+('top' if (t+b)/2<2016 else 'bottom')))
    write_csv(OUT/'dimension_statistics.csv',records);write_csv(OUT/'measurement_positions.csv',positions)
    write_csv(OUT/'supplier_nominal_comparison.csv',nominal_cases)
    grouped=[]
    for sid,name in sorted({(r['physical_sample_id'],r['dimension']) for r in positions}):
        for field in ('quadrant','orientation_bin'):
            for value in sorted({r[field] for r in positions if r['physical_sample_id']==sid and r['dimension']==name}):
                a=np.array([r['mm_provisional'] for r in positions if r['physical_sample_id']==sid and r['dimension']==name and r[field]==value])
                grouped.append(dict(physical_sample_id=sid,dimension=name,group_by=field,group=value,n=len(a),
                    mean_mm=float(a.mean()),std_mm=float(a.std()),min_mm=float(a.min()),max_mm=float(a.max()),
                    caveat='Descriptive same-specimen scene stability, not caliper accuracy or independent-object generalization'))
    write_csv(OUT/'position_orientation_stability.csv',grouped)
    decisions=csvrows(OUT/'specimen_decisions.csv');summary=[]
    for version in ('baseline','optimized'):
        for sid in sorted({r['physical_sample_id'] for r in decisions}):
            group=[r for r in decisions if r['version']==version and r['physical_sample_id']==sid]
            counts=Counter(r['conclusion'] for r in group)
            complete=sum(r['measurement_complete']=='True' for r in group)
            summary.append(dict(version=version,physical_sample_id=sid,n=len(group),
                contour_extracted=sum(r['contour_extracted']=='True' for r in group),complete=complete,
                measurement_success_rate=complete/len(group),measurement_failure_rate=1-complete/len(group),
                accepted=counts['WITHIN_DEVELOPMENT_BAND'],rejected=counts['OUTSIDE_DEVELOPMENT_BAND'],
                unmeasurable=counts['UNMEASURABLE']))
    write_csv(OUT/'measurement_summary.csv',summary)


def check():
    """Accept software/development evidence without claiming physical Stage 2 pass."""
    if (OUT/'final_acceptance.json').exists():return
    import cv2,numpy as np,time
    from types import SimpleNamespace
    from src.p07_bridge import load_backend,validate_result
    from src.models.baseline1.features import load_image_bgr
    from src.p07_ui import InferenceWorker
    from src.p07_dashboard import render
    from scripts.experiment_baseline3_v2 import configure
    configure();cv2.setNumThreads(1)
    software=software_tests();assert software['errors']==software['failures']==0
    protected=dict(load(EXP/'old_baseline3.json')['protected_sha256'])
    protected.update(load(OUT/'inventory.json')['protected'])
    # Include old frozen prediction evidence without reopening Test images/GT.
    freeze=load(EXP/'freeze.json')
    for name,sha in freeze['files'].items():
        if not name.startswith('data/') and not name.startswith('P03'):
            protected[name]=sha
    changed=[p for p,h in protected.items() if digest(ROOT/p)!=h];assert not changed,changed
    assert all(digest(ROOT/p)==h for p,h in load(OUT/'candidate_freeze.json')['files'].items())
    profile=load(OUT/'p07_profile.json');backend=load_backend('real','baseline3',profile)
    runs=load(OUT/'public_runs.json');run=ROOT/runs['validation_candidate']
    diagnostics=load(run/'predictions/diagnostics.json')['images']
    cases=[]
    # Compare actual GUI worker and batch outputs for one PASS, FAIL and REVIEW.
    for status in ('PASS','FAIL','REVIEW'):
        row=next(r for r in diagnostics if r['result']['status']==status)
        frame=load_image_bgr(str(DATA/'yolo/images/val'/row['image_id']))
        packet=SimpleNamespace(image=frame,frame_id=1,available_at=time.perf_counter(),capture_fps=0,source='validation-image')
        worker=InferenceWorker();assert worker.submit(backend,'baseline3',packet,row['expected_counts'],'pass',1)
        worker.future.result(timeout=90);result=worker.poll()['result'];worker.close()
        for key in ('objects','counts','status','predicted_label','prediction_score'):
            assert result[key]==row['result'][key],(row['image_id'],key)
        changed=backend.rejudge(result,dict.fromkeys('12345',0));restored=backend.rejudge(changed,row['expected_counts'])
        assert result['objects']==changed['objects']==restored['objects'] and result['counts']==changed['counts']
        assert restored['status']==result['status']
        canvas=render(packet,result,row['expected_counts'],'baseline3','real',dict(show_diagnostics=True,diagnostic_page=0))
        image_path=OUT/'diagnostic_views'/(status.lower()+'.jpg');image_path.parent.mkdir(exist_ok=True)
        cv2.imencode('.jpg',canvas)[1].tofile(image_path)
        cases.append(dict(image_id=row['image_id'],status=status,gui_worker_equals_batch=True,counts_change_preserves_objects=True,diagnostic_rendered=rel(image_path)))
    # Video decoding and camera-sized frames feed the same backend. No physical
    # camera is opened and no synthetic data are called live performance.
    image=load_image_bgr(str(DATA/'yolo/images/val'/cases[0]['image_id']))
    video=RUNTIME/'compatibility.avi';writer=cv2.VideoWriter(str(video),cv2.VideoWriter_fourcc(*'MJPG'),5.,(3024,4032))
    assert writer.isOpened();writer.write(image);writer.release()
    capture=cv2.VideoCapture(str(video))
    try:
        ok,decoded=capture.read();assert ok
        video_result=validate_result(backend.infer(decoded,dict.fromkeys('12345',1)),'baseline3',decoded.shape)
        assert video_result['inspection']['measurement_calls']>0
    finally:capture.release()
    unsupported=cv2.resize(image,(1280,720));result=backend.infer(unsupported,dict.fromkeys('12345',1))
    assert not result['inspection']['calibration_compatible'] and result['status']!='PASS'
    assert result['inspection']['measurement_calls']==0
    regression=[]
    defaults=load(ROOT/'config/p07.json')
    for model in ('baseline1','baseline2'):
        native=load_backend('real',model,defaults);out=native.infer(image,dict.fromkeys('12345',1))
        assert out['status'] in ('PASS','FAIL','REVIEW') and not native.is_mock
        unsupported=native.infer(image,dict.fromkeys('12345',0));assert unsupported['status']=='UNSUPPORTED_COUNTS'
        regression.append(dict(model=model,real_model_loaded=True,fixed_order_status=out['status'],
            variable_order_status=unsupported['status'],
            protected_model_artifacts={p:h for p,h in protected.items() if p.startswith(f'models/{model}/')},
            scope='Functional execution and fixed-order restriction only; not a new accuracy evaluation'))
    statistics()
    acceptance=dict(software_tests=software,protected_files_checked=len(protected),protected_hashes_match=True,
        protected_manifest=protected,gui_batch_cases=cases,video_measurement_calls=video_result['inspection']['measurement_calls'],
        unsupported_camo_frame_produces_no_physical_measurement=True,baseline1_baseline2_regression=regression,
        formal_physical_acceptance='NOT_PASSED',instructor_approval=False,independent_caliper_mae=None,
        stage2_test='NOT_RERUN',stage3_images_and_dedicated_truth='NOT_ACCESSED',physical_camera='NOT_RUN',
        shared_manifest_metadata='Initial shared index read to filter Train/Val; no excluded partition rows used for inference, selection or evaluation; later code uses development-only CSV',
        app_and_default_configs='UNCHANGED',p03='READ_ONLY_NO_WRITES',commit_push_merge=False)
    save(OUT/'final_acceptance.json',acceptance)
    update('size_v1_acceptance','COMPLETED',evidence='size_development_v1/final_acceptance.json',
           scope='Software integration/development diagnostics only',physical_stage2='PENDING_NOT_PASSED')
    print('FINAL ACCEPTANCE',len(protected),'protected files;',software['run'],'tests passed',flush=True)


def report():
    """Chinese development notes, not a replacement for P08's formal report."""
    if not (OUT/'final_acceptance.json').exists():return
    inventory_data=load(OUT/'inventory.json');cal=load(OUT/'calibration.json');selection=load(OUT/'selection.json')
    comparison=load(OUT/'public_comparison.json');acceptance=load(OUT/'final_acceptance.json')
    decisions=csvrows(OUT/'specimen_decisions.csv');stats=csvrows(OUT/'dimension_statistics.csv')
    def pct(n):return f'{100*float(n):.2f}%'
    lines=['# Baseline3 尺寸开发候选 v1：实际结果与使用限制','',
        '结论：已完成真实尺子刻度拟合、220张专项测量、有限参数选择、保留场景检查、Train/Val完整管线比较和P07软件接入。候选恢复了一部分正常工单PASS，但出现正常件误拒绝、较多REVIEW和明显耗时增加，**不建议替换默认配置，完整Stage 2物理验收尚未通过**。','',
        '本记录只说明本次开发；不替P08撰写正式报告。没有重新训练或改变YOLO置信度/NMS，没有重跑Stage 2 Test，没有打开Stage 3图像或专用标注/评价文件，也没有用其数据训练、选参或评价。','',
        '## 1. 数据、人工确认及实验边界','',
        '`human_confirmation.json`保存本次用户确认及原文SHA。原始规格文件夹中每夹一个实物，不同照片不同摆放场景；固定机位确认不等于镜头、数字变焦和Camo视野完全相同。','',
        '共220张、8个实物；seed=42分为154张开发和66张保留场景。保留场景与开发集共享实物，不是独立实物泛化。原始HEIC与派生PNG逐张做EXIF方向转换后的RGB像素比对，220/220一致。','',
        '原冻结P06算法的固定基线曾一次性预计算220张；参数选择只读取154张开发输出，66张基线输出没有用于选参。优化后的66张测量在尺寸参数冻结后运行。未记录的外部历史使用情况UNKNOWN。','',
        '读取边界披露：初始公共目录/EXIF检查及前景开发曾读取统一dataset_manifest.csv来过滤Train/Val，该公共索引也列出封存分区元数据；封存行没有进入图像读取、选参或评价。后续代码已改用仅含440张Train/Val的development/ground_truth_images.csv，避免再次读取混合索引。严格意义上不能声称连保留集索引元数据都未曾读取。','',
        '| 实物编号 | 原始规格目录 | 官方ID | 张数 | 开发/保留 |','|---|---|---:|---:|---:|']
    for s in inventory_data['specimens']:
        n=s['photos'];lines.append(f"| {s['physical_sample_id']} | {Path(s['folder']).name} | {s['official_class_id']} | {n} | {round(n*.7)}/{n-round(n*.7)} |")
    lines+=['','## 2. 十张尺子实际标定','',
        '通过刻度方向、共同基线、灰度剖面线中心、长短刻度周期提取真实刻度。以图片中cm标记及每cm的10个小间隔复核1mm间距；坐标为相对毫米刻度，未猜测绝对零点。红色为厘米长刻度、绿色为毫米刻度；原图路径/哈希保存在清单中，未复制原始数据。','',
        '| 原始照片后缀 | px/mm | 刻度数 | 跨度mm | 线性残差RMS px | P95绝对残差 px |','|---|---:|---:|---:|---:|---:|']
    for r in csvrows(OUT/'rulers/photo_scales.csv'):
        lines.append(f"| {Path(r['image_id']).stem[-8:]} | {float(r['px_per_mm']):.4f} | {r['tick_count']} | {r['span_mm']} | {float(r['residual_rms_px']):.3f} | {float(r['residual_p95_px']):.3f} |")
    lines+=['',f"共{cal['total_detected_ticks']}个识别刻度。选用全局尺度 **{cal['px_per_mm'][0]:.6f} px/mm**。逐照片留一验证的10mm间隔平均RMS误差 **{cal['models'][0]['cv_mean_rms_mm']:.4f}mm**；最差照片P95绝对间隔误差 **{cal['ruler_validation_worst_photo_p95_mm_per_10mm']:.4f}mm/10mm**，对应{pct(cal['relative_conservative_scale_envelope'])}的保守位置尺度包络。它不是95%置信区间，也不是零件测量误差界。",'',
        '| 尺度模型 | 逐照片留一10mm间隔平均RMS mm |','|---|---:|']
    for m in cal['models']:lines.append(f"| {m['mode']} | {m['cv_mean_rms_mm']:.4f} |")
    lines+=['',
        '水平、垂直、斜向尺子都参加拟合。边缘/斜向及单图不同区段存在非均匀尺度变化；仿射、透视、径向模型的留一误差没有优于全局模型，未采用更复杂修正。重叠10mm区间不是独立样本，模型比较也不是外部物理验收。','',
        'EXIF：尺子均为iPhone 13 Pro Max 1.57mm超广角、数字变焦2.5802。220张专项照片同镜头，但数字变焦约2.5033–2.6341；Train/Val共440张中180张EXIF缺失，Train的H032.jpg为5.7mm镜头/1.3114变焦，必须视作物理尺度不兼容风险。`capture_exif_audit.json`保留逐图结果。该证据不能被“固定机位”覆盖。','',
        '适用条件：原始3024×4032照片，测量在原图ROI中进行。YOLO的640 letterbox只用于检测；输出框已经回到原始像素。1280×720 Camo输入会被标为尺度不兼容、零次毫米测量、非PASS。不得直接按分辨率比值换算Camo；即使分辨率相同，镜头/视野/裁剪仍需确认。','',
        '尺子平面与零件测量面有高度差风险；现有资料没有工作距离及实物高度，未伪造视差校正或误差界。当前所有mm均为provisional。','',
        '## 3. 参数选择与测量结果','',
        '完整计划`search_plan.json`在选参前写入：12次有限组合，background_offset=25/35/45、close_kernel=3/5、targeted=false/true；仅选分割及既有目标隔离参数，不修改P06核心几何实现。按对应家族完整测量数优先、再按规格内归一化波动选参。盖型螺母不适合普通六角拟合，不用其失败数驱动放松六角质量条件。','',
        '选中参数：'+json.dumps({k:v['parameters'] for k,v in selection['selected'].items()},ensure_ascii=False)+'。螺丝继续body_profile，螺母平行对边，垫圈内外轮廓椭圆；未启用Highlight-Mask、反光重建或Stage 3专用方法。','',
        '下表测量单位为provisional mm；括号为P05–P95，完整均值、中位数、标准差、极值、分位数及像素统计见`dimension_statistics.csv`。位置/姿态统计见`measurement_positions.csv`和`position_orientation_stability.csv`。','',
        '| 实物 | 优化后完整测量/总数 | 主要测量中位数（P05–P95）mm |','|---|---:|---|']
    for s in inventory_data['specimens']:
        sid=s['physical_sample_id'];z=[r for r in decisions if r['version']=='optimized' and r['physical_sample_id']==sid]
        complete=sum(r['measurement_complete']=='True' for r in z)
        fields=[r for r in stats if r['version']=='optimized' and r['physical_sample_id']==sid and r['split']=='all' and r['unit']=='mm_provisional']
        description='；'.join(f"{r['dimension']}: {float(r['median']):.2f} ({float(r['p05']):.2f}–{float(r['p95']):.2f})" for r in fields) or '普通六角对边测量失败；不得伪造尺寸'
        lines.append(f"| {sid} | {complete}/{len(z)} | {description} |")
    lines+=['','| 版本/场景 | 完整测量 | 正常件通过 | 异常规格尺寸拒识 |','|---|---:|---:|---:|']
    for version in ('baseline','optimized'):
        for split in ('development','retained_scene_validation','all'):
            z=[r for r in decisions if r['version']==version and (split=='all' or r['experiment_split']==split)]
            normal=[r for r in z if r['official_class_id']!='0'];abnormal=[r for r in z if r['official_class_id']=='0']
            complete=sum(r['measurement_complete']=='True' for r in z);passed=sum(r['conclusion']=='WITHIN_DEVELOPMENT_BAND' for r in normal)
            rejected=sum(r['conclusion']=='OUTSIDE_DEVELOPMENT_BAND' for r in abnormal)
            lines.append(f"| {version} / {split} | {complete}/{len(z)} ({pct(complete/len(z))}) | {passed}/{len(normal)} ({pct(passed/len(normal))}) | {rejected}/{len(abnormal)} ({pct(rejected/len(abnormal))}) |")
    lines+=['',
        '上述配对比较对两种算法使用同一组冻结开发接受范围，从而单独观察分割/隔离改变。原供应商标称值±历史用户候选允许量的比较另存`supplier_nominal_comparison.csv`，不能把换接受范围产生的收益全部归因于测量算法改善。','',
        '优化后正常件总通过92/100；80个可用异常长螺丝/小垫片场景中69个尺寸拒识、11个不可测，无异常件在该对应家族挑战中被接受。40张盖型螺母均不可按普通六角对边可靠测量，只能算不可测，不能算尺寸拒识；真实管线中其已学到的YOLO ID0仍强制FAIL。保留场景中正常件27/30通过、1/30误拒绝、2/30不可测；不可将这些照片称为新的独立实物。','',
        '专项测量实验根据已知文件夹规格选择对应几何方法，并把异常长螺丝/小垫片/盖型螺母分别作为长螺丝/垫圈/普通螺母家族挑战。这是有标注的离线方法诊断，69/120不是生产管线新增ID0检测率。生产推理不读取文件名或目录真值，只根据真实YOLO类别选择方法；YOLO已经输出ID0时直接FAIL，不借真值补算类别。逐规格轮廓成功数、测量失败率及接受/拒识/不可测数见measurement_summary.csv。','',
        '原问题：校准路径/分辨率及物理验收门禁使原完整流程测量次数为0；P06垫圈容易出现多片轮廓及孔歧义；螺丝头身边界/反光会使有效长度偏短；普通六角算法无法测盖型螺母。普通螺母算法只测对边，不提供可靠螺纹内孔尺寸。','',
        '## 4. 标称值、候选范围与真实物理验收','',
        'Project Manual要求尺寸/规格核验及教师确认的容差，未给出各类统一数值容差。原供应商参考/用户候选允许量保留：ID1 L25±1、D4±0.3；ID2 L10±1、D5±0.3；ID3 L10±1、D4±0.3；ID4对边7±0.5；ID5外径15±0.75、内径5±0.5mm。这些不是已经教师批准的制造公差，也不是卡尺实测。','',
        '开发候选范围仅由154张开发场景中正常实物可见几何的最小/最大值，加尺子位置尺度包络得到。保留场景/公共Val未用于调宽范围。它适合初步规格区分，不应被解释成物理制造验收标准；例如M5螺杆直径范围较宽，不能据此保证拒绝所有未见规格。所有旧validated=false及教师确认记录未修改。','',
        '| 类别 | 可见测量量 | 候选范围mm |','|---|---|---:|']
    for cid,bands in sorted(selection['bands'].items()):
        for key,value in bands.items():lines.append(f"| {cid} | {key} | {value['min_mm']:.3f}–{value['max_mm']:.3f} |")
    lines+=['','## 5. 公共Train/Val真实完整系统对照','',
        '所有工单固定[1,1,1,1,1]。Train为训练样本诊断；Val已用于YOLO选择，本次只用于候选冻结后的开发验证，不能当成正式Test。原Val raw/previous_full输出直接复用，未重复推理；Train三个模式均真实运行。','',
        'Accuracy(All)的分母包括REVIEW/ERROR；Accuracy(Decided)只统计PASS/FAIL，必须同时看Coverage。FAIL为positive；REVIEW没有当FAIL或算正确。','',
        '| 数据/模式 | Accuracy All | Accuracy Decided | FAIL P/R/F1 | False PASS/FAIL | REVIEW | Coverage | PASS | 测量成功/调用 | 中位/P95 ms |','|---|---:|---:|---|---:|---:|---:|---:|---:|---:|']
    for name,s in comparison['results'].items():
        m=s['image_level'];f=m['fail'];t=s['offline_processing_ms']
        lines.append(f"| {name} | {pct(m['all_input_correct_fraction'])} | {pct(m['completed_accuracy'])} | {pct(f['precision'])}/{pct(f['recall'])}/{pct(f['f1'])} | {m['false_pass']['count']}/{m['false_fail']['count']} | {m['status_counts'].get('REVIEW',0)} | {pct(m['eligible_coverage'])} | {m['status_counts'].get('PASS',0)} | {s['complete_measurements']}/{s['measurement_calls']} | {t['median']:.1f}/{t['p95']:.1f} |")
    lines+=['',
        '离线计时从已解码图像进入统一Adapter起，到预处理/YOLO/几何/前景/数量及业务判定、结果校验及GPU同步完成；不含模型加载、解码、日志导出、手机曝光、Camo传输、GUI。Val raw/previous_full复用较早运行的计时，各运行的CPU线程负载/并发状态并未做受控配对；不能把这张耗时表当作严格加速比或实机≥20新帧实验。','',
        'Val恢复7张正常PASS，但新增5张工单误拒绝（False FAIL从1到6），27张正常场景REVIEW。正常目标误改ID0使五类计数向量完全正确率由95.00%降为78.75%。原始YOLO框和原类别保留在每个对象detector_class_id中，最终class_id、counts和框对应关系一致，工单变化只重新判定。','',
        'Val的6个False FAIL：A088、H005、H018、H020、H039、H040。H005是原YOLO已有错误；A088的正常M5被P06估成2.63mm直径，H018/H020约4.53mm、H040约4.50mm低于候选下限；H039/H040正常螺母约6.26/6.28mm低于候选下限。这说明几何质量门禁与单件到公共多件场景的迁移仍有问题，不能靠事后调宽Val范围隐藏。','',
        '| Val模式/ID | GT目标 | TP/FP/FN | Precision | Recall | Count MAE |','|---|---:|---:|---:|---:|---:|']
    for mode in ('validation_raw','validation_previous_full','validation_candidate'):
        for cid,c in comparison['results'][mode]['object_level']['classes'].items():
            lines.append(f"| {mode}/{cid} | {c['support']} | {c['tp']}/{c['fp']}/{c['fn']} | {pct(c['precision'])} | {pct(c['recall'])} | {c['count_mae']:.4f} |")
    lines+=['',
        '候选Val的ID0 TP25、FP19、FN0；原raw为TP25、FP1、FN0，新增18个正常目标误拒绝。该计数包括REVIEW图上的目标，不代表所有未知件拒识已通过。全部对象级错误和逐图退步在`failures/`保留。','',
        '## 6. 实际调用链、配置与判定','',
        '`app.py / predict.py → src.p07_bridge.load_backend → ObjectBackend → src.models.baseline3.size_candidate:create_backend → epoch69冻结YOLO → 原图ROI → P06 measure_object → 开发尺寸范围 → P06前景关联（光照校正后）→ 计数/工单/状态 → 公共输出及诊断。`','',
        'PASS：数量一致、无ID0、所有目录目标测量完整且在冻结开发范围内、前景关联完整、尺度输入条件满足。该PASS始终带DEVELOPMENT CANDIDATE及provisional标记，不是正式物理验收通过。','',
        'FAIL：检测ID0、开发尺寸规则拒识为ID0，或已观测计数不符；已知FAIL优先于其他测量不确定。REVIEW：数量匹配但存在不可测、尺度不兼容或未解析前景等真实不确定。ERROR：配置/文件/程序异常，经P07公共错误路径报告，不回退count-only或Mock。','',
        '前景有限6组合只用19张Train照片，选中threshold40、min_area30（756×1008诊断像素）；7/19关联完整。其余分片、粘连、未匹配前景导致REVIEW。前景候选不被无依据直接标成ID0；未知物体物理验证未完成。','',
        '新配置独立位于本目录`candidate.json`、`selection.json`、`calibration.json`、`p07_profile.json`和`candidate_freeze.json`。未覆盖旧生产配置；切回原启动命令即可回滚。GUI点击Sizes/Reasons或D查看测量值、候选参考、校准及失败原因，始终显示provisional。','',
        '## 7. 软件验收及Stage 2矩阵','',
        f"{acceptance['software_tests']['run']}项初始相关软件测试通过；随后补充UI显示及旧界面回归共11项（其中6项为复跑），累计91个不同用例，0失败/错误。{acceptance['protected_files_checked']}个旧模型/配置/源码/实验证据SHA一致；Baseline1/2真实加载、默认工单及UNSUPPORTED_COUNTS执行复核通过，只是功能检查，不是新的性能评价。所用单张Val场景的B1/B2实际输出分别为FAIL/PASS，保留原始结果；没有重写旧验证成绩。真实GUI worker与Batch在PASS/FAIL/REVIEW各1图一致；工单重判保留对象、尺寸、计数；视频解码实际调用几何；1280×720输入停止毫米测量。实机摄像头未运行。",'',
        '| 项目 | 结果 | 证据/未完成事项 |','|---|---|---|',
        '| 原始冻结YOLO、计数、已学ID0 | PASS（软件与Val范围） | 权重/阈值不变；不是未见未知件保证 |',
        '| 十张尺子刻度与尺度拟合 | PASS（开发图像标定） | 1019刻度；位置残差、镜头/变焦风险保留 |',
        '| 实际尺寸方法接入 | PASS（软件） | Val378次调用；305次完整 |',
        '| 同8实物保留场景测量 | PARTIAL | 正常27/30通过；2不可测、1误拒绝 |',
        '| 错规格定位/ID0/强制FAIL | PARTIAL | 可测异常螺丝/小垫片可拒识；正常件也误拒，盖型测量未完成 |',
        '| 任意未见non-catalogue与前景完整性 | NOT_PASSED | 未匹配前景只能REVIEW；缺独立物理验收 |',
        '| 任意合法工单/重判一致性 | PASS（软件） | 不影响原框、类别、尺寸和实际计数 |',
        '| 教师确认的公差及测量误差界 | PENDING | 没有确认记录，不把false改true |',
        '| 卡尺精度、视差、Camo尺度迁移 | NOT_VALIDATED | 不能计算可信零件MAE；不能按分辨率套尺度 |',
        '| 更新后完整系统独立Test | NOT_RUN | 旧Test不重用；需要新独立证据 |',
        '| ≥20新采集实机帧延迟 | NOT_RUN | 现有结果是离线处理耗时 |',
        '| 完整Stage 2物理合规 | NOT_PASSED | 开发成功接入不等于课程最终验收通过 |','',
        '## 8. 最小人工补充与后续修复','',
        '1. 对这8个实物各记录真实卡尺值：螺丝头下有效长度及螺杆直径；普通螺母对边；垫圈外/内径；异常件相应尺寸及盖型结构。标称规格不替代这些实测值。','2. 记录尺子平面到测量面高度差、实际工作距离，确认误差影响；没有数据时继续标provisional。',
        '3. 在实际Camo镜头/数字变焦/分辨率下拍同一测量平面尺子，覆盖中心、边缘和横竖方向，建立独立geometry_id及尺度。无需再次确认本批文件夹实物对应关系或固定机位。',
        '4. 请教师确认五类测量量定义、尺寸容差和验收条件，留下真实来源记录；随后用独立物理测量验证误差界，而非修改旧validated标志。',
        '5. P06后续优先修复螺杆边缘/头身质量判断、垫圈碎片/孔歧义、多目标前景关联和盖型/未知件类型证据；在开发Train上设计新版本，并使用新的独立验证/测试证据。保留本候选退步记录，不根据这批Val继续追分。','',
        '## 9. 复现与断点续作','',
        '在项目根目录及.venv311中：','```powershell',
        'python scripts/develop_baseline3_size.py --phase auto',
        'python app.py --backend real --model baseline3 --config results/baseline3_v2_experiment/size_development_v1/p07_profile.json',
        '```','',
        'auto跳过已完成阶段，从首个未完成阶段恢复；不会触发YOLO训练、Stage 2 Test或Stage 3。GUI默认配置不变。只有满足本批照片输入前提才用于尺寸诊断；Camo尚需独立标定。批处理命令及P08评价调用完整保存在每个run的command.json和execution_history.json中。','',
        '独立运行批处理（使用新的输出目录）：','```powershell',
        'python predict.py --input_dir data/mechanical_components_v2/yolo/images/val --model baseline3 --counts_file data/mechanical_components_v2/configs/expected_counts_val.json --config results/baseline3_v2_experiment/size_development_v1/p07_profile.json --output_dir outputs/size_development_v1/manual_validation --record-timing',
        '```','',
        '本次新增脚本scripts/develop_baseline3_size.py、模块src/models/baseline3/metrology.py和size_candidate.py、tests/test_baseline3_metrology.py；结果在本目录。src/p07_dashboard.py仅新增候选实际接受范围及未验证误差界的诊断显示，旧模式控件/业务逻辑不变。根实验PROGRESS.md/task_state.json更新进度。app.py、默认配置、P06原算法、B1/B2、冻结权重均未改；P03只读；未commit/push/merge。工作区其他已有修改不属于本次尺寸开发。','',
        '输出目录crops和compatibility.avi只是忽略的ROI/视频复现缓存，不是新数据集、标注或独立场景，也不会作为正式实机结果。保留P03及原始数据不变。']
    (OUT/'README.md').write_text('\n'.join(lines)+'\n',encoding='utf8')


def software_tests():
    """Run the selected software suite only if no successful record exists."""
    if (OUT/'software_tests.json').exists():return load(OUT/'software_tests.json')
    import unittest
    sys.path.insert(0,str(ROOT/'tests'))
    from scripts.experiment_baseline3_v2 import configure
    configure()
    names=['test_baseline3_metrology','test_baseline3_size_integration','test_baseline3_adapter',
           'test_p06_geometry','test_p06_foreground','test_p06_measurement_policy','test_work_orders','test_p07_real_integration']
    suite=unittest.TestLoader().loadTestsFromNames(names)
    with (OUT/'software_tests.log').open('w',encoding='utf8') as stream:
        result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
    record=dict(modules=names,run=result.testsRun,failures=len(result.failures),errors=len(result.errors),
                skipped=len(result.skipped),physical_acceptance=False)
    save(OUT/'software_tests.json',record);assert result.wasSuccessful(),'See software_tests.log'
    return record


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--phase',choices=('inventory','rulers','baseline','tune','holdout','foreground','validate','check','auto'),required=True)
    args=parser.parse_args();OUT.mkdir(parents=True,exist_ok=True);RUNTIME.mkdir(parents=True,exist_ok=True)
    functions=dict(inventory=inventory,rulers=rulers,baseline=baseline,tune=tune,holdout=holdout,
                   foreground=foreground,validate=validate,check=check)
    task=dict(zip(functions,TASKS))
    state=load(EXP/'task_state.json')
    for name in TASKS:state['tasks'].setdefault(name,dict(status='PENDING'))
    save(EXP/'task_state.json',state)
    for phase in functions if args.phase=='auto' else [args.phase]:
        state=load(EXP/'task_state.json')
        if args.phase=='auto' and state['tasks'][task[phase]]['status']=='COMPLETED':continue
        command=[sys.executable,str(Path(__file__).resolve()),'--phase',phase]
        history=load(OUT/'execution_history.json') if (OUT/'execution_history.json').exists() else []
        record=dict(phase=phase,command=command,pid=__import__('os').getpid(),started_at_utc=datetime.now(timezone.utc).isoformat(),status='RUNNING')
        history.append(record);save(OUT/'execution_history.json',history)
        try:
            functions[phase]()
            record.update(status='COMPLETED',finished_at_utc=datetime.now(timezone.utc).isoformat())
            current=load(EXP/'task_state.json')
            if current['tasks'][task[phase]]['status']!='COMPLETED':
                evidence=dict(inventory='inventory.json',rulers='calibration.json',baseline='baseline_summary.json',
                    tune='selection.json',holdout='holdout_acceptance.json',foreground='foreground_selection.json',
                    validate='public_comparison.json',check='final_acceptance.json')
                update(task[phase],'COMPLETED',evidence='size_development_v1/'+evidence[phase],reused_existing_result=True)
        except Exception as error:
            import traceback
            record.update(status='ERROR',finished_at_utc=datetime.now(timezone.utc).isoformat(),error=repr(error),traceback=traceback.format_exc())
            update(task[phase],'ERROR',reason=repr(error),resume_command='python scripts/develop_baseline3_size.py --phase auto')
            raise
        finally:
            save(OUT/'execution_history.json',history)
            current=load(EXP/'task_state.json')
            current['size_development']=dict(directory=rel(OUT),next_command='python scripts/develop_baseline3_size.py --phase auto',
                frozen_detector='epoch69 / conf0.35 / NMS0.50 / unchanged',physical_acceptance='PENDING_NOT_PASSED')
            pending=[k for k in TASKS if current['tasks'][k]['status']!='COMPLETED']
            current['next_command']='python scripts/develop_baseline3_size.py --phase auto' if pending else 'All automatic size-development phases complete; manual physical acceptance remains pending'
            save(EXP/'task_state.json',current)
            progress=EXP/'PROGRESS.md';text=progress.read_text(encoding='utf8')
            marker='\n## 当前尺寸开发恢复入口\n'
            text=text.split(marker)[0]+marker+'\n`python scripts/develop_baseline3_size.py --phase auto`\n\n自动开发结果：`size_development_v1/`。正式物理验收、教师确认、独立卡尺误差与 Camo 标定仍未通过；不得将开发候选的 PASS 冒充正式验收。\n'
            progress.write_text(text,encoding='utf8')
    report()


if __name__=='__main__':main()
