"""Resumable, isolated Stage 2 YOLO11n candidate experiment; never reads Stage 3 images."""
from __future__ import annotations

import argparse
from contextlib import redirect_stdout, redirect_stderr
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
import traceback
import zipfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
EXP = ROOT / 'results/baseline3_v2_experiment'
DATA = ROOT / 'data/mechanical_components_v2'
RUNTIME = ROOT / 'outputs/baseline3_v2'
MODEL = ROOT / 'models/baseline3_v2_candidate'
CLASSES = ('non_catalogue', 'long_screw', 'thick_screw', 'thin_screw', 'hex_nut', 'flat_washer')
PHASE_TASK = dict(prepare='dataset_isolation', train='training', validate='validation_selection',
                  compatibility='p07_compatibility', performance='performance',
                  freeze='freeze', test='stage2_evaluation', analyze='failure_analysis',
                  check='acceptance', recommend='recommendation')


def utc():
    return datetime.now(timezone.utc).isoformat()


def rel(path):
    return Path(path).resolve().relative_to(ROOT).as_posix()


def digest(path):
    with Path(path).open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()


def save(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + '.partial')
    temp.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n', encoding='utf-8')
    os.replace(temp, path)


def load(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def csvrows(path):
    import csv
    with Path(path).open(encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f))


def update(task, status, **details):
    s = load(EXP / 'task_state.json')
    s['updated_at'] = utc()
    s['phase'] = task
    if status in ('RUNNING','COMPLETED') and 'reason' not in details:
        s['tasks'][task].pop('reason',None);s['tasks'][task].pop('traceback',None)
    s['tasks'][task].update(status=status, updated_at=utc(), **details)
    if status=='COMPLETED':s['next_command']='python scripts/experiment_baseline3_v2.py --phase auto'
    save(EXP / 'task_state.json', s)
    lines = ['# Baseline3独立候选实验进度', '', f"更新时间UTC：{s['updated_at']}", '']
    for name, item in s['tasks'].items():
        lines.append(f"- {item['status']}：{name}" + (f"；{item['reason']}" if item.get('reason') else ''))
    lines += ['', '恢复：先检查task_state.json、PID、日志和checkpoint；运行下列幂等命令，不重复训练/Test：',
              '', '`' + s.get('next_command', 'python scripts/experiment_baseline3_v2.py --phase auto') + '`',
              '', 'Stage 3图像与真值禁止访问。app.py、默认配置和Baseline1/2不修改。']
    (EXP / 'PROGRESS.md').write_text('\n'.join(lines) + '\n', encoding='utf-8')


def check_frozen_development():
    state = load(DATA / 'dataset_status.json')
    assert state['status'] == 'READY' and state['frozen'] and state['formal_training_allowed']
    assert digest(ROOT / state['freeze_record']) == state['freeze_record_sha256']
    assert digest(ROOT / state['human_confirmation']) == state['human_confirmation_sha256']
    freeze = load(ROOT / state['freeze_record'])
    # Aggregate frozen indexes can be checked bytewise. Do not open Stage 3-specific files or images.
    checked = {}
    for name, expected in freeze['files'].items():
        if 'stage3' in name.lower():
            continue
        assert digest(ROOT / name) == expected, 'Frozen metadata changed: ' + name
        checked[name] = expected
    rows = csvrows(DATA / 'development/ground_truth_images.csv')
    assert len(rows) == 440 and Counter(r['split'] for r in rows) == {'train': 360, 'validation': 80}
    assert all(r['evaluation_stage'] == 'development' for r in rows)
    for row in rows:
        for field, hashes in [('image_path', freeze['images']), ('annotation_path', freeze['annotations'])]:
            name = row[field]
            assert '/images/test/' not in name
            assert name in hashes and digest(ROOT / name) == hashes[name], name
    return rows, state, checked


def protected_paths():
    paths = [ROOT / 'app.py', ROOT / 'src/p07_bridge.py', ROOT / 'p08_run.py',
             ROOT / 'src/evaluator.py', ROOT / 'src/inference/batch.py']
    for folder in ('config', 'models/baseline1', 'models/baseline2', 'models/baseline3',
                   'models/baseline1_v2_candidate', 'models/baseline2_v2_candidate',
                   'src/models/baseline1', 'src/models/baseline2',
                   'results/dataset_v2_baseline_comparison', 'results/baseline1', 'results/baseline2'):
        paths.extend(p for p in (ROOT / folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts)
    paths.extend(ROOT / p for p in ('src/adapters/baseline1.py', 'src/adapters/baseline2.py'))
    return sorted(set(paths))


def prepare():
    if (EXP / 'prepare.json').exists():
        check_frozen_development()
        update('dataset_isolation','COMPLETED',evidence='prepare.json',reused=True)
        return
    old_sources = [*ROOT.glob('src/p06*.py'), *ROOT.glob('src/models/baseline3/*.py'),
                   ROOT / 'src/adapters/baseline3.py', ROOT / 'tools/p06_train_baseline.py']
    old = dict(config=load(ROOT / 'config/baseline3.json'),
               pipeline=load(ROOT / 'config/p06_pipeline_candidate.json'),
               provenance=load(ROOT / 'models/baseline3/provenance.json'),
               training=load(ROOT / 'models/baseline3/training_record.json'),
               git_commit=subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
               source_sha256={rel(p): digest(p) for p in old_sources},
               protected_sha256={rel(p): digest(p) for p in protected_paths()})
    assert digest(ROOT / old['config']['weights']) == old['config']['weights_sha256']
    save(EXP / 'old_baseline3.json', old)
    with zipfile.ZipFile(EXP / 'old_source_snapshot.zip', 'x', zipfile.ZIP_DEFLATED) as z:
        for p in old_sources:
            z.write(p, rel(p))
    update('preserve_old', 'COMPLETED', record='old_baseline3.json', source_archive='old_source_snapshot.zip')
    rows, state, checked = check_frozen_development()
    import cv2
    import numpy as np
    objects = csvrows(DATA / 'development/ground_truth_objects.csv')
    by_image = {}
    for obj in objects:
        assert obj['ignore'] == '0', 'Ignored objects need an explicit trainer policy'
        by_image.setdefault(obj['image_id'], []).append(obj)
    byte_hash, pixel_hash, scenes = {}, {}, {}
    supports = {s: Counter() for s in ('train', 'validation')}
    runtime = RUNTIME / 'trainval'
    runtime.mkdir(parents=True, exist_ok=True)
    for row in rows:
        split = 'train' if row['split'] == 'train' else 'val'
        source = ROOT / row['image_path']
        im = cv2.imdecode(np.fromfile(source, dtype=np.uint8), cv2.IMREAD_COLOR)
        assert im is not None and im.shape[:2] == (int(row['height']), int(row['width']))
        pix = hashlib.sha256(str(im.shape).encode() + im.tobytes()).hexdigest()
        for index, key in [(byte_hash, digest(source)), (pixel_hash, pix), (scenes, row['scene_group_id'])]:
            previous = index.setdefault(key, row['split'])
            assert previous == row['split'], 'Cross Train/Val duplicate or scene group'
        label = DATA / 'yolo/labels' / split / source.with_suffix('.txt').name
        lines = [list(map(float, line.split())) for line in label.read_text().splitlines() if line.strip()]
        truth = by_image.get(row['image_id'], [])
        assert len(lines) == len(truth)
        # Validate every generated YOLO box against complete manual instance truth.
        remaining = list(truth)
        for cid, cx, cy, bw, bh in lines:
            w, h = int(row['width']), int(row['height'])
            target = np.array([(cx - bw/2)*w, (cy - bh/2)*h, (cx + bw/2)*w, (cy + bh/2)*h])
            match = next((i for i, o in enumerate(remaining) if int(o['class_id']) == cid and
                          np.max(np.abs(target - [float(o[k]) for k in ('xmin','ymin','xmax','ymax')])) < .02), None)
            assert match is not None, 'YOLO/GT box mismatch: ' + row['image_id']
            supports[row['split']][int(cid)] += 1
            remaining.pop(match)
        for kind, src in [('images', source), ('labels', label)]:
            dest = runtime / kind / split / src.name
            dest.parent.mkdir(parents=True, exist_ok=True)
            if dest.exists():
                assert digest(dest) == digest(src)
            elif kind == 'images':
                os.link(src, dest)  # Image bytes immutable; training writes caches only in runtime labels.
            else:
                shutil.copy2(src, dest)
    import yaml
    source_yaml = yaml.safe_load((DATA / 'yolo/data.yaml').read_text(encoding='utf-8'))
    assert source_yaml['names'] == dict(enumerate(CLASSES)) and 'test' not in source_yaml
    settings = dict(path=str(runtime), train='images/train', val='images/val', nc=6, names=dict(enumerate(CLASSES)))
    (runtime / 'data.yaml').write_text(yaml.safe_dump(settings, allow_unicode=True), encoding='utf-8')
    params = dict(epochs=100, patience=30, imgsz=640, batch=8, seed=42, workers=0,
                  cache=False, deterministic=True, amp=True, val=True, save=True,
                  save_period=10, plots=False, pretrained=True, optimizer='auto',
                  project=str(EXP / 'training'), name='run01', exist_ok=False)
    save(EXP / 'configs/training.json', params)
    save(EXP / 'prepare.json', dict(images=dict(Counter(r['split'] for r in rows)),
         scenes={s: len({r['scene_group_id'] for r in rows if r['split'] == s}) for s in ('train','validation')},
         support={s: dict(c) for s,c in supports.items()}, frozen_metadata_sha256=checked,
         dataset_state=state, cross_sha_pixel_scene_overlap=0,
         runtime_dataset=rel(runtime / 'data.yaml'), labels_checked=len(rows),
         stage3_access=False, source_policy='Only explicit 440 development rows; no Test image/annotation opened',
         old_training_independence='New-collection/user confirmation; exact P06 historical training list unavailable. Do not claim forensic proof of no historical exposure.'))
    update('requirements_environment', 'COMPLETED', environment='environment.json')
    update('dataset_isolation', 'COMPLETED', evidence='prepare.json')


def configure():
    cache = RUNTIME / 'runtime'
    cache.mkdir(parents=True, exist_ok=True)
    os.environ.update(YOLO_CONFIG_DIR=str(cache), YOLO_OFFLINE='true', MPLCONFIGDIR=str(cache/'matplotlib'),
                      WANDB_DISABLED='true', PYTHONIOENCODING='utf-8')
    (cache/'matplotlib').mkdir(exist_ok=True)
    # Offline font checks otherwise try downloading Arial even with plots=False.
    (cache/'Ultralytics').mkdir(exist_ok=True)
    font = Path(os.environ['WINDIR'])/'Fonts/arial.ttf'
    for folder in (cache, cache/'Ultralytics'):
        if not (folder/'Arial.ttf').exists():
            shutil.copyfile(font, folder/'Arial.ttf')


def train():
    if (EXP/'training/completion.json').exists():
        record=load(EXP/'training/completion.json')
        assert digest(MODEL/'best.pt') == record['best_sha256']
        assert digest(MODEL/'last.pt') == record['last_sha256']
        assert digest(MODEL/'resume_last.pt') == record['resume_sha256']
        update('training','COMPLETED',best=rel(MODEL/'best.pt'),epochs=record['epochs_completed'],reused=True)
        return
    check_frozen_development()
    configure()
    import torch
    from ultralytics import YOLO
    from ultralytics.utils import SETTINGS
    from ultralytics.models.yolo.detect import DetectionTrainer
    class CSVLoggingTrainer(DetectionTrainer):
        # Installed Polars fails at import with unknown CPU feature 'sse3'.
        # Replace only numeric log serialization, not training/evaluation algorithms.
        def read_results_csv(self):
            import csv
            with self.csv.open(encoding='utf-8',newline='') as f:
                rows=list(csv.DictReader(f))
            return {k:[float(r[k]) for r in rows] for k in rows[0]} if rows else {}
    params=load(EXP/'configs/training.json')
    device=0 if torch.cuda.is_available() else 'cpu'
    params.update(device=device, amp=device != 'cpu')
    initial=ROOT/load(EXP/'pretrained_source.json')['path']
    assert digest(initial)==load(EXP/'pretrained_source.json')['sha256']
    dict.__setitem__(SETTINGS,'weights_dir',str(initial.parent))
    MODEL.mkdir(parents=True, exist_ok=True)
    resume=MODEL/'resume_last.pt'
    run_dir=Path(params['project'])/params['name']
    if resume.exists():
        model=YOLO(str(resume)); training_args=dict(resume=True, device=device)
    else:
        assert not run_dir.exists(), 'Run exists without resumable checkpoint; inspect before restarting'
        model=YOLO(str(initial)); training_args=dict(params, data=str(RUNTIME/'trainval/data.yaml'))
    start=time.perf_counter()
    record=dict(started_at=utc(),pid=os.getpid(),initialization=load(EXP/'pretrained_source.json'),
                requested_params=params,actual_device=device,resume=resume.exists(),
                runtime_data_sha256=digest(RUNTIME/'trainval/data.yaml'))
    save(EXP/'training'/('session_'+str(os.getpid())+'.json'),record)
    progress={}
    def epoch_end(trainer):
        progress.update(epoch=int(trainer.epoch)+1,best_fitness=float(trainer.best_fitness),
                        metrics={k:float(v) for k,v in trainer.metrics.items()},
                        losses={k:float(v) for k,v in trainer.label_loss_items(trainer.tloss,prefix='train').items()},
                        updated_at=utc(),pid=os.getpid())
        save(EXP/'training/progress.json',progress)
        update('training','RUNNING',epoch=progress['epoch'],pid=os.getpid(),checkpoint=rel(resume),log='training/train.log')
        print('EPOCH_RECORD '+json.dumps(progress),flush=True)
    def model_save(trainer):
        if trainer.last.is_file():
            temp=resume.with_suffix('.partial');shutil.copy2(trainer.last,temp);os.replace(temp,resume)
    model.add_callback('on_fit_epoch_end',epoch_end)
    model.add_callback('on_model_save',model_save)
    model.train(trainer=CSVLoggingTrainer,**training_args)
    for name in ('best.pt','last.pt'):
        shutil.copy2(run_dir/'weights'/name,MODEL/name)
    checkpoint=torch.load(MODEL/'best.pt',map_location='cpu',weights_only=False)
    resume_data=torch.load(resume,map_location='cpu',weights_only=False)
    assert resume_data.get('optimizer') is not None and resume_data.get('epoch',-1)>=0
    fresh=YOLO(str(MODEL/'best.pt'));assert fresh.names==dict(enumerate(CLASSES))
    record.update(completed_at=utc(),seconds=time.perf_counter()-start,
                  epochs_completed=progress['epoch'],best_sha256=digest(MODEL/'best.pt'),
                  last_sha256=digest(MODEL/'last.pt'),resume_sha256=digest(resume),
                  resume_epoch=resume_data['epoch'],resume_optimizer_present=True,
                  effective_train_args=checkpoint.get('train_args'),stored_metrics=checkpoint.get('train_metrics'),
                  logging_workaround='Native DetectionTrainer; only read_results_csv uses stdlib csv because installed polars cannot import (unknown sse3 feature flag)',
                  gpu_peak_bytes=torch.cuda.max_memory_allocated(0) if device != 'cpu' else None)
    save(EXP/'training/completion.json',record)
    save(MODEL/'training_record.json',record)
    check_frozen_development()
    update('training','COMPLETED',best=rel(MODEL/'best.pt'),epochs=record['epochs_completed'],seconds=record['seconds'])


def write_csv(path, rows, fields=None):
    import csv
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('w',encoding='utf-8',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=fields or list(rows[0]));writer.writeheader();writer.writerows(rows)


def profiles():
    cfg=load(ROOT/'config/p07.json')
    old=load(ROOT/'config/baseline3.json')
    candidate=copy_json(old)
    candidate.update(candidate_schema='yolo11n-candidate/v1',candidate_version='p07-v2-yolo11n-standard-trial01',
                     weights=rel(MODEL/'best.pt'),weights_sha256=digest(MODEL/'best.pt'),
                     release_status='independent_candidate_not_active',initialization=load(EXP/'pretrained_source.json'))
    paths={}
    for conf in load(EXP/'task_state.json')['limits']['confidence_trials']:
        for nms in load(EXP/'task_state.json')['limits']['nms_trials']:
            label=f'new_c{conf:g}_n{nms:g}'
            detector=copy_json(candidate);detector['inference'].update(conf=conf,iou=nms)
            path=EXP/'configs'/f'{label}_detector.json';save(path,detector)
            profile=copy_json(cfg);profile['bridge']='src.models.baseline3.candidate:create_backend'
            profile['model_config'].update(baseline3_config=rel(path),baseline3_mode='yolo_frozen')
            paths[label]=EXP/'configs'/f'{label}.json';save(paths[label],profile)
    old_raw=copy_json(cfg);old_raw['model_config']['baseline3_mode']='yolo_frozen'
    save(EXP/'configs/old_raw.json',old_raw)
    save(EXP/'configs/old_full.json',cfg)
    return paths


def copy_json(value):
    import copy
    return copy.deepcopy(value)


def validation_config():
    # Reuse the already established Validation view (not any Test annotations).
    source=ROOT/'results/dataset_v2_baseline_comparison/configs/validation.json'
    cfg=load(source)
    assert cfg['evaluation_stage']=='validation'
    path=EXP/'configs/validation.json';save(path,cfg);return path


def saved_run(root, profile, evaluation_config):
    """Native P08 CLI, recorded child PID; reuse complete outputs, never silently rerun partial inference."""
    configure()
    root=Path(root);root.mkdir(parents=True,exist_ok=True)
    existing=list(root.glob('baseline3-*'))
    if existing:
        assert len(existing)==1,'Ambiguous runs: '+str(root)
        result=existing[0]
        command=load(result/'command.json')
        assert command['model_config_sha256']==digest(profile),'Saved run config changed'
        assert (result/'evaluation/summary.json').exists(),'Incomplete run; inspect PID/logs and complete using frozen inputs, do not blindly repeat'
        return result
    command=[sys.executable,str(ROOT/'p08_run.py'),'--evaluation-config',str(evaluation_config),
             '--config',str(profile),'--model','baseline3','--record-timing','--output',str(root)]
    log_path=root/'execution.log'
    with log_path.open('x',encoding='utf-8') as log:
        proc=subprocess.Popen(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,env=os.environ.copy())
        s=load(EXP/'task_state.json');s['active_child']=dict(pid=proc.pid,command=command,log=rel(log_path),started_at=utc());save(EXP/'task_state.json',s)
        code=proc.wait()
    s=load(EXP/'task_state.json');s['active_child'].update(exit_code=code,finished_at=utc());save(EXP/'task_state.json',s)
    assert code==0,f'P08 exited {code}; see {log_path}'
    result,=root.glob('baseline3-*')
    assert (result/'evaluation/object_observations.json').is_file(),'P08 object observation metrics missing'
    return result


def run_metrics(path):
    return load(Path(path)/'evaluation/summary.json')['image_level_details']


def validate():
    configure()
    assert (EXP/'training/completion.json').exists()
    if (EXP/'validation/selection.json').exists():
        selected=load(EXP/'validation/selection.json')
        if not (EXP/'model_selection.md').exists():
            (EXP/'model_selection.md').write_text('# Test前选型记录\n\n原始选择时间UTC：'+selected['selected_at_utc']+'\n\n完整规则、候选、参数及推荐见validation/selection.json；此文件由既有选择记录恢复，没有重新选型。\n',encoding='utf-8')
        update('validation_selection','COMPLETED',selected=selected['selected_candidate'],reused=True)
        update('candidate_selection','COMPLETED',recommended_detector=selected['recommended_detector'],full_pipeline='BLOCKED',reused=True)
        return
    # Stripped framework checkpoints have epoch=-1. Recover epoch only when their
    # complete stored metric tuple identifies a unique actual training CSV row.
    import torch
    checkpoint=torch.load(MODEL/'best.pt',map_location='cpu',weights_only=False)
    record=load(EXP/'training/completion.json')
    native=Path(record['effective_train_args']['save_dir']) if record['effective_train_args'].get('save_dir') else Path(record['effective_train_args']['project'])/record['effective_train_args']['name']
    history=csvrows(native/'results.csv');stored=checkpoint['train_metrics']
    keys=[k for k in stored if k in history[0]]
    matches=[int(r['epoch']) for r in history if all(abs(float(r[k])-float(stored[k]))<=1e-5 for k in keys)]
    save(EXP/'training/best_epoch.json',dict(serialized_epoch=checkpoint.get('epoch'),metric_keys=keys,
        matching_epochs=matches,selected_epoch=matches[0] if len(matches)==1 else None,
        evidence='Unique match of checkpoint stored validation metric tuple against native results.csv; not inferred from filename'))
    # Keep deliverable best/last/resume under models/. Preserve redundant native
    # checkpoints in ignored local outputs rather than uploading periodic weights.
    assert native.resolve().is_relative_to((EXP/'training').resolve())
    archived=[]
    destination=RUNTIME/'native_checkpoint_archive';destination.mkdir(parents=True,exist_ok=True)
    for weight in (native/'weights').glob('*.pt'):
        dest=(destination/weight.name).resolve()
        assert weight.resolve().is_relative_to((EXP/'training').resolve()) and dest.is_relative_to(RUNTIME.resolve())
        h=digest(weight)
        if dest.exists():assert digest(dest)==h
        else:shutil.move(str(weight),str(dest))
        archived.append(dict(original=rel(weight),preserved_local_path=rel(dest),sha256=h))
    if archived:save(EXP/'training/native_weight_archive.json',archived)
    configs=profiles();val=validation_config();runs={}
    index=EXP/'validation/runs.json'
    if index.exists():runs=load(index)
    candidates=[]
    for label,path in {'old_raw':EXP/'configs/old_raw.json',**configs}.items():
        run_dir=saved_run(EXP/'validation'/label,path,val);runs[label]=rel(run_dir);save(index,runs)
        if label=='old_raw':continue
        m=run_metrics(run_dir);obs=load(run_dir/'evaluation/object_observations.json')
        eligible=(m['eligible_coverage']>=.9 and (m['fail']['recall'] or 0)>=.5 and (m['passed']['recall'] or 0)>=.5)
        # Predeclared finite grid and lexicographic safety/coverage/recognition criterion; no Test input.
        key=[m['false_pass']['count'],-(m['fail']['recall'] or 0),-(m['fail']['f1'] or 0),
             m['false_fail']['count'],-(obs['classes']['0']['recall'] or 0),
             -(obs['five_class_vector_exact'] or 0),-(m['completed_accuracy'] or 0)]
        candidates.append(dict(label=label,profile=rel(path),metrics=m,observations=obs,eligible=eligible,key=key))
    eligible=[c for c in candidates if c['eligible']]
    assert eligible,'No nondegenerate candidate; do not use Test to select another'
    chosen=min(eligible,key=lambda c:(c['key'],c['label']))
    # Promote config into independent candidate folder, never into active config/.
    profile=load(ROOT/chosen['profile']);detector=load(ROOT/profile['model_config']['baseline3_config'])
    save(MODEL/'detector.json',detector)
    profile['model_config']['baseline3_config']=rel(MODEL/'detector.json')
    save(EXP/'configs/new_raw.json',profile)
    pipeline=copy_json(load(ROOT/'config/p06_pipeline_candidate.json'))
    pipeline.update(detector_config_path=rel(MODEL/'detector.json'),calibration_path=None,
                    capture_geometry_id='mechanical-components-v2-geometry-unconfirmed')
    save(EXP/'configs/new_pipeline.json',pipeline)
    full=copy_json(profile);full['model_config'].update(baseline3_mode='size_verified',
         baseline3_pipeline_config=rel(EXP/'configs/new_pipeline.json'),baseline3_acceptance_approval=None)
    save(EXP/'configs/new_full.json',full)
    for version in ('old','new'):
        label=version+'_full';run_dir=saved_run(EXP/'validation'/label,EXP/'configs'/f'{label}.json',val)
        runs[label]=rel(run_dir);save(index,runs)
        derived=derive_count_rule(run_dir)
        raw_label='old_raw' if version=='old' else chosen['label']
        expected={r['image_id']:r['predicted_label'] for r in csvrows(ROOT/runs[raw_label]/'predictions/images.csv')}
        assert {r['image_id']:r['predicted_label'] for r in csvrows(derived/'predictions/images.csv')}==expected, 'Full pipeline observations differ from separately saved raw count predictions'
    selection=dict(selected_at_utc=utc(),phase='Validation only, before Stage 2 Test',
        selected_candidate=chosen['label'],criterion='Before Validation: coverage>=90% and recall>=50% for each image class; exclude trivial/mostly-one-class solutions. Then minimize False PASS, maximize FAIL recall/F1, minimize False FAIL, maximize ID0 recall/count-vector exact; finite grid',
        candidates=candidates,
        full_pipeline_ready=False,physical_size_acceptance='BLOCKED: no compatible calibration/physical evidence; not resolved by detector performance',
        old_full_metrics=run_metrics(ROOT/runs['old_full']),new_full_metrics=run_metrics(ROOT/runs['new_full']),
        stage2_test='NOT_RUN',stage3='NOT_RUN')
    # Version recommendation based on full predeclared vector, not on test.
    old_m=run_metrics(ROOT/runs['old_raw']);new_m=chosen['metrics']
    old_key=(old_m['false_pass']['count'],-old_m['fail']['recall'],-old_m['fail']['f1'],old_m['false_fail']['count'])
    new_key=(new_m['false_pass']['count'],-new_m['fail']['recall'],-new_m['fail']['f1'],new_m['false_fail']['count'])
    old_eligible=old_m['eligible_coverage']>=.9 and (old_m['fail']['recall'] or 0)>=.5 and (old_m['passed']['recall'] or 0)>=.5
    selection['old_eligible']=old_eligible
    selection['recommended_detector']='new' if not old_eligible or new_key<old_key else 'old'
    save(EXP/'validation/selection.json',selection)
    lines=['# Test前模型选型记录','',f"记录UTC：{selection['selected_at_utc']}",
           f"候选参数：{chosen['label']}；检测器推荐：{selection['recommended_detector']}",
           f"旧/新Validation原始计数判定准确率：{old_m['completed_accuracy']:.4%} / {new_m['completed_accuracy']:.4%}。",
           f"旧/新False PASS：{old_m['false_pass']['count']} / {new_m['false_pass']['count']}。",
           '选择规则及全部有限试验见validation/selection.json；本记录生成时Stage 2 Test未运行。',
           '完整尺寸系统仍缺少可信标定和物理验收，不能将检测器推荐解释为可完整替换现有系统。',
           '完整管线与原始计数辅助结果分别统计；不会排除REVIEW后宣称全部输入准确率。',
           'Stage 3未访问；Test完成后不重训或再选阈值。','']
    (EXP/'model_selection.md').write_text('\n'.join(lines),encoding='utf-8')
    update('validation_selection','COMPLETED',selected=chosen['label'],runs='validation/runs.json')
    update('candidate_selection','COMPLETED',recommended_detector=selection['recommended_detector'],full_pipeline='BLOCKED')


def freeze():
    assert (EXP/'validation/selection.json').exists()
    assert (EXP/'tests/real_compatibility.json').exists(), 'Complete real Validation interface checks before Test'
    path=EXP/'freeze.json'
    if path.exists():
        verify_freeze();update('freeze','COMPLETED',evidence='freeze.json',reused=True);return
    check_frozen_development()
    targets=[*MODEL.glob('*.json'),MODEL/'best.pt',*EXP.glob('configs/*.json'),
             ROOT/'src/models/baseline3/candidate.py',ROOT/'src/adapters/baseline3.py',
             ROOT/'src/p06_pipeline.py']
    targets.extend(ROOT/name for name in ('src/p07_bridge.py','src/work_orders.py',
        'src/models/baseline1/features.py','src/data/p06_labelme.py',
        'src/p07_output.py','src/camera.py','src/p07_ui.py'))
    # Both systems and all shared decision/geometry sources are pinned before Test.
    old=load(EXP/'old_baseline3.json')
    targets.extend(ROOT/p for p in old['source_sha256'])
    targets.extend(ROOT/p for p in old['protected_sha256'] if p.startswith('config/') or p=='p08_run.py' or p=='src/evaluator.py' or p=='src/inference/batch.py')
    targets.extend([ROOT/'models/baseline3/best.pt',EXP/'validation/selection.json',EXP/'model_selection.md',
                   ROOT/'scripts/benchmark_live.py',
                   DATA/'configs/stage2_evaluation.json',DATA/'splits/stage2_test.txt',
                   DATA/'evaluation/stage2/ground_truth_images.csv',DATA/'evaluation/stage2/ground_truth_objects.csv',
                   DATA/'configs/expected_counts_stage2.json'])
    # Resolve exact stage paths from established config; never reference Stage 3.
    targets=[p for p in targets if p.exists()]
    stage=load(DATA/'configs/stage2_evaluation.json')
    targets.extend(ROOT/stage[k] for k in ('ground_truth_images','ground_truth_objects','counts_file','split_list'))
    save(path,dict(frozen_at_utc=utc(),before_test=True,files={rel(p):digest(p) for p in sorted(set(targets))},
                   experiment_runner_sha256_at_freeze=digest(Path(__file__)),
                   selected=load(EXP/'validation/selection.json')['recommended_detector'],stage3_access=False,
                   prior_stage2_use='Same 30 images already evaluated for Baseline1/2; no Baseline3 Test inference or Test-based parameter choice in this experiment before freeze',
                   metrics_policy='Full size-gated pipeline primary; saved count-rule auxiliary reported separately, no size compliance claim'))
    update('freeze','COMPLETED',evidence='freeze.json')


def verify_freeze():
    for name,h in load(EXP/'freeze.json')['files'].items():
        assert digest(ROOT/name)==h,'Frozen model/config/source changed: '+name


def derive_count_rule(full_run):
    """Diagnostic comparison from saved detections, without rerunning a single Test image."""
    from src.work_orders import judge_observed
    from src.evaluator import evaluate
    full_run=Path(full_run);out=full_run/'count_rule_derived'
    if (out/'evaluation/summary.json').exists():return out
    out.mkdir(exist_ok=True);pred=out/'predictions';pred.mkdir(exist_ok=True)
    metadata=load(full_run/'predictions/run_config.json')
    assert metadata.get('foreground_enabled') is False and metadata.get('acceptance_confirmation') is None, 'Derived raw comparison requires unchanged, unapproved size/foreground observations'
    expected=metadata['per_image_expected_counts']
    rows=csvrows(full_run/'predictions/images.csv');objs=csvrows(full_run/'predictions/objects.csv')
    # Current configs have no validated size relabelling or foreground merging. Use retained real boxes.
    for row in rows:
        if row['status']=='ERROR':continue
        counts=Counter(str(o['class_id']) for o in objs if o['image_id']==row['image_id'])
        status='FAIL' if counts['0'] or any(counts[str(i)]!=expected[row['image_id']][str(i)] for i in range(1,6)) else 'PASS'
        row.update(status=status,predicted_label=status,prediction_score='',score_type='none')
    write_csv(pred/'images.csv',rows)
    for name in ('objects.csv','counts.csv'):
        shutil.copy2(full_run/'predictions'/name,pred/name)
    save(pred/'run_config.json',dict(metadata,derived_from=rel(full_run),
        decision_scope='Count-rule auxiliary derived from saved real detections; not full size verification and not a new inference run'))
    command=load(full_run/'command.json');data=Path(command['dataset'])
    counts=next((x for x in command['command'][command['command'].index('--counts_file')+1:]),None)
    evaluate(data/'ground_truth_images.csv',data/'ground_truth_objects.csv',counts,pred,out/'evaluation')
    return out


def test():
    verify_freeze()
    stage=DATA/'configs/stage2_evaluation.json';spec=load(stage)
    rows=csvrows(ROOT/spec['ground_truth_images']);assert len(rows)==30
    assert all(r['evaluation_stage']=='stage2' for r in rows)
    freeze_data=load(ROOT/load(DATA/'dataset_status.json')['freeze_record'])
    import cv2
    import numpy as np
    # Only the explicit 30 Stage 2 IDs may be opened here.
    for row in rows:
        path=ROOT/spec['input_dir']/row['image_id'];assert digest(path)==freeze_data['images'][rel(path)]
    index=EXP/'evaluation/runs.json';runs=load(index) if index.exists() else {}
    for version in ('old','new'):
        run_dir=saved_run(EXP/'evaluation'/('baseline3_'+version),EXP/'configs'/f'{version}_full.json',stage)
        assert set(r['image_id'] for r in csvrows(run_dir/'predictions/images.csv'))==set(r['image_id'] for r in rows)
        runs[version]=rel(run_dir);save(index,runs)
        derive_count_rule(run_dir)
    save(EXP/'evaluation/completion.json',dict(completed_at=utc(),runs=runs,test_images=30,
        inference_runs_per_model=1,stage3_access=False,freeze_sha256=digest(EXP/'freeze.json')))
    update('stage2_evaluation','COMPLETED',runs='evaluation/runs.json',images=30)


def analyze():
    """Aggregate saved CSV/JSON only; never infers or adjusts parameters."""
    runs=load(EXP/'evaluation/runs.json');val=load(EXP/'validation/runs.json')
    result={}
    from collections import defaultdict
    from src.evaluator import iou
    for version,path in runs.items():
        run_dir=ROOT/path;summary=load(run_dir/'evaluation/summary.json')
        obj=load(run_dir/'evaluation/object_observations.json');aux=derive_count_rule(run_dir)
        truth_rows=csvrows(Path(load(run_dir/'command.json')['dataset'])/'ground_truth_images.csv')
        truth={r['image_id']:r for r in truth_rows};preds={r['image_id']:r for r in csvrows(run_dir/'predictions/images.csv')}
        auxpred={r['image_id']:r for r in csvrows(aux/'predictions/images.csv')}
        groups={}
        failures=[]
        for image,gt in truth.items():
            group=groups.setdefault(gt['scenario_type'],Counter())
            status=preds[image]['status'];a=auxpred[image]['status'];label=gt['ground_truth_label']
            group['images']+=1;group['correct']+=status==label;group['review']+=status=='REVIEW'
            group['false_pass']+=label=='FAIL' and status=='PASS';group['false_fail']+=label=='PASS' and status=='FAIL'
            group['count_rule_correct']+=a==label
            if status!=label or a!=label:
                failures.append(dict(image_id=image,truth=label,status=status,count_rule=a,
                    scenario=gt['scenario_type'],non_catalogue_type=gt.get('non_catalogue_type',''),
                    has_id0=int(gt['non_catalogue_count'])>0,run=path))
        special={}
        for name,eligible in [
            ('id0_present',[g for g in truth_rows if int(g['non_catalogue_count'])>0]),
            ('correct_targets_plus_id0',[g for g in truth_rows if int(g['non_catalogue_count'])>0 and all(int(g[c+'_count'])==1 for c in CLASSES[1:])]),
            ('empty',[g for g in truth_rows if sum(int(g[c+'_count']) for c in CLASSES[1:])+int(g['non_catalogue_count'])==0]),
            ('only_id0',[g for g in truth_rows if sum(int(g[c+'_count']) for c in CLASSES[1:])==0 and int(g['non_catalogue_count'])>0])]:
            special[name]=dict(support=len(eligible),false_pass=sum(preds[g['image_id']]['status']=='PASS' for g in eligible),
                count_rule_false_pass=sum(auxpred[g['image_id']]['status']=='PASS' for g in eligible),
                review=sum(preds[g['image_id']]['status']=='REVIEW' for g in eligible))
        variant_groups={}
        for g in truth_rows:
            if int(g['non_catalogue_count'])>0:
                key=g.get('non_catalogue_type') or 'UNKNOWN'
                group=variant_groups.setdefault(key,dict(image_ids=[],rejected=0,review=0,count_rule_rejected=0))
                group['image_ids'].append(g['image_id']);group['rejected']+=preds[g['image_id']]['status']=='FAIL'
                group['review']+=preds[g['image_id']]['status']=='REVIEW';group['count_rule_rejected']+=auxpred[g['image_id']]['status']=='FAIL'
        details=dict(summary=summary,all_observation_metrics=obj,special_cases=special,annotated_variant_groups=variant_groups,
                     count_rule_auxiliary=load(aux/'evaluation/summary.json'),
                     groups={k:dict(v) for k,v in groups.items()})
        result[version]=details
        if failures:write_csv(EXP/'failure_cases'/f'{version}.csv',failures)
        object_errors=object_diagnostics(run_dir)
        if object_errors:write_csv(EXP/'failure_cases'/f'{version}_object_errors.csv',object_errors)
        truth_objects=csvrows(Path(load(run_dir/'command.json')['dataset'])/'ground_truth_objects.csv')
        actual=Counter((o['image_id'],o['class_id']) for o in truth_objects if o['ignore']=='0')
        count_errors=[]
        for row in csvrows(run_dir/'predictions/counts.csv'):
            gt=actual[(row['image_id'],row['class_id'])];observed=int(row['observed_count']);expected=int(row['expected_count'])
            if observed!=gt:
                count_errors.append(dict(image_id=row['image_id'],class_id=row['class_id'],actual_count=gt,
                    observed_count=observed,expected_count=expected,reported_difference=int(row['difference']),
                    true_difference=gt-expected,count_error=observed-gt,status=preds[row['image_id']]['status']))
        if count_errors:write_csv(EXP/'failure_cases'/f'{version}_count_errors.csv',count_errors)
    save(EXP/'comparison_metrics.json',result)
    paired_summary={}
    for scope in ('full_pipeline','count_rule_auxiliary'):
        suffix=Path('predictions/images.csv') if scope=='full_pipeline' else Path('count_rule_derived/predictions/images.csv')
        maps={v:{r['image_id']:r for r in csvrows(ROOT/p/suffix)} for v,p in runs.items()}
        assert set(maps['old'])==set(maps['new'])==set(truth)
        pairs=[];totals=Counter()
        for image,gt in sorted(truth.items()):
            a,b=maps['old'][image]['status'],maps['new'][image]['status'];label=gt['ground_truth_label']
            event='both_correct' if a==label and b==label else 'old_wrong_new_correct' if b==label else 'old_correct_new_wrong' if a==label else 'both_wrong_or_unresolved'
            totals[event]+=1
            pairs.append(dict(image_id=image,truth=label,scenario=gt['scenario_type'],old_status=a,new_status=b,event=event))
        write_csv(EXP/'failure_cases'/f'{scope}_paired.csv',pairs)
        paired_summary[scope]=dict(totals)
    save(EXP/'failure_cases/paired_summary.json',paired_summary)
    rows=[]
    timing=load(EXP/'benchmarks/offline_summary.json')['models']
    for version in ('old','new'):
        d=result[version];m=d['summary']['image_level_details'];aux=d['count_rule_auxiliary']['image_level_details']
        vfull=run_metrics(ROOT/val[version+'_full']);vraw=run_metrics(ROOT/val['old_raw' if version=='old' else load(EXP/'validation/selection.json')['selected_candidate']])
        row=dict(model='baseline3_'+version,val_accuracy=vfull['completed_accuracy'],val_coverage=vfull['eligible_coverage'],
            val_fail_f1=vfull['fail']['f1'],val_count_rule_fail_f1=vraw['fail']['f1'],
            val_all_input_correct=vfull['all_input_correct_fraction'],val_count_rule_accuracy=vraw['completed_accuracy'],
            test_accuracy=m['completed_accuracy'],test_balanced_accuracy=m['completed_balanced_accuracy'],
            test_fail_precision=m['fail']['precision'],test_fail_recall=m['fail']['recall'],test_fail_f1=m['fail']['f1'],
            fail_recall_all_eligible=m['fail']['recall_all_eligible'],
            false_pass=m['false_pass']['count'],false_fail=m['false_fail']['count'],review=m['status_counts'].get('REVIEW',0),
            error=m['status_counts'].get('ERROR',0),coverage=m['eligible_coverage'],all_input_correct=m['all_input_correct_fraction'],
            other_non_success=sum(n for k,n in m['status_counts'].items() if k not in ('PASS','FAIL','REVIEW','ERROR')),
            input_images=m['input_cases'],independent_scenes=d['summary']['input_scenes'],
            pass_support=m['passed']['support_all'],fail_support=m['fail']['support_all'],
            tp=m['confusion_matrix']['tp'],fp=m['confusion_matrix']['fp'],fn=m['confusion_matrix']['fn'],tn=m['confusion_matrix']['tn'],
            false_pass_rate=m['false_pass']['rate'],false_fail_rate=m['false_fail']['rate'],
            count_rule_accuracy=aux['completed_accuracy'],count_rule_false_pass=aux['false_pass']['count'],count_rule_false_fail=aux['false_fail']['count'],
            count_rule_false_pass_rate=aux['false_pass']['rate'],count_rule_false_fail_rate=aux['false_fail']['rate'],
            vector_exact=d['all_observation_metrics']['five_class_vector_exact'],
            size_mae='NOT_RUN',size_acceptance='BLOCKED',live_latency='NOT_MEASURED',
            normal_size_pass_rate='NOT_RUN',wrong_size_metrology_rejection_rate='NOT_RUN',
            median_offline_inference_ms=timing[version]['inference']['median_ms'],
            p95_offline_inference_ms=timing[version]['inference']['p95_ms'],
            median_offline_processing_ms=timing[version]['processing']['median_ms'],
            p95_offline_processing_ms=timing[version]['processing']['p95_ms'],
            peak_cuda_allocated_bytes=timing[version]['peak_cuda_allocated_bytes'],
            device=timing[version]['device'],inference_imgsz=640,inference_batch=1,
            capture_fps='NOT_MEASURED',continuous_processing_fps='NOT_MEASURED',
            weight_bytes=(ROOT/'models/baseline3/best.pt' if version=='old' else MODEL/'best.pt').stat().st_size)
        for cid in range(6):
            c=d['all_observation_metrics']['classes'][str(cid)]
            for field in ('support','tp','fp','fn','precision','recall','count_mae'):row[f'id{cid}_{field}']=c[field]
        rows.append(row)
    write_csv(EXP/'comparison_metrics.csv',rows)
    update('failure_analysis','COMPLETED',metrics='comparison_metrics.csv',failures='failure_cases/')


def object_diagnostics(run_dir):
    """Official same-class matching first; residual cross-class matches are diagnostic only."""
    from src.evaluator import iou
    data=Path(load(run_dir/'command.json')['dataset'])
    truths=csvrows(data/'ground_truth_objects.csv');predictions=csvrows(run_dir/'predictions/objects.csv')
    errors=[]
    def box(o):return tuple(float(o[k]) for k in ('xmin','ymin','xmax','ymax'))
    for image in sorted({r['image_id'] for r in csvrows(data/'ground_truth_images.csv')}):
        gt=[r for r in truths if r['image_id']==image and r['ignore']=='0']
        ds=sorted([r for r in predictions if r['image_id']==image],key=lambda r:(-float(r['score']),int(r['detection_id'])))
        used=set();left=[]
        for p in ds:
            choices=sorted([(iou(box(p),box(g)),j) for j,g in enumerate(gt) if j not in used and g['class_id']==p['class_id']],
                           key=lambda q:(-q[0],gt[q[1]]['object_id']))
            if choices and choices[0][0]>=.5:used.add(choices[0][1])
            else:left.append(p)
        for p in left:
            choices=sorted([(iou(box(p),box(g)),j) for j,g in enumerate(gt) if j not in used],key=lambda q:(-q[0],gt[q[1]]['object_id']))
            if choices and choices[0][0]>=.5:
                overlap,j=choices[0];used.add(j);g=gt[j]
                event='normal_as_id0' if p['class_id']=='0' else 'id0_as_normal' if g['class_id']=='0' else 'class_confusion'
                errors.append(dict(image_id=image,event=event,object_id=g['object_id'],true_class=g['class_id'],
                    detection_id=p['detection_id'],predicted_class=p['class_id'],score=p['score'],iou=overlap))
            else:
                errors.append(dict(image_id=image,event='false_alarm',object_id='',true_class='',
                    detection_id=p['detection_id'],predicted_class=p['class_id'],score=p['score'],iou=''))
        for j,g in enumerate(gt):
            if j not in used:errors.append(dict(image_id=image,event='id0_miss' if g['class_id']=='0' else 'normal_miss',
                object_id=g['object_id'],true_class=g['class_id'],detection_id='',predicted_class='',score='',iou=''))
    return errors


def compatibility():
    configure()
    (EXP/'tests').mkdir(parents=True,exist_ok=True)
    import cv2
    import numpy as np
    from types import SimpleNamespace
    from src.p07_bridge import load_backend,validate_result
    from src.models.baseline1.features import load_image_bgr
    from src.p07_ui import InferenceWorker,present
    from src.work_orders import reference_counts
    rows=csvrows(DATA/'development/ground_truth_images.csv')
    selected=[]
    for scenario in 'ABDEG':
        row=next((r for r in rows if r['split']=='validation' and r['scenario_type']==scenario),None)
        if row:selected.append(row)
    selected.append(next(r for r in rows if sum(int(r[c+'_count']) for c in CLASSES[1:])+int(r['non_catalogue_count'])==0))
    records=[]
    for version in ('old','new'):
        for mode in ('raw','full'):
            backend=load_backend('real','baseline3',load(EXP/'configs'/f'{version}_{mode}.json'))
            for row in selected:
                frame=load_image_bgr(str(ROOT/row['image_path']));expected=reference_counts()
                result=validate_result(backend.infer(frame,expected),'baseline3',frame.shape)
                changed=backend.rejudge(result,dict.fromkeys('12345',0))
                assert result['objects']==changed['objects'] and result['counts']==changed['counts']
                if result['non_catalogue_count']>0:assert result['status']==changed['status']=='FAIL'
                records.append(dict(version=version,mode=mode,image_id=row['image_id'],status=result['status'],
                    id0=result['non_catalogue_count'],observed=result['counts'],zero_order_status=changed['status'],
                    observations_unchanged=True,physical_size_acceptance=False))
            worker=InferenceWorker();packet=SimpleNamespace(image=frame,frame_id=1,available_at=time.perf_counter())
            try:
                assert worker.submit(backend,'baseline3',packet,expected,'pass',1)
                deadline=time.perf_counter()+60;answer=None
                while answer is None and time.perf_counter()<deadline:answer=worker.poll();time.sleep(.005)
                assert answer is not None and answer['result']['status']!='ERROR'
                canvas=present(packet,answer['result'],expected,'baseline3','real',dict(model_mode=backend.metadata['baseline3_mode']))
                assert canvas.ndim==3 and canvas.dtype==np.uint8
            finally:worker.close()
    # Two independent batch runs with different legal work orders, same actual Validation images.
    cases=selected[:3];orders=[]
    for label,expected in [('fixed',reference_counts()),('zero',dict.fromkeys('12345',0))]:
        path=EXP/'configs'/f'functional_counts_{label}.json'
        save(path,[dict(image_id=r['image_id'],expected_counts=expected) for r in cases]);orders.append(path)
        out=RUNTIME/'compatibility'/label
        command=[sys.executable,str(ROOT/'predict.py'),'--input_dir',str(DATA/'yolo/images/val'),
                 '--counts_file',str(path),'--model','baseline3','--config',str(EXP/'configs/new_full.json'),'--output_dir',str(out)]
        out.parent.mkdir(parents=True,exist_ok=True)
        with (out.parent/(label+'.log')).open('w',encoding='utf-8') as f:
            code=subprocess.run(command,cwd=ROOT,stdout=f,stderr=subprocess.STDOUT).returncode
        assert code==0
    a,b=[RUNTIME/'compatibility'/x for x in ('fixed','zero')]
    assert csvrows(a/'objects.csv')==csvrows(b/'objects.csv')
    ca,cb=csvrows(a/'counts.csv'),csvrows(b/'counts.csv')
    assert [(r['image_id'],r['class_id'],r['observed_count']) for r in ca]==[(r['image_id'],r['class_id'],r['observed_count']) for r in cb]
    for r in ca+cb:assert int(r['difference'])==int(r['observed_count'])-int(r['expected_count'])
    # Real app image/video route. These offline derived frames are never live evidence.
    image=ROOT/cases[0]['image_path'];video=RUNTIME/'compatibility/validation_fixture.avi'
    writer=cv2.VideoWriter(str(video),cv2.VideoWriter_fourcc(*'MJPG'),5,(480,640))
    assert writer.isOpened()
    for row in cases:writer.write(cv2.resize(load_image_bgr(str(ROOT/row['image_path'])),(480,640)))
    writer.release()
    for kind,path in [('image',image),('video',video)]:
        command=[sys.executable,str(ROOT/'app.py'),'--headless','--model','baseline3','--config',str(EXP/'configs/new_full.json'),
            '--'+kind,str(path),'--output-dir',str(RUNTIME/'compatibility'/('app_'+kind)),'--max-frames','1','--timeout','60']
        with (EXP/'tests'/('app_'+kind+'.log')).open('w',encoding='utf-8') as f:
            code=subprocess.run(command,cwd=ROOT,stdout=f,stderr=subprocess.STDOUT).returncode
        assert code==0,'App '+kind+' compatibility failed'
    original=load(ROOT/'config/p07.json')
    baseline12={}
    for name in ('baseline1','baseline2'):
        backend=load_backend('real',name,original);result=backend.infer(frame,reference_counts())
        assert result['status'] in ('PASS','FAIL')
        assert backend.infer(frame,dict.fromkeys('12345',0))['status']=='UNSUPPORTED_COUNTS'
        baseline12[name]=dict(real_load=True,normal_status=result['status'],unsupported_counts=True)
    save(EXP/'tests/real_compatibility.json',dict(records=records,worker_and_render=True,batch_dynamic_counts=True,
        app_image_video=True,camera='NOT_RUN',baseline12=baseline12,synthetic_or_training_diagnostics_not_performance=True))
    update('development','COMPLETED',scope='Independent detector/provider dependency injection, unchanged decision/geometry algorithms')
    update('p07_compatibility','COMPLETED',evidence='tests/real_compatibility.json',camera='NOT_RUN')


def performance():
    configure()
    import torch
    import numpy as np
    from src.p07_bridge import load_backend,validate_result
    from src.models.baseline1.features import load_image_bgr
    from src.work_orders import reference_counts
    rows=[r for r in csvrows(DATA/'development/ground_truth_images.csv') if r['split']=='validation'][:20]
    records=[];summaries={}
    for version in ('old','new'):
        backend=load_backend('real','baseline3',load(EXP/'configs'/f'{version}_full.json'))
        for row in rows[:3]:backend.infer(load_image_bgr(str(ROOT/row['image_path'])),reference_counts())
        torch.cuda.synchronize();torch.cuda.reset_peak_memory_stats(0)
        for row in rows:
            frame=load_image_bgr(str(ROOT/row['image_path']));backend.synchronize();start=time.perf_counter()
            result=validate_result(backend.infer(frame,reference_counts()),'baseline3',frame.shape)
            backend.synchronize();elapsed=(time.perf_counter()-start)*1000
            detector=backend.native.provider.detector
            speed=detector._model.predictor.results[0].speed
            records.append(dict(model=version,image_id=row['image_id'],processing_ms=elapsed,
                inference_ms=float(speed['inference']),status=result['status'],
                geometry_attempts=sum('measurement' in o.get('size_evidence',{}) for o in result['objects'])))
        mine=[r for r in records if r['model']==version]
        def stats(field):
            a=np.array([r[field] for r in mine]);return dict(median_ms=float(np.median(a)),p95_ms=float(np.percentile(a,95,method='linear')),mean_ms=float(a.mean()))
        summaries[version]=dict(processing=stats('processing_ms'),inference=stats('inference_ms'),
             peak_cuda_allocated_bytes=torch.cuda.max_memory_allocated(0),device='cuda:0',warmup=3,images=20,
             geometry_attempts=sum(r['geometry_attempts'] for r in mine),live_latency='NOT_MEASURED',capture_fps='NOT_MEASURED',processing_fps='NOT_MEASURED',
             limitation='Old pipeline computes provisional geometry with unverified old scale; new calibration missing so measurements cannot run. Full processing times are not an isolated detector speedup comparison.')
        del detector,backend;torch.cuda.empty_cache()
    write_csv(EXP/'benchmarks/offline_frames.csv',records)
    save(EXP/'benchmarks/offline_summary.json',dict(models=summaries,
         boundaries='Decoded frame -> preprocess/model/postprocess/size-work-order decision/result validation/GPU complete; excludes decode/load/render',
         forward_source='Ultralytics Results.speed[inference], ops.Profile synchronizes CUDA',percentile_method='linear',live='NOT_RUN'))
    update('performance','COMPLETED',offline='benchmarks/offline_summary.json',live='NOT_RUN: user must connect physical station')


def check():
    old=load(EXP/'old_baseline3.json')
    changed=[p for p,h in old['protected_sha256'].items() if digest(ROOT/p)!=h]
    assert not changed,changed
    verify_freeze()
    save(EXP/'tests/preservation.json',dict(protected=len(old['protected_sha256']),unchanged=True,
         old_weights_sha256=digest(ROOT/'models/baseline3/best.pt'),stage3_access=False,
         app_default_configs_baseline12_unchanged=True,old_source_archive_sha256=digest(EXP/'old_source_snapshot.zip')))
    update('acceptance','COMPLETED',scope='Preservation/freeze checks only; see separate software and physical acceptance records')


def recommend():
    selection=load(EXP/'validation/selection.json');metrics=load(EXP/'comparison_metrics.json')
    performance=load(EXP/'benchmarks/offline_summary.json')
    statement=dict(pre_test_detector_choice=selection['recommended_detector'],
        after_test_parameters_changed=False,formal_replacement=False,
        complete_stage2_compliance=False,
        recommendation='Detector candidate selection only; neither full system has verified physical size acceptance. Do not replace GUI defaults until calibration/physical validation and user approval.',
        physical_blockers=load(EXP/'stage2_audit.json')['size_blockers'],live='NOT_RUN',
        metrics='comparison_metrics.csv',timing='benchmarks/offline_summary.json',
        source_snapshot='old_source_snapshot.zip',resume_command='python scripts/experiment_baseline3_v2.py --phase auto')
    save(EXP/'recommendation.json',statement)
    save(EXP/'stage2_compliance.json',dict(
        software_interface='PASS: real Validation worker/image/video/batch tests in tests/real_compatibility.json',
        localization_classification_counting='MEASURED: per-class precision/recall/support and MAE in comparison_metrics.csv; performance is not perfect by assertion',
        learned_id0_rejection='MEASURED: labeled seen size variants only; no universal unseen-component claim',
        dynamic_work_orders='PASS: same-frame rejudge plus independent batch work orders, unchanged retained boxes/counts',
        wrong_size_mechanism='PARTIAL: six-class learned ID0 real evaluation; independent calibrated metrology BLOCKED',
        physical_scale_tolerance_instructor_acceptance='BLOCKED: no compatible verified scale, per-specimen caliper GT, independent error bounds or instructor confirmation',
        foreground_unknown_candidates='PARTIAL: existing implementation preserved but disabled without validated reference/coverage',
        genuine_review_not_pass='PASS software safeguard; actual coverage and all-input correctness reported without excluding failures',
        live_latency_and_rig='NOT_RUN: needs user camera/physical platform; offline timing is separate',
        stage3='NOT_ACCESSED',overall='NOT_FULLY_ACCEPTED'))
    text=['# 实验复现与恢复','',
          '本目录仅用于Baseline3模型开发、验证和选型，不代替P08正式报告；不生成英文图表。',
          '进度与实际命令保存在task_state.json / PROGRESS.md。恢复前检查其中PID、training/progress.json、训练日志和models/baseline3_v2_candidate/resume_last.pt。',
          '恢复命令：`python scripts/experiment_baseline3_v2.py --phase auto`。已完成阶段跳过，正在运行的PID不重复启动，已有完整P08结果直接复用。',
          '训练使用冻结360/80分区，原生YOLO11n标准训练；仅checkpoint CSV元数据读取避开本机Polars导入错误。原始失败尝试和日志保留。恢复使用原生resume及未strip的优化器checkpoint，不是从best重新拟合。',
          '完整模型对照位于evaluation/baseline3_old和baseline3_new，每模型仅推理一次相同30张Stage 2图。count_rule_derived只从已保存真实检测结果重判，不重新推理，也不代表完整尺寸验收。',
          '旧完整管线保留历史未验证尺度；新管线不沿用无法证明兼容的尺度，calibration=null，因此尺寸MAE、正常规格通过率及错误规格尺寸拒识率NOT_RUN。六类ID0识别的拒绝率不等于尺寸测量精度或任意未知件拒识。',
          '官方P08目标/计数主指标会排除模型REVIEW；object_observations.json另报包括REVIEW的真实保留框和数量，两个分母不可混淆。Accuracy、全部输入正确比例及Coverage必须一起查看。',
          '离线forward来自Ultralytics已同步GPU的Results.speed，完整处理另用perf_counter；不将倒数当作持续摄像头FPS。旧/新测量分支因标定资料不同，完整处理时间不能归因于单独检测器加速。','',
          '## 返回现场后补做','',
          '1. P01固定Camo机位/光源/白色哑光背景，记录分辨率、距离/姿态/镜头，标注尺子端点和真实长度并复核中心及边缘尺度。',
          '2. 对正常及三个异常规格实物建立specimen_id，卡尺重复测量，记录独立开发/验证清单；确认教师认可的规格容差及支持工况。不得用名义尺寸代替卡尺真值。',
          '3. 用独立开发资料验证已有几何算法误差与失败率；补足测量策略、真实背景与前景关联证据。另存新配置，不改本轮冻结文件，不根据本轮Test调整算法。',
          '4. 在相同机位/电源性能/输入条件下分别测新旧系统，每模型20新帧预热和100新帧测量。当前未验证尺寸配置的计时只能说明其当前实际分支，不证明尺寸功能通过。','',
          '```powershell',
          'python scripts/benchmark_live.py --camera 0 --models baseline3 --warmup 20 --frames 100 --display --config results/baseline3_v2_experiment/configs/old_full.json',
          'python scripts/benchmark_live.py --camera 0 --models baseline3 --warmup 20 --frames 100 --display --config results/baseline3_v2_experiment/configs/new_full.json',
          '```','',
          '计时从新帧available_at至实际P07渲染和imshow/waitKey返回，包含必要GPU同步；不含此前曝光/Camo传输或物理屏幕刷新。原processing-only指标单列；Capture FPS见capture_events.csv，实际选样吞吐见observed_sample_fps。',
          '新旧模型已按Test前配置冻结，Stage 3禁止开发访问。任何后续算法调整都需要新的独立评价证据。','']
    (EXP/'reproducibility.md').write_text('\n'.join(text),encoding='utf-8')
    update('recommendation','COMPLETED',choice=selection['recommended_detector'],physical_stage2='BLOCKED',live='NOT_RUN')


class Tee:
    def __init__(self, console, log):
        self.console, self.log = console, log

    def write(self, text):
        self.console.write(text)
        self.log.write(text)
        self.log.flush()
        return len(text)

    def flush(self):
        self.console.flush()
        self.log.flush()

    def isatty(self):
        return False


def alive(pid):
    if not pid or pid==os.getpid():
        return False
    import ctypes
    dll=ctypes.windll.kernel32
    dll.OpenProcess.restype=ctypes.c_void_p
    handle=dll.OpenProcess(0x1000,False,int(pid))
    if not handle:
        return False
    code=ctypes.c_ulong()
    try:
        return bool(dll.GetExitCodeProcess(ctypes.c_void_p(handle),ctypes.byref(code))) and code.value==259
    finally:
        dll.CloseHandle(ctypes.c_void_p(handle))


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--phase',choices=(*PHASE_TASK,'auto'),required=True)
    parser.add_argument('--wait-active',action='store_true',help='Supervisor waits for an existing recorded task instead of launching a duplicate')
    args=parser.parse_args()
    s=load(EXP/'task_state.json')
    if args.phase=='auto':
        supervisor=s.get('supervisor',{})
        if alive(supervisor.get('pid')):
            print('Supervisor already active:',supervisor['pid']);return 0
        if (EXP/'prepare.json').exists():check_frozen_development()
        if (EXP/'training/completion.json').exists():
            assert digest(MODEL/'best.pt')==load(EXP/'training/completion.json')['best_sha256']
        if (EXP/'freeze.json').exists():verify_freeze()
        s['supervisor']=dict(pid=os.getpid(),started_at=utc(),status='WAITING_FOR_ACTIVE_TASK');save(EXP/'task_state.json',s)
    while True:
        s=load(EXP/'task_state.json')
        active=[(task,item) for task,item in s['tasks'].items() if item.get('status')=='RUNNING' and alive(item.get('pid'))]
        if not active:break
        print('Existing tasks alive; no duplicates:',[(task,item['pid']) for task,item in active],flush=True)
        if not args.wait_active:return 0
        time.sleep(20)
    if args.phase=='auto':
        s=load(EXP/'task_state.json');s['supervisor']=dict(pid=os.getpid(),started_at=utc(),status='RUNNING');save(EXP/'task_state.json',s)
        for phase,task in PHASE_TASK.items():
            if load(EXP/'task_state.json')['tasks'][task]['status']=='COMPLETED':continue
            print('Supervisor launching phase:',phase,utc(),flush=True)
            code=subprocess.run([sys.executable,'-u',str(Path(__file__).resolve()),'--phase',phase],cwd=ROOT).returncode
            if code:
                print('Phase stopped without bypassing checks:',phase,code,flush=True)
                return code
        s=load(EXP/'task_state.json');s['supervisor'].update(status='COMPLETED',finished_at=utc());save(EXP/'task_state.json',s)
        return 0
    phases=list(PHASE_TASK) if args.phase=='auto' else [args.phase]
    for phase in phases:
        task=PHASE_TASK[phase]
        if load(EXP/'task_state.json')['tasks'][task]['status']=='COMPLETED':
            print('Already completed:',phase)
            continue
        s=load(EXP/'task_state.json')
        s['next_command']=f'python scripts/experiment_baseline3_v2.py --phase {phase}'
        s['commands'].append(dict(command=sys.argv,pid=os.getpid(),started_at=utc(),phase=phase,status='RUNNING'))
        save(EXP/'task_state.json',s)
        update(task,'RUNNING',pid=os.getpid(),started_at=utc())
        try:
            log_path=EXP/('training/train.log' if phase=='train' else f'{phase}.log')
            log_path.parent.mkdir(parents=True,exist_ok=True)
            with log_path.open('a',encoding='utf-8') as log:
                with redirect_stdout(Tee(sys.stdout,log)),redirect_stderr(Tee(sys.stderr,log)):
                    {'prepare':prepare,'train':train,'validate':validate,'freeze':freeze,
                     'test':test,'analyze':analyze,'check':check,'compatibility':compatibility,
                     'performance':performance,'recommend':recommend}[phase]()
        except BaseException as exc:
            update(task,'FAILED',reason=repr(exc),traceback=traceback.format_exc())
            raise
        finally:
            s=load(EXP/'task_state.json');s['commands'][-1].update(finished_at=utc(),status=s['tasks'][task]['status'],
                exit_code=0 if s['tasks'][task]['status']=='COMPLETED' else 1)
            save(EXP/'task_state.json',s)
    return 0


if __name__=='__main__':
    raise SystemExit(main())
