"""Versioned P08 raw-baseline comparison. No Stage 3 inference and no GUI defaults changed."""
from __future__ import annotations
import argparse
import copy
from datetime import datetime,timezone
import json
import os
from pathlib import Path
import shutil
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from src.data.dataset_v2 import save_json,save_csv,digest,relative
from src.data.development import read_csv
from p08_run import run

DATA=ROOT/'data/mechanical_components_v2'
OUT=ROOT/'results/dataset_v2_baseline_comparison'
VARIANTS=('baseline1_old','baseline1_new','baseline2_old','baseline2_new')


def assert_dataset():
    state=json.loads((DATA/'dataset_status.json').read_text(encoding='utf-8'))
    if state.get('status')!='READY' or state.get('frozen') is not True:raise ValueError('Dataset is not READY/frozen')
    freeze=json.loads((ROOT/state['freeze_record']).read_text(encoding='utf-8'))
    if digest(ROOT/state['freeze_record'])!=state['freeze_record_sha256']:raise ValueError('Freeze record changed')
    if any(digest(ROOT/p)!=sha for p,sha in freeze['files'].items()):raise ValueError('Frozen data metadata changed')
    return state,freeze


def model_files():
    return {variant:[ROOT/'models'/('baseline1' if variant.endswith('_old') else 'baseline1_v2_candidate')/'baseline1.joblib']
            if variant.startswith('baseline1') else [ROOT/'models'/('baseline2' if variant.endswith('_old') else 'baseline2_v2_candidate')/n for n in ('baseline2.json','resnet18-f37072fd.pth')]
            for variant in VARIANTS}


def feature_audit():
    import numpy as np
    from src.models.baseline1.model import load_bundle
    audit={}
    for model in ('baseline1','baseline2'):
        folder=ROOT/'models'/f'{model}_v2_candidate'
        info=json.loads((folder/'training_record.json').read_text(encoding='utf-8'))
        matches=[]
        for p in (DATA/'development_cache/features').glob(f'{model}-*.json'):
            spec=json.loads(p.read_text(encoding='utf-8'))
            if spec['manifest']==info['data']['manifest_sha256']:matches.append(p)
        if len(matches)!=1:raise ValueError('Ambiguous feature cache identity')
        cache=matches[0]
        manifest=next(p for p in (DATA/'development_cache').glob('*/manifest.json') if
            json.loads(p.read_text(encoding='utf-8'))['evidence']['manifest_sha256']==info['data']['manifest_sha256'] and
            json.loads(p.read_text(encoding='utf-8'))['evidence']['settings_sha256']==info['data']['settings_sha256'])
        records=json.loads(manifest.read_text(encoding='utf-8'))['records']
        with np.load(cache.with_suffix('.npz'),allow_pickle=False) as f:X=f['X']
        mask=np.array([r['split']=='train' for r in records])
        if set(r['split'] for r in records)!={'train','validation'} or len(X)!=440 or mask.sum()!=360:raise ValueError('Feature cache escaped development-only records')
        if any('/images/test/' in r['path'] for r in records):raise ValueError('Test image reached feature cache')
        if model=='baseline1':
            bundle=load_bundle(str(folder/'baseline1.joblib'));pipeline=bundle['mlp'];scaler=pipeline.steps[0][1]
            mean,scale=scaler.mean_,scaler.scale_
            count=int(scaler.n_samples_seen_)
            extra={}
        else:
            bundle=json.loads((folder/'baseline2.json').read_text(encoding='utf-8'));mean=np.array(bundle['classifier']['mean']);scale=np.array(bundle['classifier']['scale']);count=info['trials'][0]['scaler_fit_samples'];extra={}
        expected=X[mask].std(axis=0);expected[expected==0]=1
        good=np.allclose(mean,X[mask].mean(axis=0),rtol=1e-6,atol=1e-6) and np.allclose(scale,expected,rtol=1e-6,atol=1e-6) and count==360
        if not good:raise ValueError('Scaler was not fitted exclusively on Train')
        audit[model]=dict(train=360,validation=80,feature_dimension=X.shape[1],scaler_train_only=True,
                          cache=relative(cache.with_suffix('.npz')),cache_sha256=digest(cache.with_suffix('.npz')),
                          manifest_sha256=info['data']['manifest_sha256'],**extra)
        dest=OUT/'training'/model;dest.mkdir(parents=True,exist_ok=True)
        report=ROOT/'outputs/training_v2'/model/f'{model}_v2_candidate'
        for name in ('training_record.json','development_manifest.json','train_predictions.csv','validation_predictions.csv'):
            shutil.copyfile(report/name,dest/name)
    save_json(OUT/'training/data_isolation_audit.json',audit)


def profiles():
    base=json.loads((ROOT/'config/p07.json').read_text(encoding='utf-8'))
    paths={}
    for version in ('old','new'):
        config=copy.deepcopy(base)
        if version=='new':
            config['model_config'].update(baseline1_config='models/baseline1_v2_candidate/config.json',
                 baseline1_bundle='models/baseline1_v2_candidate/baseline1.joblib',baseline2_bundle='models/baseline2_v2_candidate')
        config['_live_scene_guard']=False
        config['experiment_variants']={m:m+'_'+version for m in ('baseline1','baseline2')}
        path=OUT/'configs'/f'{version}_raw.json';save_json(path,config)
        for model in ('baseline1','baseline2'):paths[model+'_'+version]=path
    return paths


def validation_config():
    rows=[r for r in read_csv(DATA/'development/ground_truth_images.csv') if r['split']=='validation'];ids={r['image_id'] for r in rows}
    objects=[r for r in read_csv(DATA/'development/ground_truth_objects.csv') if r['image_id'] in ids]
    view=DATA/'evaluation/validation'
    save_csv(view/'ground_truth_images.csv',rows);save_csv(view/'ground_truth_objects.csv',objects)
    cfg=json.loads((DATA/'configs/stage2_evaluation.json').read_text(encoding='utf-8'))
    cfg.update(dataset=relative(view),evaluation_stage='validation',input_dir=relative(DATA/'yolo/images/val'),
               ground_truth_images=relative(view/'ground_truth_images.csv'),ground_truth_objects=relative(view/'ground_truth_objects.csv'),
               counts_file=relative(DATA/'configs/expected_counts_val.json'),split_list=relative(DATA/'splits/val.txt'))
    path=OUT/'configs/validation.json';save_json(path,cfg);return path


def validate():
    assert_dataset()
    if (OUT/'validation/runs.json').exists():raise FileExistsError('Preserve existing validation results')
    feature_audit();configs=profiles();cfg=validation_config();runs={}
    for variant in VARIANTS:
        model=variant.rsplit('_',1)[0]
        runs[variant]=relative(run(None,model,OUT/'validation'/variant,cfg,configs[variant],True))
    save_json(OUT/'validation/runs.json',runs)
    # Re-loaded deployment/P08 predictions must match stored training-stage validation predictions.
    consistency={}
    for model in ('baseline1','baseline2'):
        variant=model+'_new';pred=read_csv(ROOT/runs[variant]/'predictions/images.csv');expected={r['image_id']:r for r in read_csv(OUT/'training'/model/'validation_predictions.csv')}
        mismatches=[]
        for row in pred:
            truth=expected[row['image_id']];score=float(truth['p_fail'])
            if model=='baseline1' and row['predicted_label']=='PASS':score=1-score
            if row['predicted_label']!=truth['predicted_label'] or abs(float(row['prediction_score'])-score)>2e-6:mismatches.append(row['image_id'])
        consistency[model]=dict(images=len(pred),mismatches=mismatches)
        if len(pred)!=80 or mismatches:raise ValueError('Training/deployment/batch prediction regression')
    save_json(OUT/'validation/deployment_consistency.json',consistency)
    choice={};evidence={}
    for model in ('baseline1','baseline2'):
        candidates=[]
        for version in ('old','new'):
            variant=model+'_'+version
            metrics=json.loads((ROOT/runs[variant]/'evaluation/summary.json').read_text(encoding='utf-8'))['image_level_details']
            eligible=metrics['eligible_coverage']>=.9 and (metrics['fail']['recall'] or 0)>0 and (metrics['passed']['recall'] or 0)>0
            key=(metrics['false_pass']['count'],-(metrics['fail']['recall'] or 0),-(metrics['fail']['f1'] or 0),
                 -metrics['eligible_coverage'],metrics['false_fail']['count'],-(metrics['completed_balanced_accuracy'] or 0),-(metrics['completed_accuracy'] or 0))
            evidence[variant]=dict(metrics=metrics,eligible=eligible,selection_key=key)
            if eligible:candidates.append((key,variant))
        choice[model]=min(candidates)[1] if candidates else None
    frozen={relative(p):digest(p) for files in model_files().values() for p in files}
    frozen.update({relative(p):digest(p) for p in {*configs.values(),cfg}})
    frozen.update({relative(p):digest(p) for p in (ROOT/'models/baseline1_v2_candidate/config.json',ROOT/'models/baseline1_v2_candidate/freeze.json')})
    selection=dict(selected_before_test_at_utc=datetime.now(timezone.utc).isoformat(),criterion='Exclude one-class/non-covering predictors; lexicographic False PASS, FAIL recall, FAIL F1, coverage, False FAIL, balanced accuracy, accuracy. No live-speed claim.',
                   choice=choice,validation=evidence,frozen_files=frozen,test='NOT_RUN',hyperparameter_search=False)
    save_json(OUT/'selection.json',selection)
    text=['# Candidate selection before Stage 2 test','',selection['criterion'],'',
          'Raw baselines only. This experiment does not integrate GUI scene guards or replace active models.',
          f"Recorded UTC: {selection['selected_before_test_at_utc']}",f"Choices: {choice}",'',
          'Original selected hyperparameters retrained once; no search or threshold optimization. Train-only scalers and feature-cache signatures checked. Live latency NOT_MEASURED.',
          'All four checkpoint/config identities are pinned in selection.json. Stage 2 Test has not run at this selection point. Stage 3 is never evaluated.','']
    (OUT/'model_selection.md').write_bytes('\n'.join(text).encode())
    print('Pre-test selection:',choice,flush=True)


def test():
    assert_dataset()
    if (OUT/'evaluation/runs.json').exists():raise FileExistsError('Stage 2 comparison already recorded; no repeated test')
    selection=json.loads((OUT/'selection.json').read_text(encoding='utf-8'))
    if any(digest(ROOT/p)!=sha for p,sha in selection['frozen_files'].items()):raise ValueError('Selected model/config changed after validation freeze')
    records=json.loads((DATA/'manifests/records.json').read_text(encoding='utf-8'))['records']
    chosen=[r for r in records if r['evaluation_stage']=='stage2']
    old=json.loads((ROOT/'results/data_manifests/development.json').read_text(encoding='utf-8'))['records']
    overlap=[r['image_id'] for r in chosen if any(r[f]==o[f] for o in old for f in ('sha256','pixel_sha256'))]
    if len(chosen)!=30 or overlap:raise ValueError('No trustworthy common Stage 2 test; do not use Stage 3')
    save_json(OUT/'evaluation/independence.json',dict(stage2_images=30,old_development_sha_pixel_overlap=overlap,
        scene_basis='Collector/user independently rearranged scene confirmation; hashes do not prove scene independence',
        old_development_images=len(old),stage3_used=False,
        input_ids=[r['image_id'] for r in chosen],input_sha256={r['image_id']:r['sha256'] for r in chosen}))
    runs={}
    for variant in VARIANTS:
        model,version=variant.rsplit('_',1)
        runs[variant]=relative(run(None,model,OUT/'evaluation'/variant,DATA/'configs/stage2_evaluation.json',OUT/'configs'/f'{version}_raw.json',True))
    save_json(OUT/'evaluation/runs.json',runs)
    print('Four P08 Stage 2 runs completed. No retraining or threshold selection follows.',flush=True)


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--phase',choices=('validate','test'),required=True)
    args=parser.parse_args();os.environ['PYTHONIOENCODING']='utf-8'
    (validate if args.phase=='validate' else test)()


if __name__=='__main__':main()
