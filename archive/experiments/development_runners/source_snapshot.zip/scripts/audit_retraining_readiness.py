"""Run the existing data checks and record retraining blockers; never train or score."""
from __future__ import annotations

import argparse
import csv
from datetime import datetime, timezone
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from src.data.dataset_v2 import save_json,save_csv,digest,relative
from src.data.development import read_csv
from src.work_orders import reference_counts


def inventory():
    paths=set()
    for directory in ('models','config','src/models/baseline3'):
        paths.update(p for p in (ROOT/directory).rglob('*') if p.is_file() and '__pycache__' not in p.parts)
    paths.update(ROOT/p for p in ('app.py','src/p07_bridge.py','scripts/benchmark_live.py'))
    paths.update(ROOT.glob('src/p06_*.py'));paths.update(ROOT.glob('tools/p06_*.py'))
    data=ROOT/'data/mechanical_components_v2'
    paths.update((data/'splits').glob('*'))
    paths.update(data/p for p in ('dataset_status.json','ground_truth_images.csv','ground_truth_objects.csv',
                                  'development/ground_truth_images.csv','development/ground_truth_objects.csv',
                                  'configs/training.json','configs/stage2_evaluation.json','configs/stage3_evaluation.json'))
    return {relative(p):dict(sha256=digest(p),size_bytes=p.stat().st_size) for p in sorted(paths) if p.is_file()}


def old_models():
    result={}
    b1_config=json.loads((ROOT/'config/baseline1.json').read_text(encoding='utf-8'))
    b2_bundle=json.loads((ROOT/'models/baseline2/baseline2.json').read_text(encoding='utf-8'))
    for name in ('baseline1','baseline2'):
        folder=ROOT/'models'/name
        training=json.loads((folder/'training_record.json').read_text(encoding='utf-8'))
        files=[folder/'baseline1.joblib',folder/'config.json',folder/'freeze.json'] if name=='baseline1' else [folder/'baseline2.json',folder/'resnet18-f37072fd.pth']
        item=dict(variant=name+'_old',model_id=name,files=[dict(path=relative(p),sha256=digest(p),bytes=p.stat().st_size) for p in files if p.exists()],
                  model_version=training['model_version'],training_record=relative(folder/'training_record.json'),
                  historical_metrics=training['metrics'],historical_support=training['data']['summary'],
                  source_git_commit=training.get('source_git_commit'),source_worktree=training.get('source_worktree'),
                  selected_parameters=training['selected_parameters'],fixed_counts=reference_counts(),
                  official_held_out_test=training.get('official_held_out_test','UNKNOWN'),
                  data_manifest='results/data_manifests/development.json',new_dataset_evaluation='NOT_RUN')
        if name=='baseline1':
            item.update(algorithm=b1_config['method'],input_size=b1_config['image_size'],preprocessing=b1_config['preprocessing'],
                        hog=b1_config['hog'],feature_dimension=1764,mlp=b1_config['mlp'],
                        decision='argmax in saved classes_ order; conceptual two-class boundary 0.5',
                        score='P(predicted class), uncalibrated; not always P(FAIL)',
                        raw_non_success='Invalid input/inference exception -> ERROR; other legal work order -> UNSUPPORTED_COUNTS',
                        gui_system_guard=dict(path='models/baseline1/scene_guard.npz',sha256=digest(folder/'scene_guard.npz'),
                           rule='Nearest standardized training-HOG support; outside -> REVIEW with null score/label',
                           compatibility='Bound to old model SHA; implementation fixes reference shape at 262x1764; cannot reuse for new model'))
        else:
            item.update(algorithm='Frozen ImageNet ResNet18 + Train-only StandardScaler + LogisticRegression',
                        input_size=[224,224],preprocessing=b2_bundle['preprocessing'],feature_dimension=512,
                        decision=dict(p_fail_threshold=b2_bundle['classifier']['fail_probability_threshold'],positive_class='FAIL'),
                        score='P(FAIL), uncalibrated',frozen_backbone=True,
                        raw_non_success='Invalid input/inference exception -> ERROR; other legal work order -> UNSUPPORTED_COUNTS')
        item['deployment_model_bytes']=sum(p.stat().st_size for p in files if p.suffix in ('.joblib','.pth') or p.name=='baseline2.json')
        result[name+'_old']=item
    return result


def run_check(command, path):
    start=time.perf_counter();env=dict(os.environ,PYTHONIOENCODING='utf-8',PYTHONUTF8='1')
    env.update(YOLO_CONFIG_DIR=str(ROOT/'tmp/ultralytics'),MPLCONFIGDIR=str(ROOT/'tmp/matplotlib'))
    (ROOT/'tmp/ultralytics/Ultralytics').mkdir(parents=True,exist_ok=True)
    print('Running: '+' '.join(command),flush=True)
    with path.open('wb') as log:
        proc=subprocess.run([sys.executable,*command],cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT)
    return dict(command=['.venv311/Scripts/python.exe',*command],exit_code=proc.returncode,
                duration_seconds=time.perf_counter()-start,log=relative(path),log_sha256=digest(path))


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,default=ROOT/'results/dataset_v2_baseline_comparison')
    args=parser.parse_args();output=args.output.resolve()
    if not output.is_relative_to(ROOT/'results'):parser.error('Use a new experiment below results/')
    if output.exists():parser.error('Use a new --output directory; previous audit evidence is preserved')
    stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    preflight=output/'preflight'/stamp;preflight.mkdir(parents=True)
    before=inventory();save_json(preflight/'protected_before.json',before)
    data=ROOT/'data/mechanical_components_v2'
    status_before=json.loads((data/'dataset_status.json').read_text(encoding='utf-8'))
    commands=[
       ['scripts/prepare_dataset_v2.py','--verify-only'],
       ['scripts/check_dataset_v2.py'],
       ['-m','scripts.train_baseline1','--dataset-config','data/mechanical_components_v2/configs/training.json','--prepare-only','--audit-candidate'],
       ['-m','scripts.train_baseline2','--dataset-config','data/mechanical_components_v2/configs/training.json','--prepare-only','--audit-candidate'],
       ['p08_run.py','--evaluation-config','data/mechanical_components_v2/configs/stage2_evaluation.json','--check-data-only'],
       ['-m','unittest','discover','-s','tests','-v']]
    receipt=[]
    for i,command in enumerate(commands,1):
        item=run_check(command,preflight/f'{i:02d}.log');receipt.append(item)
        print(f"Check {i}/{len(commands)} exit={item['exit_code']}",flush=True)
    after=inventory();save_json(preflight/'protected_after.json',after)
    unchanged=before==after
    resolution=json.loads((ROOT/'results/data_manifests/mechanical_components_v2/annotation_resolutions.json').read_text(encoding='utf-8'))
    records=json.loads((data/'manifests/records.json').read_text(encoding='utf-8'))['records']
    by_id={r['image_id']:r for r in records}
    bound={iid:dict(scope=r['scope'],source=r['source'],sha256_matches=digest(ROOT/by_id[iid]['source_annotation'])==r['annotation_sha256']) for iid,r in resolution.items()}
    save_json(preflight/'annotation_resolution_check.json',bound)
    pairs=json.loads((data/'audit/duplicates.json').read_text(encoding='utf-8'))['near_candidates']
    triage=[]
    for pair in pairs:
        a,b=by_id[pair['image_a']],by_id[pair['image_b']]
        pa,pb=a['split']+':'+a['evaluation_stage'],b['split']+':'+b['evaluation_stage']
        triage.append(dict(**pair,partition_a=pa,partition_b=pb,same_group=a['scene_group_id']==b['scene_group_id'],
                           cross_partition=pa!=pb,collector_scene_confirmation='Already recorded; do not infer same scene from pHash alone'))
    save_csv(output/'near_duplicate_triage.csv',triage)
    specs=old_models();save_json(output/'old_model_inventory.json',specs)
    # Gate probes do not reach fitting, prediction or evaluation.
    from src.data.dataset_v2 import prepare_development
    from p08_run import evaluation_inputs
    settings=json.loads((data/'configs/training.json').read_text(encoding='utf-8'))
    gate={}
    for name,operation in (
        ('formal_development_loader',lambda:prepare_development(data/'development',settings)),
        ('formal_stage2_entry',lambda:evaluation_inputs(data/'configs/stage2_evaluation.json'))):
        try:operation();gate[name]=dict(blocked=False)
        except ValueError as exc:gate[name]=dict(blocked=True,reason=str(exc))
    stats=json.loads((data/'manifests/dataset_statistics.json').read_text(encoding='utf-8'))
    checks=dict(requested_checks_passed=all(r['exit_code']==0 for r in receipt),protected_files_unchanged=unchanged,
                original_json_confirmations_bound=all(r['sha256_matches'] for r in bound.values()),
                ready_status_unchanged=json.loads((data/'dataset_status.json').read_text(encoding='utf-8'))==status_before)
    env=dict(python=sys.version,dependencies={n:importlib.metadata.version(n) for n in ['numpy','scikit-learn','scikit-image','torch','torchvision','opencv-python','ultralytics']})
    report=dict(status='BLOCKED_PENDING_HUMAN_EVIDENCE' if status_before.get('status')!='READY' or status_before.get('frozen') is not True else 'DATA_GATE_READY_NO_EXPERIMENT_RUN',
                dataset_status=status_before,checks=checks,gate_probes=gate,commands=receipt,environment=env,
                git_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
                actual_support=stats['public'],annotation_resolution_check=bound,
                near_duplicate_pairs=len(pairs),cross_partition_candidates=sum(r['cross_partition'] for r in triage),
                scope='Data-format/hash/metadata audit only; no classifier fit, new dataset prediction, or formal scoring',
                stage3_usage='No model inference, evaluation, selection or algorithm debugging; requested integrity checker performs existing read-only annotation/hash/list checks',
                trained=False,formal_test='NOT_RUN',live_latency='NOT_MEASURED')
    save_json(output/'preflight.json',report)
    save_json(output/'confirmation_needed.json',dict(status='PENDING_NOT_A_CONFIRMATION',
        dataset_version={relative(p):digest(p) for p in [data/'development/ground_truth_images.csv',data/'ground_truth_objects.csv',data/'splits/train.txt',data/'splits/val.txt',data/'splits/stage2_test.txt',data/'splits/stage3_test.txt']},
        annotation_quality=dict(reviewer='',role='',date='',review_scope='',evidence_file='',negative_scenes_verified=None,outcome=None),
        near_duplicate_review=dict(reviewer='',decision='',evidence='',existing_scene_independence_confirmation='Already present; not requested again'),
        held_out_history=dict(responsible_person='',stage2_unused_for_fit_or_selection=None,stage3_unused_for_fit_tuning_or_improvement_design=None,evidence=''),
        instructions='Fill only after actual verification. This template grants no READY/freeze override. Calibration/size measurement is not a B1/B2 classifier prerequisite.'))
    metrics=[]
    for metric in ('Train Accuracy','Val Accuracy (new 80)','Val FAIL F1 (new 80)','Test Accuracy','Balanced Accuracy','FAIL Precision','FAIL Recall','FAIL F1','False PASS','False FAIL','Coverage','REVIEW','Median live latency','P95 live latency','Model Size'):
        row=dict(metric=metric)
        for variant in ('baseline1_old','baseline1_new','baseline2_old','baseline2_new'):
            value='NOT_MEASURED' if 'latency' in metric else 'NOT_RUN'
            if metric=='Model Size':value=specs[variant]['deployment_model_bytes'] if variant in specs else 'NOT_CREATED'
            row[variant]=value
        metrics.append(row)
    save_csv(output/'comparison_metrics.csv',metrics)
    save_json(output/'comparison_metrics.json',dict(status=report['status'],metrics=metrics,
       historical_metrics_only={k:v['historical_metrics'] for k,v in specs.items()},
       historical_support='262 Train / 46 Validation; cannot substitute for new 360/80/30 comparison',object_metrics='N/A: image-level models'))
    print(json.dumps(dict(output=relative(output),status=report['status'],checks=checks,gate_probes=gate),ensure_ascii=False,indent=2),flush=True)
    if not all(checks.values()):return 1
    return 0


if __name__=='__main__':raise SystemExit(main())
