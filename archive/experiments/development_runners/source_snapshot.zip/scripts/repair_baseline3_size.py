"""Evidence-driven size repairs; Train/development only, frozen v1 stays intact."""
from __future__ import annotations
import argparse
from collections import Counter,defaultdict
from datetime import datetime,timezone
import json
import sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from scripts.experiment_baseline3_v2 import load,save,csvrows,write_csv,digest,rel,configure

EXP=ROOT/'results/baseline3_v2_experiment';OLD=EXP/'size_development_v1'
OUT=EXP/'size_repair_v2';CACHE=ROOT/'outputs/size_repair_v2'
DATA=ROOT/'data/mechanical_components_v2'


def audit():
    if (OUT/'failure_audit.json').exists():return
    runs=load(OLD/'public_runs.json');data=load(ROOT/runs['validation_candidate']/'predictions/diagnostics.json')['images']
    incomplete=[];objects=[];images=[]
    for row in data:
        result=row['result'];inspection=result['inspection']
        images.append(dict(image_id=row['image_id'],status=result['status'],
            measurement_calls=inspection['measurement_calls'],measurement_complete=inspection['measurement_complete'],
            review_reasons=inspection['review_reasons'],foreground_unresolved=[c for c in inspection.get('foreground',{}).get('candidates',[]) if c['class_id'] is None]))
        for obj in result['objects']:
            ev=obj.get('size_evidence',{});m=ev.get('measurement')
            if not m:continue
            reason=m['reason']
            stage=('ROI/isolation' if reason.startswith(('TARGET_','FOREGROUND_TOUCHES','MULTIPLE_FOREGROUND')) else
                   'washer/aperture' if reason.startswith(('INNER_','CIRCULAR_','ELLIPSE_','ANNULAR_')) else
                   'nut/parallel_flats' if reason.startswith(('OPPOSITE_','NUT_','SIX_')) else 'screw/axis_or_edges')
            entry=dict(image_id=row['image_id'],detection_id=obj['detection_id'],detector_class_id=obj['detector_class_id'],
                measurement_status=m['status'],reason=reason,failure_stage=stage if m['status']!='MEASURED_CANDIDATE' else '',
                size_conclusion=ev['conclusion'],final_class_id=obj['class_id'])
            objects.append(entry)
            if m['status']!='MEASURED_CANDIDATE':incomplete.append(entry)
    assert len(objects)==378 and len(incomplete)==73
    write_csv(OUT/'incomplete_73.csv',incomplete);write_csv(OUT/'original_object_measurements.csv',objects)
    save(OUT/'original_image_diagnostics.json',images)
    report=dict(scope='Existing 80 Val outputs are already-used diagnostic data, not independent verification',
        measurement_calls=378,incomplete=73,by_stage=dict(Counter(r['failure_stage'] for r in incomplete)),
        by_reason=dict(Counter(r['reason'] for r in incomplete)),
        by_class={str(c):dict(total=sum(r['detector_class_id']==c for r in objects),
                            incomplete=sum(r['detector_class_id']==c for r in incomplete),
                            reasons=dict(Counter(r['reason'] for r in incomplete if r['detector_class_id']==c))) for c in range(1,6)},
        repair_scope='Develop on public Train and dimension development154 only. A088 is forensic diagnosis only; no fit/tolerance tuning on it. Val80 and retained66 are reused regression cases after code freeze.',
        protected={rel(p):digest(p) for p in OLD.rglob('*') if p.is_file()},
        original_protected=load(OLD/'final_acceptance.json')['protected_manifest'])
    save(OUT/'failure_audit.json',report)
    forensic(data)
    print('AUDIT',report['by_stage'],flush=True)


def forensic(data):
    import cv2,numpy as np
    from src.models.baseline1.features import load_image_bgr
    from src.p06_geometry import measure_object,DEFAULT_PARAMETERS
    row=next(r for r in data if r['image_id']=='A088.jpg')
    obj=next(o for o in row['result']['objects'] if o['detector_class_id']==2)
    im=load_image_bgr(str(DATA/'yolo/images/val'/'A088.jpg'))
    x1,y1,x2,y2=[obj[k] for k in ('xmin','ymin','xmax','ymax')];pad=max(16,round(max(x2-x1,y2-y1)*.18))
    l,t=max(0,int(x1)-pad),max(0,int(y1)-pad);r,b=min(im.shape[1],int(np.ceil(x2))+pad),min(im.shape[0],int(np.ceil(y2))+pad)
    crop=im[t:b,l:r];captured={}
    def trace(frame,event,arg):
        if event=='return' and frame.f_code.co_name in ('body_profile_geometry','screw_geometry','silhouette') and frame.f_code.co_filename.endswith('p06_geometry.py'):
            captured[frame.f_code.co_name]=dict(frame.f_locals)
    params=load(OLD/'selection.json')['selected']['1']['parameters'];scale=load(OLD/'calibration.json')['px_per_mm']
    previous=sys.getprofile();sys.setprofile(trace)
    try:measured=measure_object(crop,2,scale,dict(DEFAULT_PARAMETERS,**{k:v for k,v in params.items() if k!='targeted'}),target_box=[x1-l,y1-t,x2-l,y2-t])
    finally:sys.setprofile(previous)
    body=captured['body_profile_geometry'];screw=captured['screw_geometry']
    folder=CACHE/'forensic';folder.mkdir(parents=True,exist_ok=True);cv2.imencode('.png',crop)[1].tofile(folder/'A088.png')
    keys=('signal','gradient','normal_positions','samples','width','ls','rs','valid','body','inside','axis','normal','center')
    arrays={k:body[k] for k in keys if k in body};np.savez_compressed(folder/'A088_profiles.npz',**arrays)
    evidence=dict(image_id='A088.jpg',diagnosis_only_not_parameter_selection=True,crop_xyxy=[l,t,r,b],
        old_measurement=measured,scale_px_per_mm=scale,
        diameter_px=measured['dimensions']['thread_major_diameter']['pixels'],
        rough_contour_width_px=float(body['rough']),head_width_px=float(body['head_width']),
        chosen_left_index=int(body['left']),chosen_right_index=int(body['right']),
        chosen_transverse_positions_px=body['normal_positions'][[body['left'],body['right']]].tolist(),
        shaft_start=int(body['shoulder']),shaft_end=int(body['tip']),chosen_section=int(body['u']),
        axis=screw['axis'].tolist(),profile_edges_supported=int(len(body['matches'])),
        nominal_conversion_check='93.99999999999993 original pixels / 35.7584464442507 px/mm = 2.62874955 mm; no letterbox factor applied')
    # Save contour and actual gradient selection without altering the original.
    display=crop.copy();contour=captured['silhouette'].get('contour')
    if contour is not None:cv2.drawContours(display,[contour],-1,(0,180,0),2)
    for name,dim in measured['dimensions'].items():
        a,b=np.rint(dim['line_xy']).astype(int);cv2.line(display,tuple(a),tuple(b),(0,0,255),3)
    cv2.imencode('.jpg',display)[1].tofile(OUT/'A088_original_measurement.jpg')
    # Compact sampled profile, coordinates and original lines are machine-readable.
    write_csv(OUT/'A088_transverse_profile.csv',[dict(index=i,transverse_px=float(p),intensity=float(s),gradient=float(g),chosen_edge=i in (body['left'],body['right']))
        for i,(p,s,g) in enumerate(zip(body['normal_positions'],body['signal'],body['gradient']))])
    save(OUT/'A088_forensic.json',evidence)
    print('A088 rough/selected px',evidence['rough_contour_width_px'],evidence['diameter_px'],flush=True)


def prepare_jobs():
    if (OUT/'development_jobs.json').exists():return load(OUT/'development_jobs.json')
    import cv2,numpy as np
    from src.models.baseline1.features import load_image_bgr
    runs=load(OLD/'public_runs.json');data=load(ROOT/runs['train_candidate']/'predictions/diagnostics.json')['images']
    truth={r['image_id']:r for r in csvrows(DATA/'development/ground_truth_images.csv') if r['split']=='train'}
    folder=CACHE/'crops';folder.mkdir(parents=True,exist_ok=True);jobs=[]
    def crop_job(im,box,peers,record):
        x1,y1,x2,y2=box;pad=max(24,round(max(x2-x1,y2-y1)*.35))
        l,t=max(0,int(x1)-pad),max(0,int(y1)-pad);r,b=min(im.shape[1],int(np.ceil(x2))+pad),min(im.shape[0],int(np.ceil(y2))+pad)
        path=folder/(record['uid']+'.png')
        if not path.exists():cv2.imencode('.png',im[t:b,l:r])[1].tofile(path)
        local=lambda p:[p[0]-l,p[1]-t,p[2]-l,p[3]-t]
        return dict(record,crop_path=rel(path),crop_xyxy=[l,t,r,b],target_box=local(box),
                    excluded_boxes=[local(p) for p in peers if min(r,p[2])>max(l,p[0]) and min(b,p[3])>max(t,p[1])])
    for number,row in enumerate(data):
        image=row['image_id'];assert image in truth
        im=load_image_bgr(str(ROOT/truth[image]['image_path']));objects=row['result']['objects']
        for obj in objects:
            cid=obj['detector_class_id']
            if cid==0:continue
            box=[obj[k] for k in ('xmin','ymin','xmax','ymax')]
            peers=[[o[k] for k in ('xmin','ymin','xmax','ymax')] for o in objects if o['detection_id']!=obj['detection_id']]
            jobs.append(crop_job(im,box,peers,dict(uid=f"train_{Path(image).stem}_{obj['detection_id']}",
                image_id=image,detection_id=obj['detection_id'],class_id=cid,split='public_train',
                original_measurement=obj.get('size_evidence',{}).get('measurement'))))
        if number%60==0:print('TRAIN ROI',number,'/360',flush=True)
    for row in load(OLD/'rois.json'):
        if row['experiment_split']!='development':continue
        im=load_image_bgr(str(ROOT/row['image_path']))
        if row.get('crop_xyxy'):
            l,t,r,b=row['crop_xyxy'];a,c,d,e=row['target_box'];box=[l+a,t+c,l+d,t+e];roi_method='frozen detector/measurement ROI'
        else:
            small=cv2.cvtColor(cv2.resize(im,(756,1008),interpolation=cv2.INTER_AREA),cv2.COLOR_BGR2GRAY)
            residual=cv2.GaussianBlur(small,(0,0),31).astype(float)-small
            mask=cv2.morphologyEx((residual>20).astype(np.uint8),cv2.MORPH_CLOSE,np.ones((3,3),np.uint8))
            contours,_=cv2.findContours(mask,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
            candidates=[]
            for contour in contours:
                x,y,w,h=cv2.boundingRect(contour)
                if x>1 and y>1 and x+w<755 and y+h<1007 and cv2.contourArea(contour)>=50:candidates.append(contour)
            assert candidates,'No diagnostic foreground ROI: '+row['image_id']
            x,y,w,h=cv2.boundingRect(max(candidates,key=cv2.contourArea));box=[4*x,4*y,4*(x+w),4*(y+h)];roi_method='local background foreground diagnostic ROI; not ground truth'
        jobs.append(crop_job(im,box,[],dict(uid='dimension_'+Path(row['image_id']).stem,image_id=row['image_id'],
            class_id=int(row['official_class_id']) or int(row['measurement_family']),
            official_class_id=int(row['official_class_id']),physical_sample_id=row['physical_sample_id'],
            split='dimension_development',original_measurement=None,roi_method=roi_method)))
    save(OUT/'development_jobs.json',jobs);return jobs


def develop():
    if (OUT/'development_measurements.json').exists() or (OUT/'development_measurements.json.gz').exists():return
    import cv2
    from concurrent.futures import ThreadPoolExecutor
    from src.models.baseline3.geometry_repair import measure_object
    from src.models.baseline3.size_candidate import size_conclusion
    cv2.setNumThreads(1)
    jobs=prepare_jobs();selection=load(OLD/'selection.json');scale=load(OLD/'calibration.json')['px_per_mm']
    save(OUT/'repair_plan.json',dict(training_images=360,dimension_development_images=154,
        prohibited_for_development=['Val80 pixel/statistic tuning','dimension retained66','Stage2 Test','Stage3'],
        prior_val_use='73 failure classification and A088 forensic diagnosis explicitly requested; already-used data, not independent',
        algorithm_changes=['35% ROI with peer ownership (old18%); do not reject target merely because shadows cross YOLO box',
            'Hull-supported screw axis; real exterior gradients with sustained outside background, repeated thread-crest envelope',
            'Try both observed dark/closed-edge outlines against unchanged nut/annulus fit quality',
            'Only image-supported measurements can reject as ID0; local repeatability interval must clearly exclude frozen band'],
        no_tolerance_widening=True,acceptance_bands_sha256=digest(OLD/'selection.json'),
        yolo_weights_sha256=load(ROOT/'models/baseline3_v2_candidate/detector.json')['weights_sha256'],
        parameter_search=False,independent_validation_available=False))
    def run(row):
        import numpy as np
        image=cv2.imdecode(np.fromfile(ROOT/row['crop_path'],np.uint8),cv2.IMREAD_COLOR)
        family='1' if row['class_id'] in (1,2,3) else str(row['class_id'])
        params={k:v for k,v in selection['selected'][family]['parameters'].items() if k!='targeted'}
        m=measure_object(image,row['class_id'],scale,params,target_box=row['target_box'],excluded_boxes=row['excluded_boxes'])
        conclusion,details=size_conclusion(m,row['class_id'],selection['bands'])
        return dict(uid=row['uid'],measurement=m,conclusion=conclusion,details=details)
    results=[]
    with ThreadPoolExecutor(max_workers=4) as pool:
        for n,result in enumerate(pool.map(run,jobs),1):
            results.append(result)
            if n%200==0:print('GEOMETRY',n,'/',len(jobs),flush=True)
    save(OUT/'development_measurements.json',results)
    save(OUT/'development_code.json',dict(geometry_sha256=digest(ROOT/'src/models/baseline3/geometry_repair.py'),
        jobs_sha256=digest(OUT/'development_jobs.json'),stage='Train+dimension development only',
        interrupted_attempt='Initial scalar gradient scan interrupted before producing results; reused ROI cache and replaced scan with equivalent vectorized local maxima, no threshold change'))
    index={r['uid']:r for r in results};summaries={}
    for split in ('public_train','dimension_development'):
        subset=[r for r in jobs if r['split']==split];summary={}
        for cid in range(1,6):
            values=[index[r['uid']] for r in subset if r['class_id']==cid]
            summary[str(cid)]=dict(n=len(values),complete=sum(v['measurement']['status']=='MEASURED_CANDIDATE' for v in values),
                reasons=dict(Counter(v['measurement']['reason'] for v in values if v['measurement']['reason'])),
                conclusions=dict(Counter(v['conclusion'] for v in values)))
        summaries[split]=summary
    save(OUT/'development_summary.json',summaries)
    print('DEVELOPMENT',json.dumps(summaries),flush=True)


def configurations():
    candidate=load(OLD/'candidate.json');candidate.update(geometry_revision='exterior-geometry-repair-v2',
        numerical_bands='Frozen v1 ranges unchanged; quality uncertainty can prevent ID0, never widens PASS range',
        evaluation_scope='Development/reused regression only; no independent Test for this repaired system')
    if not (OUT/'candidate.json').exists():save(OUT/'candidate.json',candidate)
    profile=load(OLD/'p07_profile.json');profile['bridge']='src.models.baseline3.size_repaired:create_backend'
    profile['model_config'].update(baseline3_mode='size_repaired_development',size_candidate_config=rel(OUT/'candidate.json'))
    if not (OUT/'p07_profile.json').exists():save(OUT/'p07_profile.json',profile)


def replay():
    """Full decisions over Train using existing YOLO + newly measured geometry."""
    if (OUT/'train_replay.json').exists():
        reference_consistency_replay();return
    import cv2,numpy as np
    from src.models.baseline3.size_repaired import RepairedSizeBackend
    from src.models.baseline3.inference import _observations
    from src.models.baseline1.features import load_image_bgr
    from src.p07_bridge import validate_result
    configurations();cv2.setNumThreads(1)
    backend=RepairedSizeBackend(OUT/'candidate.json')
    results=load(OUT/'development_measurements.json');by_uid={r['uid']:r for r in results}
    runs=load(OLD/'public_runs.json');old=load(ROOT/runs['train_candidate']/'predictions/diagnostics.json')['images']
    truth={r['image_id']:r for r in csvrows(DATA/'development/ground_truth_images.csv') if r['split']=='train'}
    cases=[];frame_counts=Counter();measure_counts=Counter();old_counts=Counter();by_class=defaultdict(Counter)
    for n,row in enumerate(old):
        image=row['image_id'];frame=load_image_bgr(str(ROOT/truth[image]['image_path']));h,w=frame.shape[:2]
        objects=row['result']['objects'];raw=_observations([[o[k] for k in ('xmin','ymin','xmax','ymax','score')]+[o['detector_class_id']] for o in objects],w,h)
        cache={o['detection_id']:by_uid[f"train_{Path(image).stem}_{o['detection_id']}"]['measurement'] for o in objects if o['detector_class_id']!=0}
        result=validate_result(backend.process_observations(frame,raw,row['expected_counts'],measurement_cache=cache),'baseline3',frame.shape)
        label=truth[image]['ground_truth_label'];frame_counts[result['status']]+=1
        if result['status']==label:frame_counts['correct']+=1
        if label=='FAIL' and result['status']=='PASS':frame_counts['false_pass']+=1
        if label=='PASS' and result['status']=='FAIL':frame_counts['false_fail']+=1
        measure_counts.update(calls=result['inspection']['measurement_calls'],complete=result['inspection']['measurement_complete'])
        old_counts.update(calls=row['result']['inspection']['measurement_calls'],complete=row['result']['inspection']['measurement_complete'])
        for o in result['objects']:
            m=o.get('size_evidence',{}).get('measurement')
            if not m:continue
            c=by_class[str(o['detector_class_id'])];c.update(calls=1,complete=int(m['status']=='MEASURED_CANDIDATE'))
            c['status:'+o['size_evidence']['conclusion']]+=1
            if m['reason']:c['reason:'+m['reason']]+=1
        cases.append(dict(image_id=image,truth=label,result=result))
        if n%60==0:print('TRAIN REPLAY',n,'/360',flush=True)
    save(OUT/'train_replay_cases.json',cases)
    save(OUT/'train_replay.json',dict(scope='Training diagnostic only, cached unchanged YOLO and actual v2 geometry; no timing claim',
        images=360,frames=dict(frame_counts),measurements=dict(measure_counts),original_measurements=dict(old_counts),
        by_class={k:dict(v) for k,v in by_class.items()},geometry_sha256=digest(ROOT/'src/models/baseline3/geometry_repair.py'),
        backend_sha256=digest(ROOT/'src/models/baseline3/size_repaired.py'),bands_unchanged=True))
    print('TRAIN REPLAY',dict(frame_counts),dict(measure_counts),flush=True)
    reference_consistency_replay()


def reference_consistency_replay():
    """Replay only the final static-reference guard over already measured data."""
    record=load(OUT/'train_replay.json')
    if record.get('reference_consistency_applied'):return
    from types import SimpleNamespace
    from src.models.baseline3.size_repaired import assess,RepairedSizeBackend
    from src.p07_bridge import validate_result
    bands=load(OLD/'selection.json')['bands'];specs={s['class_id']:s for s in load(ROOT/'config/p06_part_specs_candidate.json')['items']}
    data=load(OUT/'train_replay_cases.json');changes=[];counts=Counter();by_class=defaultdict(Counter)
    native=RepairedSizeBackend.__new__(RepairedSizeBackend)
    native.detector=SimpleNamespace(_params=load(ROOT/'models/baseline3_v2_candidate/detector.json')['inference'])
    for row in data:
        r=row['result'];old_status=r['status'];updates=[]
        for obj in r['objects']:
            cid=obj['detector_class_id'];ev=obj.get('size_evidence',{})
            if cid==0 or ev.get('conclusion')!='OUTSIDE_DEVELOPMENT_BAND':continue
            conclusion,details,intervals=assess(ev['measurement'],cid,bands,specs[cid])
            if conclusion=='SPEC_REFERENCE_CONFLICT':
                obj['class_id']=cid;obj.pop('class_assignment',None);ev.update(conclusion=conclusion,details=details,dimension_evidence=intervals)
                prefix=f"object {obj['detection_id']}: IMAGE_SUPPORTED_SIZE_OUTSIDE_UNCHANGED_BAND"
                r['inspection']['failure_reasons']=[s for s in r['inspection']['failure_reasons'] if not s.startswith(prefix)]
                r['inspection']['review_reasons'].append(f"object {obj['detection_id']}: SPEC_REFERENCE_CONFLICT {details}")
                updates.append(dict(detection_id=obj['detection_id'],class_id=cid,details=details))
        r=native.rejudge(r,r['expected_counts']);row['result']=r
        validate_result(r,'baseline3',(4032,3024,3));counts[r['status']]+=1
        if r['status']==row['truth']:counts['correct']+=1
        if r['status']=='PASS' and row['truth']=='FAIL':counts['false_pass']+=1
        if r['status']=='FAIL' and row['truth']=='PASS':counts['false_fail']+=1
        if updates:changes.append(dict(image_id=row['image_id'],old_status=old_status,new_status=r['status'],objects=updates))
        for o in r['objects']:
            ev=o.get('size_evidence',{});m=ev.get('measurement')
            if m:
                c=by_class[str(o['detector_class_id'])];c.update(calls=1,complete=int(m['status']=='MEASURED_CANDIDATE'))
                c['status:'+ev['conclusion']]+=1
                if m['reason']:c['reason:'+m['reason']]+=1
    save(OUT/'reference_consistency_changes.json',dict(scope='Shared final native quality function on cached real measurements; no image/model rerun',
        old_frames=record['frames'],new_frames=dict(counts),changed_cases=changes,
        pass_range_and_spec_allowances_unchanged=True,truth_not_used_in_decisions=True))
    record.update(frames=dict(counts),by_class={k:dict(v) for k,v in by_class.items()},reference_consistency_applied=True,
        backend_sha256=digest(ROOT/'src/models/baseline3/size_repaired.py'),
        note='Final nominal-reference consistency guard replayed using native assess/rejudge; no PASS promotion or tolerance widening')
    save(OUT/'train_replay_cases.json',data);save(OUT/'train_replay.json',record)
    print('FINAL TRAIN QUALITY REPLAY',dict(counts),flush=True)


def freeze():
    if (OUT/'candidate_freeze.json').exists():return
    configurations()
    development=load(OUT/'development_code.json')
    assert development['geometry_sha256']==digest(ROOT/'src/models/baseline3/geometry_repair.py'),'Development run is stale'
    replay_data=load(OUT/'train_replay.json')
    assert replay_data['geometry_sha256']==development['geometry_sha256']
    assert replay_data['backend_sha256']==digest(ROOT/'src/models/baseline3/size_repaired.py')
    paths=[OUT/'candidate.json',OUT/'p07_profile.json',ROOT/'src/models/baseline3/geometry_repair.py',
           ROOT/'src/models/baseline3/size_repaired.py',OLD/'selection.json',OLD/'calibration.json',
           ROOT/'models/baseline3_v2_candidate/detector.json',ROOT/'models/baseline3_v2_candidate/best.pt',
           ROOT/'config/p06_part_specs_candidate.json']
    save(OUT/'candidate_freeze.json',dict(frozen_at_utc=datetime.now(timezone.utc).isoformat(),
        files={rel(p):digest(p) for p in paths},no_yolo_training=True,no_numerical_band_changes=True,
        selection_scope='Train360 and dimension development154; Val73 failure-output audit/A088 forensic already-used diagnosis disclosed',
        subsequent_val='Reused regression only, not independent validation',
        formal_test='NOT_RUN for repaired candidate; historical Test unchanged',stage3='NOT_OPENED'))
    print('REPAIR CANDIDATE FROZEN',flush=True)


def regress():
    if (OUT/'regression_comparison.json').exists():return
    from scripts.experiment_baseline3_v2 import saved_run,run_metrics,object_diagnostics
    frozen=load(OUT/'candidate_freeze.json');assert all(digest(ROOT/p)==h for p,h in frozen['files'].items())
    run=saved_run(OUT/'val_regression',OUT/'p07_profile.json',EXP/'configs/validation.json')
    summary=run_metrics(run);obs=load(run/'evaluation/object_observations.json');data=load(run/'predictions/diagnostics.json')['images']
    by_class={};incomplete=[];rejections=[]
    for cid in range(1,6):
        objects=[(r,o) for r in data for o in r['result']['objects'] if o.get('detector_class_id')==cid]
        measurements=[o['size_evidence']['measurement'] for _,o in objects if 'measurement' in o.get('size_evidence',{})]
        by_class[str(cid)]=dict(calls=len(measurements),complete=sum(m['status']=='MEASURED_CANDIDATE' for m in measurements),
            failures=dict(Counter(m['reason'] for m in measurements if m['reason'])),
            size_conclusions=dict(Counter(o['size_evidence']['conclusion'] for _,o in objects)))
        for row,o in objects:
            m=o.get('size_evidence',{}).get('measurement')
            if m and m['status']!='MEASURED_CANDIDATE':incomplete.append(dict(image_id=row['image_id'],detection_id=o['detection_id'],class_id=cid,reason=m['reason']))
            if o['class_id']==0:rejections.append(dict(image_id=row['image_id'],detection_id=o['detection_id'],detector_class_id=cid,details=';'.join(o['size_evidence']['details'])))
    write_csv(OUT/'regression_incomplete.csv',incomplete,['image_id','detection_id','class_id','reason'])
    write_csv(OUT/'regression_size_rejections.csv',rejections,['image_id','detection_id','detector_class_id','details'])
    write_csv(OUT/'regression_object_errors.csv',object_diagnostics(run),['image_id','event','object_id','true_class','detection_id','predicted_class','score','iou'])
    oldruns=load(OLD/'public_runs.json');oldm=run_metrics(ROOT/oldruns['validation_candidate'])
    truths={r['image_id']:r for r in csvrows(DATA/'evaluation/validation/ground_truth_images.csv')}
    oldrows={r['image_id']:r for r in csvrows(ROOT/oldruns['validation_candidate']/'predictions/images.csv')}
    paired=[]
    for row in data:
        image=row['image_id'];truth=truths[image]['ground_truth_label'];r=row['result']
        paired.append(dict(image_id=image,true_label=truth,old_status=oldrows[image]['status'],new_status=r['status'],
            correct=r['status']==truth,recovered=oldrows[image]['status']!=truth and r['status']==truth,
            regression=oldrows[image]['status']==truth and r['status']!=truth,
            reasons='; '.join(r['inspection']['decision_failure_reasons']+r['inspection']['decision_review_reasons'])))
    write_csv(OUT/'regression_paired.csv',paired)
    record=dict(scope='80 already-used Val cases; reused regression diagnosis, NOT independent validation',run=rel(run),
        original=oldm,repaired=summary,objects=obs,by_class=by_class,
        measurement_calls=sum(v['calls'] for v in by_class.values()),complete=sum(v['complete'] for v in by_class.values()),
        foreground_complete=sum(r['result']['inspection']['foreground']['counts_complete'] for r in data),
        recovered=sum(r['recovered'] for r in paired),regressions=sum(r['regression'] for r in paired),
        no_code_updates_based_on_this_regression=True,independent_validation=False,
        dimension_retained66='NOT_RERUN; already-used scenes, not independent evidence',
        formal_stage2_test='NOT_RERUN',stage3='NOT_OPENED')
    save(OUT/'regression_comparison.json',record)
    a=next(r for r in data if r['image_id']=='A088.jpg');o=next(o for o in a['result']['objects'] if o['detector_class_id']==2)
    save(OUT/'A088_repaired_regression.json',dict(scope='Post-freeze reused forensic regression, not selection',
        image_id='A088.jpg',result_status=a['result']['status'],object=o))
    print('VAL REGRESSION',summary['status_counts'],'measurement',record['complete'],'/',record['measurement_calls'],
          'false pass/fail',summary['false_pass']['count'],summary['false_fail']['count'],flush=True)


def check():
    if (OUT/'acceptance.json').exists():return
    import unittest,cv2,numpy as np,time
    from types import SimpleNamespace
    from src.p07_bridge import load_backend,validate_result
    from src.models.baseline1.features import load_image_bgr
    from src.p07_ui import InferenceWorker
    from src.p07_dashboard import render
    sys.path.insert(0,str(ROOT/'tests'));cv2.setNumThreads(1)
    names=['test_baseline3_geometry_repair','test_baseline3_metrology','test_baseline3_size_integration',
        'test_baseline3_adapter','test_p06_geometry','test_p06_foreground','test_p06_measurement_policy',
        'test_work_orders','test_p07_real_integration','test_p07_dashboard']
    with (OUT/'software_tests.log').open('w',encoding='utf8') as log:
        tests=unittest.TextTestRunner(stream=log,verbosity=2).run(unittest.TestLoader().loadTestsFromNames(names))
    test_record=dict(run=tests.testsRun,failures=len(tests.failures),errors=len(tests.errors),skipped=len(tests.skipped),
        modules=names,synthetic_software_fixtures_are_not_physical_acceptance=True)
    save(OUT/'software_tests.json',test_record);assert tests.wasSuccessful(),'See software_tests.log'
    protected=load(OUT/'failure_audit.json');changed=[p for p,h in protected['protected'].items() if digest(ROOT/p)!=h]
    changed.extend(p for p,h in protected['original_protected'].items() if digest(ROOT/p)!=h)
    assert not changed,changed
    assert all(digest(ROOT/p)==h for p,h in load(OLD/'candidate_freeze.json')['files'].items()),'Frozen v1 algorithm changed'
    assert all(digest(ROOT/p)==h for p,h in load(OUT/'candidate_freeze.json')['files'].items())
    profile=load(OUT/'p07_profile.json');backend=load_backend('real','baseline3',profile)
    run=ROOT/load(OUT/'regression_comparison.json')['run'];cases=load(run/'predictions/diagnostics.json')['images'];functional=[]
    for status in ('PASS','FAIL','REVIEW'):
        row=next((r for r in cases if r['result']['status']==status),None)
        if row is None:functional.append(dict(status=status,result='NOT_AVAILABLE_IN_REGRESSION'));continue
        image=load_image_bgr(str(DATA/'yolo/images/val'/row['image_id']));packet=SimpleNamespace(image=image,frame_id=1)
        worker=InferenceWorker();worker.submit(backend,'baseline3',packet,row['expected_counts'],'pass',1)
        worker.future.result(timeout=120);actual=worker.poll()['result'];worker.close();expected=row['result']
        assert actual['status']==expected['status'] and actual['counts']==expected['counts']
        assert len(actual['objects'])==len(expected['objects'])
        for a,b in zip(actual['objects'],expected['objects']):
            for k in ('detection_id','class_id','detector_class_id'):assert a[k]==b[k]
            assert np.allclose([a[k] for k in ('xmin','ymin','xmax','ymax','score')],[b[k] for k in ('xmin','ymin','xmax','ymax','score')],rtol=0,atol=1e-6)
            da=a['size_evidence'].get('measurement',{}).get('dimensions',{});db=b['size_evidence'].get('measurement',{}).get('dimensions',{})
            assert da.keys()==db.keys()
            for key in da:assert abs(da[key]['mm_estimate']-db[key]['mm_estimate'])<1e-6
        changed_order=backend.rejudge(actual,dict.fromkeys('12345',0));restored=backend.rejudge(changed_order,row['expected_counts'])
        assert actual['objects']==changed_order['objects']==restored['objects'] and actual['counts']==changed_order['counts']
        assert actual['status']==restored['status']
        path=OUT/'diagnostic_views'/(status.lower()+'.jpg');path.parent.mkdir(exist_ok=True)
        cv2.imencode('.jpg',render(packet,actual,row['expected_counts'],'baseline3','real',dict(show_diagnostics=True)))[1].tofile(path)
        functional.append(dict(status=status,image_id=row['image_id'],gui_worker_matches_batch=True,counts_rejudge_preserves_measurements=True))
    first=next(r for r in cases if r['result']['inspection']['measurement_calls']>0)
    image=load_image_bgr(str(DATA/'yolo/images/val'/first['image_id']))
    video=CACHE/'regression_video.avi';writer=cv2.VideoWriter(str(video),cv2.VideoWriter_fourcc(*'MJPG'),5.,(3024,4032))
    assert writer.isOpened();writer.write(image);writer.release();capture=cv2.VideoCapture(str(video))
    try:
        ok,decoded=capture.read();assert ok;video_result=backend.infer(decoded,dict.fromkeys('12345',1))
        assert video_result['inspection']['measurement_calls']>0
    finally:capture.release()
    mismatch=backend.infer(cv2.resize(image,(1280,720)),dict.fromkeys('12345',1))
    assert mismatch['inspection']['measurement_calls']==0 and mismatch['status']!='PASS'
    defaults=load(ROOT/'config/p07.json');other=[]
    for model in ('baseline1','baseline2'):
        native=load_backend('real',model,defaults);result=native.infer(image,dict.fromkeys('12345',1))
        unsupported=native.infer(image,dict.fromkeys('12345',0));assert unsupported['status']=='UNSUPPORTED_COUNTS' and not native.is_mock
        other.append(dict(model=model,real_loaded=True,status=result['status'],variable_order=unsupported['status'],
                          scope='Functional execution, not a new model accuracy evaluation'))
    save(OUT/'acceptance.json',dict(tests=test_record,gui_batch=functional,video_measurement_calls=video_result['inspection']['measurement_calls'],
        camera_resolution_guard_passed=True,physical_camera='NOT_RUN',baseline1_baseline2=other,
        frozen_v1_result_files_unchanged=len(protected['protected']),original_protected_files_unchanged=len(protected['original_protected']),
        full_size_pipeline_enabled=True,production_mock=False,old_weights_and_parameters_unchanged=True,frozen_v1_algorithm_hashes_match=True,
        p03='NO_WRITES',formal_test='NOT_RERUN',stage3='NO_IMAGES_OR_DEDICATED_TRUTH_OPENED',
        physical_stage2_acceptance='NOT_PASSED: caliper truth, Camo calibration, instructor tolerance approval and independent evaluation pending'))
    print('SOFTWARE ACCEPTANCE',tests.testsRun,'tests passed;',len(protected['protected']),'v1 files unchanged',flush=True)


def diagnose_head_plane(gray,measurement):
    """Train-only probe of a visible head seating plane, never nominal fitting."""
    import cv2,numpy as np
    dims=measurement['dimensions'];shoulder,tip=np.asarray(dims['underhead_length']['line_xy'],float)
    diameter=float(dims['thread_major_diameter']['pixels']);length=np.linalg.norm(tip-shoulder)
    axis=(tip-shoulder)/length;normal=np.array([-axis[1],axis[0]])
    positions=np.arange(-.7*diameter,.75*diameter)
    radii=[-.60,.60,-.72,.72,-.84,.84]
    grid=shoulder+positions[None,:,None]*axis+np.asarray(radii)[:,None,None]*diameter*normal
    if not ((grid[:,:,0]>=0).all() and (grid[:,:,0]<gray.shape[1]-1).all() and (grid[:,:,1]>=0).all() and (grid[:,:,1]<gray.shape[0]-1).all()):return dict(status='UNRESOLVED',reason='HEAD_TRACK_OUTSIDE_ROI')
    signal=cv2.remap(gray.astype(np.float32),grid[:,:,0].astype(np.float32),grid[:,:,1].astype(np.float32),cv2.INTER_LINEAR)
    signal=cv2.GaussianBlur(signal,(7,1),1.3);gradient=np.gradient(signal,axis=1);locations=[]
    for values,g in zip(signal,gradient):
        bg=float(np.median(values[-10:]));peaks=np.flatnonzero((g[1:-1]>=g[:-2])&(g[1:-1]>g[2:])&(g[1:-1]>=3))+1
        accepted=[]
        for j in peaks:
            if j<5 or len(g)-j<max(12,.18*diameter):continue
            if max(g[j-3],g[j+3])>=.8*g[j]:continue
            outside=values[j+5:]
            if np.quantile(abs(outside-bg),.8)<18 and np.median(outside)-np.median(values[j-5:j-2])>=10:accepted.append(j)
        locations.append(float(positions[accepted[-1]]) if accepted else None)
    pairs=[]
    for i in range(0,6,2):
        if locations[i] is not None and locations[i+1] is not None and abs(locations[i]-locations[i+1])<=max(4,.15*diameter):pairs.append((locations[i]+locations[i+1])/2)
    if len(pairs)<2 or max(pairs)-min(pairs)>.2*diameter:return dict(status='UNRESOLVED',reason='HEAD_SEATING_PLANE_NOT_CONFIRMED',tracks=locations)
    offset=float(np.median(pairs));new_length=length-offset
    scale=float(np.mean(measurement['scale_px_per_mm']))
    return dict(status='VISIBLE_HEAD_PLANE',tracks=locations,offset_pixels=offset,old_length_mm=length/scale,
        new_length_mm=new_length/scale,line_xy=[(shoulder+offset*axis).tolist(),tip.tolist()],
        caveat='Visible multi-radius seating-plane consistency only; head style and caliper truth still needed')


def headcheck():
    if (OUT/'head_plane_development_probe.json').exists():return
    import gzip,cv2,numpy as np
    rows={r['uid']:r for r in load(OUT/'development_jobs.json')}
    if (OUT/'development_measurements.json').exists():data=load(OUT/'development_measurements.json')
    else:
        with gzip.open(OUT/'development_measurements.json.gz','rt',encoding='utf8') as f:data=json.load(f)
    selected=[]
    for cid in (1,2,3):
        available=[r for r in data if rows[r['uid']]['split']=='public_train' and rows[r['uid']]['class_id']==cid and r['measurement']['status']=='MEASURED_CANDIDATE']
        available.sort(key=lambda r:r['measurement']['dimensions']['underhead_length']['mm_estimate'])
        chosen=available[:5]+available[len(available)//2:len(available)//2+5]+available[-5:]
        for entry in chosen:
            row=rows[entry['uid']];image=cv2.imdecode(np.fromfile(ROOT/row['crop_path'],np.uint8),cv2.IMREAD_COLOR)
            probe=diagnose_head_plane(cv2.cvtColor(image,cv2.COLOR_BGR2GRAY),entry['measurement'])
            selected.append(dict(uid=entry['uid'],class_id=cid,measurement=probe))
    save(OUT/'head_plane_development_probe.json',dict(scope='45 public Train extremes/medians; no Val or retained pixels, no parameter grid',results=selected))


def report():
    """Generate Chinese engineering notes; never claim independent acceptance."""
    import gzip,hashlib,numpy as np
    from src.models.baseline3.size_repaired import assess
    artifact=OUT/'development_measurements.json';compressed=OUT/'development_measurements.json.gz'
    if artifact.exists():
        raw=artifact.read_bytes()
        with gzip.open(compressed,'wb',compresslevel=6) as f:f.write(raw)
        assert hashlib.sha256(gzip.decompress(compressed.read_bytes())).hexdigest()==hashlib.sha256(raw).hexdigest()
        save(OUT/'measurement_archive.json',dict(path=rel(compressed),uncompressed_sha256=hashlib.sha256(raw).hexdigest(),lossless=True))
        assert artifact.resolve().parent==OUT.resolve();artifact.unlink()
    with gzip.open(compressed,'rt',encoding='utf8') as f:measurements=json.load(f)
    jobs={r['uid']:r for r in load(OUT/'development_jobs.json')};bands=load(OLD/'selection.json')['bands']
    specs={s['class_id']:s for s in load(ROOT/'config/p06_part_specs_candidate.json')['items']}
    special=[];distributions=[]
    for entry in measurements:
        row=jobs[entry['uid']]
        if row['split']!='dimension_development':continue
        m=entry['measurement'];outcome,details,intervals=assess(m,row['class_id'],bands,specs[row['class_id']])
        special.append(dict(image_id=row['image_id'],physical_sample_id=row['physical_sample_id'],official_class_id=row['official_class_id'],
            challenged_class=row['class_id'],complete=m['status']=='MEASURED_CANDIDATE',conclusion=outcome,reason=m['reason']))
        for key,dimension in m['dimensions'].items():distributions.append(dict(image_id=row['image_id'],physical_sample_id=row['physical_sample_id'],
            dimension=key,pixels=dimension['pixels'],mm_provisional=dimension['mm_estimate']))
    write_csv(OUT/'dimension_development_decisions.csv',special)
    write_csv(OUT/'dimension_development_values.csv',distributions)
    summaries=[]
    for sid in sorted({r['physical_sample_id'] for r in special}):
        group=[r for r in special if r['physical_sample_id']==sid];counts=Counter(r['conclusion'] for r in group)
        summaries.append(dict(physical_sample_id=sid,n=len(group),complete=sum(r['complete'] for r in group),
            accepted=counts['WITHIN_DEVELOPMENT_BAND'],rejected=counts['OUTSIDE_DEVELOPMENT_BAND'],
            unresolved=len(group)-counts['WITHIN_DEVELOPMENT_BAND']-counts['OUTSIDE_DEVELOPMENT_BAND']))
    write_csv(OUT/'dimension_development_summary.csv',summaries)
    regression=load(OUT/'regression_comparison.json');training=load(OUT/'train_replay.json');audit_data=load(OUT/'failure_audit.json');acceptance=load(OUT/'acceptance.json')
    old=regression['original'];new=regression['repaired'];pct=lambda x:f'{100*x:.2f}%'
    rows=[]
    old_all=load(OLD/'public_comparison.json')['results']
    from src.evaluator import image_level_details
    train_cases=load(OUT/'train_replay_cases.json')
    train_details=image_level_details([dict(ground_truth_label=r['truth'],prediction_status=r['result']['status'],
        predicted_label=r['result']['predicted_label']) for r in train_cases])
    for label,m in (('v1_Train',old_all['train_candidate']['image_level']),('v2_Train_cache_replay',train_details),('v2_Val_reused_regression',new),('v1_Val_reused_regression',old)):
        rows.append(dict(mode=label,input_cases=m['input_cases'],correct_fraction_all_inputs=m['all_input_correct_fraction'],
            completed_accuracy=m['completed_accuracy'],coverage=m['eligible_coverage'],pass_outputs=m['status_counts'].get('PASS',0),
            review=m['status_counts'].get('REVIEW',0),false_pass=m['false_pass']['count'],false_fail=m['false_fail']['count'],
            fail_precision=m['fail']['precision'],fail_recall=m['fail']['recall'],fail_f1=m['fail']['f1']))
    write_csv(OUT/'comparison_metrics.csv',rows)
    times=[float(r['processing_ms']) for r in csvrows(ROOT/regression['run']/'predictions/timing.csv') if r['processing_ms']]
    old_a=load(OUT/'A088_forensic.json');new_a=load(OUT/'A088_repaired_regression.json');obj=new_a['object'];m=obj['size_evidence'].get('measurement',{})
    lines=['# Baseline3 几何测量修复 v2：实际证据与剩余边界','',
        '本次保留YOLO+尺寸核验+前景+计数+工单完整链路，没有重训YOLO，没有关闭尺寸核验，没有放宽数值范围，没有把validated改true。原v1与全部旧冻结模型/实验结果保持不变。新版独立启动，正式物理验收仍待完成。','',
        '## 1. 原378次测量的73次不完整测量','',
        '| 失败环节 | 次数 |','|---|---:|']
    for k,v in audit_data['by_stage'].items():lines.append(f'| {k} | {v} |')
    lines+=['','| 具体原因 | 次数 |','|---|---:|']
    for k,v in sorted(audit_data['by_reason'].items(),key=lambda t:-t[1]):lines.append(f'| {k} | {v} |')
    lines+=['',
        '42次ROI/隔离失败包括：裁切边缘22、目标分量越过检测框14、多个前景4、目标关联歧义2。YOLO轴对齐框不是精确物理轮廓；邻件及其阴影进入padding后，旧算法把它们当目标的一部分或拒绝整个ROI。','',
        '原18个尺寸改ID0的目标中，M5螺丝10、细螺丝3、螺母3、长螺丝2；这不等于18个独立误判工单。原27张REVIEW均保留在准确率分母，不能从指标中排除。逐目标/逐图证据见incomplete_73.csv和original_image_diagnostics.json。','',
        '## 2. 2.63mm真实原因及修复','',
        old_a['root_cause'],'',
        '原Canny闭轮廓沿螺杆内部反光条绕进金属面，截面粗宽约127.63px；内部反光正梯度约22.4，外边缘约7.5，被旧0.4×最大梯度门槛压掉。左-75px至右+19px仅94px，94/35.758446=2.62875mm，换算无640 letterbox或单位错误。153个截面重复支持的是同一个错误物理边界，不是153次独立正确确认。','',
        f"冻结后重用A088回归：状态{new_a['result_status']}，测量状态{m.get('status','N/A')}，尺寸核验{obj['size_evidence']['conclusion']}。测量值："+json.dumps({k:round(v['mm_estimate'],4) for k,v in m.get('dimensions',{}).items()},ensure_ascii=False)+'。这些是provisional图像估计，不是卡尺真值。','',
        '证据：A088_original_measurement.jpg、A088_transverse_profile.csv、A088_forensic.json及A088_repaired_regression.json。A088已用于取证，不作为独立验证；没有用其值拟合阈值。','',
        '## 3. 实际算法修复及质量门禁','',
        '- ROI扩大至目标跨度35%，先按已知邻件归属隔离，再保留目标框内原始像素；轴对齐框相交不会自动认定实物重叠。实际轮廓重叠仍阻止可靠归属。',
        '- 螺杆主轴使用完整支撑凸包，尺寸端点始终从原始灰度取证；凸包不冒充实物边界。选择向外持续通到背景、且局部变化足够锐利的成对边缘，拒绝内部反光和软阴影。',
        '- 在多个轴向位置验证成对外边缘，使用重复螺纹外包络的P90，不再用单个池化截面的强反光边缘；跨段支持、宽度一致性和裁切范围不满足时明确不可测。',
        '- 螺母对两种真实轮廓运行原平行对边方法；保留3组对边变化作为倾斜/阴影不确定性，不用单一投影短边直接拒识。原12%拟合筛选参数没有放松。',
        '- 垫圈先隔离邻件，再在以目标为中心的局部ROI做原有内外轮廓/椭圆拟合；避免扩大背景改变Otsu分布，消除重复的相同孔拟合调用。原圆度、角覆盖和残差要求没有放松。',
        '- 完整/可信质量检查先于ID0规则；截面重复性、对边变化及椭圆残差形成局部区间。区间仍接触接受范围时为BORDERLINE_MEASUREMENT，不能当已确认错规格。它不是卡尺绝对误差界。',
        '- 旧单实物经验范围与已有供应商标称允许量相矛盾时为SPEC_REFERENCE_CONFLICT，不能据此宣称ID0；PASS范围及原允许量均不扩大。',
        '- 实际测得轮廓用于前景像素守恒，解决同一金属面分片及阴影连接多件的问题；阈值40、最小面积30保持不变。轮廓之外的未匹配区域仍REVIEW，不凭空标ID0。轮廓重叠时撤销无法归属的尺寸拒识，已学ID0仍强制FAIL。','',
        '没有调用其他Baseline/Final补判，没有Highlight-Mask/反光重建，没有Stage3数据，没有把不完整测量伪装为完整。','',
        '## 4. 开发集实际结果','',
        f"公共Train360：实际几何测量完整数1409/1698（{pct(1409/1698)}）→{training['measurements']['complete']}/1698（{pct(training['measurements']['complete']/1698)}）。计数/工单诊断使用同一冻结YOLO观测与实际新几何缓存，非独立模型评估；没有将缓存回放时间冒充模型延迟。",'',
        '最终Train状态：'+json.dumps(training['frames'],ensure_ascii=False)+'；旧v1为17 PASS、197 FAIL、146 REVIEW、False FAIL17、False PASS0。','',
        '下表仅专项开发154张（同8实物），没有重跑66张旧保留场景；后者已经使用过，不再当独立验证。异常件的家族挑战根据已知目录选几何方法，仅用于开发诊断，不是生产输入读取目录标签。','',
        '| 实物编号 | 场景 | 完整测量 | 接受 | 尺寸拒识 | 不可测/边界/冲突 |','|---|---:|---:|---:|---:|---:|']
    for r in summaries:lines.append(f"| {r['physical_sample_id']} | {r['n']} | {r['complete']} | {r['accepted']} | {r['rejected']} | {r['unresolved']} |")
    lines+=['','## 5. 已使用Val80的冻结后回归','',
        'Val已用于先前分析/选型，本轮结果只叫回归诊断。先冻结代码和配置，再运行本轮80图；没有按本次Val结果再次改算法。正式Stage2 Test未重跑，Stage3图像/专用真值未打开。','',
        '| 模式 | 全输入正确率 | 已判定准确率 | Coverage | PASS | REVIEW | False PASS/FAIL |','|---|---:|---:|---:|---:|---:|---:|']
    for label,s in (('原v1',old),('修复v2',new)):
        lines.append(f"| {label} | {pct(s['all_input_correct_fraction'])} | {pct(s['completed_accuracy'])} | {pct(s['eligible_coverage'])} | {s['status_counts'].get('PASS',0)} | {s['status_counts'].get('REVIEW',0)} | {s['false_pass']['count']}/{s['false_fail']['count']} |")
    lines+=['',f"实际测量{regression['complete']}/{regression['measurement_calls']}完整，前景证据完整{regression['foreground_complete']}/80。FAIL Precision/Recall/F1：{pct(new['fail']['precision'])}/{pct(new['fail']['recall'])}/{pct(new['fail']['f1'])}。离线完整处理Median/P95：{np.median(times):.1f}/{np.percentile(times,95):.1f}ms；不含解码、模型加载、Camo/曝光、GUI，不是实机新帧延迟。",'',
        '| 类别 | 原完整/调用 | 新完整/调用 | 新主要失败原因 |','|---|---:|---:|---|']
    for cid,v in regression['by_class'].items():
        previous=audit_data['by_class'][cid];reason='；'.join(f'{k}: {n}' for k,n in sorted(v['failures'].items(),key=lambda t:-t[1])[:3]) or '无'
        lines.append(f"| {cid} | {previous['total']-previous['incomplete']}/{previous['total']} | {v['complete']}/{v['calls']} | {reason} |")
    lines+=['',
        '回归全部退步、False PASS/FAIL及REVIEW原因保存在regression_paired.csv；对象误拒绝/漏检见regression_object_errors.csv。不得只报完成子集准确率。','',
        '## 6. 业务状态、剩余缺陷与物理边界','',
        'PASS仅用于当前开发输入前提满足、数量一致、无ID0、每个目标通过完整尺寸检查且前景已解释的场景。FAIL用于真实检测ID0、可信且无矛盾的尺寸拒识或数量不符。测量/归属/尺度/规格证据不确定为REVIEW；程序/配置故障为ERROR，无Mock或count-only回退。工单重判不会改变框、检测类别、尺寸及实际数量。','',
        '当前仍有真实几何失败、姿态/遮挡及规格证据冲突。螺母对边是可见投影量，垫圈孔受倒角/反光影响，螺丝头下长度仍需实物定义核对。旧经验上限10.08mm与正常开发图10.3–10.4mm的矛盾没有通过放宽数值掩盖。','',
        '剩余False FAIL为H005和H034：H005同时包含原YOLO的ID0误检，H034为长度拒识。A088的M5已经通过尺寸检查，整图仍因另一个垫圈ELLIPSE_SUPPORT_DEGENERATE而REVIEW，未强制改成PASS。完整记录见remaining_false_fail.json。','',
        '另用45个Train极端/中位长度案例做了多半径、双侧可见头下基准诊断：24个可获得一致可见平面，21个不能确认。Train H033/H035的长长度在这种复核下仍约11.6mm，不能凭标称10mm强行修正。该探针未作为新的生产放行规则，没有用Val再调参数；结果见head_plane_development_probe.json。公共工单实物与专项实物是否同一枚、头型和卡尺实测尚需确认，这不同于已确认的专项文件夹内实物编号关系。','',
        '标定仍为35.758446 px/mm的provisional图像标定；照片变焦/镜头差异与高度视差没有独立误差界。未标定的Camo1280×720不输出毫米尺寸或PASS。不能把开发候选PASS当教师正式验收通过。未见未知件的完整定位/拒识尚缺独立物理证据，未匹配前景不会被随意忽略。','',
        '## 7. 需要用户补充的最小实测与确认','',
        '1. 三枚正常螺丝（M4×25、M5×10、M4×10）及异常M4×40：头型、头下有效长度、总长、螺纹外径，各用卡尺重复测3次，说明标称长度从哪个平面量起。',
        '2. M4普通螺母：三组对边距离、厚度；M6盖型螺母：基部对边、总高及盖型结构记录。M5垫圈与M4小垫片：外径、内径和厚度。不能把M4/M5公称螺纹直径当作垫圈外径。',
        '3. Camo操作：固定Camera0的镜头、分辨率、数字变焦和裁切，关闭自动切镜；把真实毫米尺置于实际测量平面，采中心/四角的横竖刻度帧，记录实际分辨率、机位工作距离及零件测量面高度。新建独立geometry_id，不能按分辨率比例直接套照片尺度。',
        '4. 请教师确认每类尺寸量定义、标称规格、允许容差以及错误规格/不可判定处理规则，保留真实确认来源。现有允许量仍未获教师确认，本轮未改任何validated或批准记录。',
        '5. 修复候选冻结后采集新的独立正常/异常规格实物和场景做物理验收；旧Val、专项66、已跑Test不能重新包装成独立证据，Stage3保留集继续封存。','',
        '## 8. 软件验收与复现','',
        f"软件{acceptance['tests']['run']}项通过，0失败/错误；{acceptance['frozen_v1_result_files_unchanged']}个v1结果文件与{acceptance['original_protected_files_unchanged']}个原保护文件哈希一致，v1算法冻结SHA一致。真实GUI worker/批处理和视频核心一致，工单重判不改观测；B1/B2执行和UNSUPPORTED_COUNTS功能复核通过，没有重写它们的验证成绩。实机摄像头未运行，完整Stage2物理验收NOT_PASSED。",'',
        '```powershell','python scripts/repair_baseline3_size.py --phase auto',
        'python app.py --backend real --model baseline3 --config results/baseline3_v2_experiment/size_repair_v2/p07_profile.json','```','',
        'auto按状态跳过已完成阶段，锁防止重复启动；不会训练YOLO或运行封存测试。新核心为src/models/baseline3/geometry_repair.py、size_repaired.py，脚本scripts/repair_baseline3_size.py，测试tests/test_baseline3_geometry_repair.py。旧P06源码、v1源码/配置、app.py、GUI默认配置、B1/B2和权重不变；P03未写入；未commit/push。','',
        '原始ROI缓存仅在忽略的outputs/size_repair_v2；大体积逐点测量使用JSON.gz无损保存，measurement_archive.json记录解压后SHA。开发中未完成的慢扫描尝试中止后复用了ROI，未作为成功结果；r01及质量门禁升级前的非最终结果压缩归档在development_revisions，未覆盖旧v1实验。','',
        '详细实物测量表、Camo采集步骤及教师确认事项见manual_acceptance.md。']
    (OUT/'README.md').write_text('\n'.join(lines)+'\n',encoding='utf8')


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--phase',choices=['audit','develop','headcheck','replay','freeze','regress','check','auto'],required=True)
    args=parser.parse_args();OUT.mkdir(parents=True,exist_ok=True);CACHE.mkdir(parents=True,exist_ok=True);configure()
    import os,msvcrt,traceback
    functions=dict(audit=audit,develop=develop,headcheck=headcheck,replay=replay,freeze=freeze,regress=regress,check=check)
    task_names=dict(audit='audit',develop='development',headcheck='head_diagnostic',replay='train_replay',freeze='freeze',regress='regression',check='acceptance')
    with (CACHE/'phase.lock').open('a+b') as lock:
        lock.seek(0);lock.write(b'1');lock.flush();lock.seek(0)
        try:msvcrt.locking(lock.fileno(),msvcrt.LK_NBLCK,1)
        except OSError:raise RuntimeError('A repair runner already holds the lock; do not duplicate it')
        try:
            for phase in functions if args.phase=='auto' else [args.phase]:
                key='size_repair_v2_'+task_names[phase];state=load(EXP/'task_state.json')
                for name in task_names.values():state['tasks'].setdefault('size_repair_v2_'+name,dict(status='PENDING'))
                if args.phase=='auto' and state['tasks'][key]['status']=='COMPLETED':continue
                history=load(OUT/'execution_history.json') if (OUT/'execution_history.json').exists() else []
                record=dict(phase=phase,pid=os.getpid(),command=[sys.executable,str(Path(__file__).resolve()),'--phase',phase],
                    started_at_utc=datetime.now(timezone.utc).isoformat(),status='RUNNING')
                history.append(record);save(OUT/'execution_history.json',history)
                state['phase']=key;state['tasks'][key]=dict(record);state['next_command']='python scripts/repair_baseline3_size.py --phase auto';save(EXP/'task_state.json',state)
                try:
                    functions[phase]();record.update(status='COMPLETED',finished_at_utc=datetime.now(timezone.utc).isoformat())
                except Exception as error:
                    record.update(status='ERROR',error=repr(error),traceback=traceback.format_exc());raise
                finally:
                    history[-1]=record;save(OUT/'execution_history.json',history)
                    state=load(EXP/'task_state.json');state['tasks'][key]=record
                    remaining=[n for n in task_names.values() if state['tasks']['size_repair_v2_'+n]['status']!='COMPLETED']
                    state['next_command']='python scripts/repair_baseline3_size.py --phase auto' if remaining else 'Automatic geometry repair complete; independent physical acceptance still required'
                    save(EXP/'task_state.json',state)
                    progress=EXP/'PROGRESS.md';text=progress.read_text(encoding='utf8');marker='\n## 尺寸几何修复 v2\n'
                    text=text.split(marker)[0]+marker+'\n'+ '\n'.join(f"- {n}: {state['tasks']['size_repair_v2_'+n]['status']}" for n in task_names.values())
                    text+='\n\n结果目录：`size_repair_v2/`；恢复：`python scripts/repair_baseline3_size.py --phase auto`。旧冻结模型/结果保留；Val仅为已使用数据的回归诊断，正式物理验收待完成。\n'
                    progress.write_text(text,encoding='utf8')
            if (OUT/'acceptance.json').exists():report()
        finally:
            lock.seek(0);msvcrt.locking(lock.fileno(),msvcrt.LK_UNLCK,1)


if __name__=='__main__':main()
